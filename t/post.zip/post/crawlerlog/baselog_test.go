package crawlerlog

import (
	"crawler/post/common"
	"testing"
)

func TestLog(t *testing.T) {
	blog := NewBaseLog("test_log", LOG_SHIFT_BY_DAY, 0, LOG_FATAL|LOG_ERROR|LOG_INFO)

	str := "123"
	i := 200
	blog.DLogError("hello|%s|%d", str, i)
	blog.DLogInfo("oh....")
	blog.DLogInfo("test")
	blog.DLogDebug("test2, debug")
	blog.DLogInfo(common.GetDateStr())
}
