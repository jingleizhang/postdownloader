package crawlerlog

import (
	"crawler/post/common"
	"fmt"
	"log"
	"os"
	"runtime"
	"time"
)

//log mode
const (
	LOG_SHIFT_BY_SIZE = 1
	//LOG_SHIFT_BY_MIN  = 2
	//LOG_SHIFT_BY_HOUR = 3
	LOG_SHIFT_BY_DAY = 4
)

//log level
const (
	LOG_FATAL = 0x01
	LOG_ERROR = 0x02
	LOG_INFO  = 0x04
	LOG_DEBUG = 0x08
)

type BaseLog struct {
	shiftMode     int
	fileName      string
	prefix        string
	maxSize       int //单位：KB
	logLevel      int
	logFile       *os.File
	crawlerLogger *log.Logger
	dateStr       string
}

//maxsize单位：KB
func NewBaseLog(logprefix string, logmode int, maxsize int, level int) *BaseLog {
	blog := BaseLog{}
	blog.shiftMode = logmode
	blog.dateStr = common.GetDateStr()
	blog.prefix = logprefix

	if logmode == LOG_SHIFT_BY_DAY {
		blog.fileName = logprefix + "_" + blog.dateStr
	} else if logmode == LOG_SHIFT_BY_SIZE {
		blog.fileName = logprefix
	} else {
		blog.fileName = logprefix
	}

	blog.maxSize = maxsize
	blog.logLevel = level

	blog.Init()

	return &blog
}

func (blog *BaseLog) Init() {
	var err error
	blog.logFile, err = os.OpenFile(blog.fileName, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		fmt.Println("got error: %s\r\n", err.Error())
		blog.logFile.Close()
		os.Exit(-1)
	}

	//blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp()+"|", log.Ldate|log.Ltime)
	blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp(), 0)
}

func (blog *BaseLog) Fini() {
	if blog.logFile != nil {
		blog.logFile.Close()
	}
}

func (blog *BaseLog) DLogFatal(format string, v ...interface{}) {
	if (blog.logLevel & LOG_FATAL) > 0 {
		file, line, now, ok := blog.getExtraInfo()
		if !ok {
			file = "unknown"
			line = 0
		}
		str := fmt.Sprintf("|%d|%s:%d|FATAL|", now, file, line) + fmt.Sprintf(format, v...)
		blog.dlog(str)
	}
}

func (blog *BaseLog) DLogError(format string, v ...interface{}) {
	if (blog.logLevel & LOG_ERROR) > 0 {
		file, line, now, ok := blog.getExtraInfo()
		if !ok {
			file = "unknown"
			line = 0
		}
		str := fmt.Sprintf("|%d|%s:%d|ERROR|", now, file, line) + fmt.Sprintf(format, v...)
		blog.dlog(str)
	}
}

func (blog *BaseLog) DLogDebug(format string, v ...interface{}) {
	if (blog.logLevel & LOG_DEBUG) > 0 {
		file, line, now, ok := blog.getExtraInfo()
		if !ok {
			file = "unknown"
			line = 0
		}
		str := fmt.Sprintf("|%d|%s:%d|DEBUG|", now, file, line) + fmt.Sprintf(format, v...)
		blog.dlog(str)
	}
}

func (blog *BaseLog) DLogInfo(format string, v ...interface{}) {
	if (blog.logLevel & LOG_INFO) > 0 {
		file, line, now, ok := blog.getExtraInfo()
		if !ok {
			file = "unknown"
			line = 0
		}
		str := fmt.Sprintf("|%d|%s:%d|INFO|", now, file, line) + fmt.Sprintf(format, v...)
		blog.dlog(str)
	}
}

func (blog *BaseLog) getExtraInfo() (string, int, int64, bool) {
	_, file, line, ok := runtime.Caller(2)
	if ok {
		for i := len(file) - 1; i > 0; i-- {
			if file[i] == '/' {
				file = file[i+1:]
				break
			}
		}
	}

	return file, line, time.Now().Unix(), ok
}

func (blog *BaseLog) shift() {

	if blog.shiftMode == LOG_SHIFT_BY_DAY {
		//check shift
		if blog.dateStr != common.GetDateStr() {
			log.Println("do shift, blog:", blog)

			log.Println("blog.dateStr != common.GetDateStr(): ", blog.dateStr, common.GetDateStr())

			blog.Fini()

			blog.dateStr = common.GetDateStr()
			newFile := blog.prefix + "_" + blog.dateStr

			blog.fileName = newFile

			var err error
			blog.logFile, err = os.OpenFile(blog.fileName, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
			if err != nil {
				log.Println("got error: %s\r\n", err.Error())
				blog.logFile.Close()
				os.Exit(-1)
			}

			//blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp(), log.Ldate|log.Ltime)
			blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp(), 0)

			log.Println("finish do shift, blog:", blog)
		} else {
			//check file exist
			_, err := os.Stat(blog.fileName)
			if err != nil {
				log.Println("stat error, err:", err, blog.fileName)

				blog.Fini()

				var err error
				blog.logFile, err = os.OpenFile(blog.fileName, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
				if err != nil {
					log.Println("got error: %s\r\n", err.Error())
					blog.logFile.Close()
					os.Exit(-1)
				}

				blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp(), 0)
			}
		}
	} else if blog.shiftMode == LOG_SHIFT_BY_SIZE {
		fi, err := os.Stat(blog.fileName)
		if err != nil || fi.Size() >= (int64)(blog.maxSize*1024) {
			log.Println("do shift, blog:", blog)

			blog.Fini()

			os.Remove(blog.fileName)

			var err error
			blog.logFile, err = os.OpenFile(blog.fileName, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
			if err != nil {
				log.Println("got error: %s\r\n", err.Error())
				blog.logFile.Close()
				os.Exit(-1)
			}

			blog.crawlerLogger = log.New(blog.logFile, common.GetLocalIp(), 0)
		}
	}
}

func (blog *BaseLog) dlog(v string) {
	//TODO: add data to local buffer, then batch flush to disk

	//check shift
	blog.shift()

	//write
	blog.crawlerLogger.Println(v)
}
