package crawlerlog

import (
	"crawler/post/common"
	"log"
	"os"
)

type CrawlerLog struct {
	RollLogger      *BaseLog //roll logger
	StatLogger     *BaseLog //captcha stat logger
	PostStatLogger *BaseLog //all stat logger except captcha
}

var crawlerLogInstance *CrawlerLog

func NewCrawlerLog(dayLogName string, statLogName string, postLogName string) *CrawlerLog {
	if dayLogName == "" || statLogName == "" || postLogName == ""{
		log.Fatalln("dayLogName or statLogName is not valid.", dayLogName, statLogName, postLogName)
	}

	clog := CrawlerLog{}

	os.Mkdir("/data/crawler/log/", os.FileMode(0777))

	clog.RollLogger = NewBaseLog(dayLogName, LOG_SHIFT_BY_SIZE, 500*1024, LOG_FATAL|LOG_ERROR|LOG_INFO)
	clog.StatLogger = NewBaseLog(statLogName, LOG_SHIFT_BY_DAY, 0, LOG_FATAL|LOG_ERROR|LOG_INFO)
	clog.PostStatLogger = NewBaseLog(postLogName, LOG_SHIFT_BY_DAY, 0, LOG_FATAL|LOG_ERROR|LOG_INFO)

	return &clog
}

func CrawlerLogInstance() *CrawlerLog {
	if crawlerLogInstance == nil {
		crawlerLogInstance = NewCrawlerLog(common.PostdlConfigInstance().DayLog, common.PostdlConfigInstance().StatLog, common.PostdlConfigInstance().PostStatLog)
	}

	return crawlerLogInstance
}
