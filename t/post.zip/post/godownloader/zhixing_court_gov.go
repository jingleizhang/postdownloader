package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"fmt"
	"github.com/moovweb/gokogiri"
	"io/ioutil"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

const (
	COURT_GOV_URL        = "http://zhixing.court.gov.cn/search/search"
	COURT_GOV_DETAIL_URL = "http://zhixing.court.gov.cn/search/detail?id="
	COURT_GOV_URL_CAP    = "http://zhixing.court.gov.cn/search/security/jcaptcha.jpg?59"
)

type ZhiXingCourt struct {
	CourtBase
	zhixing_gov_url    string
	zhixing_detail_url string
}

func NewZhiXingCourt(index string, detail_url string, refer string, origin string, host string, ms int, gclient *graphite.Client) *ZhiXingCourt {
	court := ZhiXingCourt{}

	court.zhixing_gov_url = index
	court.zhixing_detail_url = detail_url
	court.Refer = refer
	court.Origin = origin
	court.Host = host
	court.Sleepms = ms
	court.MetricSender = gclient

	return &court
}

func SaveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func getCourtInfoById(detailID string, down *DownloadUtil) (string, string) {
	var status int
	var html, resp string
	url := COURT_GOV_DETAIL_URL + detailID

	//先去rtd查
	rtd := down.GetRtDownloaderAddr()
	status, html, _, resp = down.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)

	if status == 200 && len(html) > 20 {
		return html, resp
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, resp = down.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html, resp
		} else {
			return "", ""
		}
	}
}

func extractGotoPage(data string) int {
	start := strings.Index(data, "gotoPage(")
	end := strings.Index(data, ")")

	if start >= 0 && end >= 0 {
		ret, _ := strconv.Atoi(data[start+len("gotoPage(") : end])
		return ret
	}
	return 0
}

//input:
//	pname
//	pcid
// pagestart: start from 1
//output:
//	[]string: json
//	int: totalpages
func ExtractCourtByPage(pname string, pcid string, pagestart int, captcha string, gclient *graphite.Client) ([]string, int, []string) {
	var parray []string
	var resparray []string
	totalpages := 0
	sleepms := 50

	url := COURT_GOV_URL
	extheaders := make(map[string]string)
	extheaders["Referer"] = "http://zhixing.court.gov.cn/search/"
	extheaders["Origin"] = "http://zhixing.court.gov.cn"
	extheaders["Host"] = "zhixing.court.gov.cn"

	postdata := make(map[string]string)
	postdata["searchCourtName"] = "全国法院（包含地方各级法院）"
	postdata["currentPage"] = strconv.Itoa(pagestart)
	postdata["selectCourtId"] = "1"
	postdata["selectCourtArrange"] = "1"
	postdata["pname"] = pname
	postdata["cardNum"] = pcid
	if pagestart == 1 {
		postdata["j_captcha"] = captcha
	}

	downUtil := NewDownloadUtil(gclient)
	if pname != "" {
		downUtil.QueryWords = append(downUtil.QueryWords, pname)
	}
	if pcid != "" {
		downUtil.QueryWords = append(downUtil.QueryWords, pcid)
	}

	status, html, _, _ := downUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil, true)
	if status == 200 && len(html) > 50 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error: %s", err.Error())
			return parray, totalpages, resparray
		}

		//extract id
		nodeArr, err := doc.Search("//a/@id")
		if err != nil || len(nodeArr) == 0 {
			return parray, totalpages, resparray
		}

		for _, node := range nodeArr {
			if len(node.String()) > 0 {
				pjson, resp := getCourtInfoById(node.String(), downUtil)
				parray = append(parray, pjson)
				resparray = append(resparray, resp)

				if sleepms > 0 {
					time.Sleep(time.Duration(sleepms) * time.Millisecond)
				}
			}
		}

		//extract total page
		nodeArr, err = doc.Search("//a/@onclick")
		if err != nil {
			return parray, totalpages, resparray
		}
		if len(nodeArr) > 0 {
			totalpages = extractGotoPage(nodeArr[len(nodeArr)-1].String())
		}

	} 

	return parray, totalpages, resparray
}

//input:
//	pname
//	pcid
//output:
//	string: json array
func ExtractCourtGov(pname string, pcid string, metricSender *graphite.Client) (palldata []string, resparray []string) {
	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do ExtractCourtGov|%s|%s", pname, pcid)

		startpage := 1

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do startpage|%s|%s|%d", pname, pcid, startpage)

		//取验证码
		downUtil := NewDownloadUtil(metricSender)
		result, cookies, imgStr, duration := downUtil.Post2Captha(COURT_GOV_URL_CAP, nil)
		if result == nil || cookies == nil {
			log.Println("fatal error, result or cookie is nil.")
			continue
		}

		for ir, r := range *result {
			parray, endpage, rarray := ExtractCourtByPage(pname, pcid, startpage, r.Label, metricSender)
			for _, strjson := range parray {
				palldata = append(palldata, strjson)
			}
			for _, resp := range rarray {
				resparray = append(resparray, resp)
			}

			//只爬第一页
			endpage = 1

			for endpage > startpage {
				startpage++

				crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("startpage and endpage|%s|%s|%d|%d", pname, pcid, startpage, endpage)

				parray2, _, resparray2 := ExtractCourtByPage(pname, pcid, startpage, r.Label, metricSender)
				for _, v := range parray2 {
					palldata = append(palldata, v)
				}
				for _, v := range resparray2 {
					resparray = append(resparray, v)
				}
			}

			//save img to disk
			SaveCaptchaSample(imgStr, COURT_GOV_URL_CAP, ir, len(*result), duration, r.Label)

			return palldata, resparray
		}
	}
	return palldata, resparray
}
