package godownloader

import (
	//"fmt"
	//"net/http"
	"testing"
)

func TestParseStateConf(t *testing.T) {
	queryMap := make(map[string]string)
	queryMap["姓名"] = "上海苏商"
	queryMap["电话"] = "12345678"

//	postdl := NewPostDownloader()
//	lenPostConf, lenMetaConf := postdl.initPostConfJson()
//
//	if lenPostConf == 0 || lenMetaConf == 0 {
//		t.Error("postCrawlerConf:\n", postdl.postCrawlerConf, "postMetaConf:\n", postdl.postMetaConf)
//	}
//
//	stateArray := ParseStateConf(&queryMap, postdl.postMetaConf, postdl.postCrawlerConf)
//	fmt.Println("len(stateArray):", len(*stateArray))
//
//	StateExecute(stateArray)
//	
//	if len(*stateArray)== 0 {
//		t.Error(stateArray)
//	}
}
