package godownloader

import (
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const (
	SGS_GOV_URL        = "http://www.sgs.gov.cn/lz/etpsInfo.do?method=doSearch"
	SGS_GOV_DETAIL_URL = "http://www.sgs.gov.cn/lz/etpsInfo.do?method=viewDetail"
)

type ShangHaiAIC struct {
	AICBase
}

func NewShangHaiAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ShangHaiAIC {
	aic := ShangHaiAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ShangHaiAIC) extractGSId(data string) string {
	start := strings.Index(data, "viewDetail('")
	end := strings.Index(data, "')")

	if start >= 0 && end >= 0 {
		return data[start+len("viewDetail('") : end]
	}

	return ""
}

func (aic *ShangHaiAIC) getGSInfoById(gsid string, curcookie []*http.Cookie) (string, string) {
	url := SGS_GOV_DETAIL_URL
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["etpsId"] = gsid

	status, html, _, respinfo := aic.DownUtil.PostHttp(url, extheaders, postdata, nil, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	return html, respinfo
}

func (aic *ShangHaiAIC) ExtractSHGSByPage(pname string, pcid string, pagestart int) (parray []string, totalpages int, resparray []string) {
	totalpages = 0

	url := SGS_GOV_URL
	postdata := make(map[string]string)
	if len(pname) > 0 {
		postdata["searchType"] = "1"
		postdata["keyWords"] = pname
		postdata["period"] = pname
		postdata["pageNo"] = strconv.Itoa(pagestart)
	} else {
		postdata["searchType"] = "2"
		postdata["keyWords"] = pcid
		postdata["period"] = pcid
		postdata["pageNo"] = strconv.Itoa(pagestart)
	}

	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	status, html, curCookies, _ := aic.DownUtil.PostHttp(url, extheaders, postdata, nil, true)
	if status == 200 && len(html) > 50 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			return parray, totalpages, resparray
		}

		//extract id
		nodeArr, err := doc.Search("//a/@onclick")
		if err != nil || len(nodeArr) == 0 {
			return parray, totalpages, resparray
		}

		for _, node := range nodeArr {
			if len(node.String()) > 0 {
				detailhtml, resp := aic.getGSInfoById(aic.extractGSId(node.String()), curCookies)

				resparray = append(resparray, resp)
				parray = append(parray, detailhtml)

				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
				}
			}
		}

		//extract total page
		nodeArr, err = doc.Search("//a")

		if err != nil || len(nodeArr) == 0 {
			return parray, totalpages, resparray
		}

		var countsdata []string
		for _, node := range nodeArr {
			if strings.Index(node.String(), "javascript:do_submit") > 0 {
				countsdata = append(countsdata, node.String())
			}
		}

		if len(countsdata) > 0 {
			countstr := countsdata[len(countsdata)-1]
			start := strings.Index(countstr, "javascript:do_submit(")
			end := strings.Index(countstr, ")")

			if start >= 0 && end >= 0 {
				ret, _ := strconv.Atoi(countstr[start+len("javascript:do_submit(") : end])
				totalpages = ret
			}
		}
	}
	return parray, totalpages, resparray
}

func (aic *ShangHaiAIC) ExtractSHGSGov(pname string, pcid string) ([]string, []string) {
	var htmlarray []string
	var resparray []string

	startpage := 1

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do ExtractSHGSGov aic|%s|%s", pname, pcid)

	if pname != "" {
		aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)
	}
	if pcid != "" {
		aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pcid)
	}

	aic.SetStatusStart()

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("startpage|%s|%s|%d", pname, pcid, startpage)

	parray, endpage, resp := aic.ExtractSHGSByPage(pname, pcid, startpage)
	for _, strhtml := range parray {
		htmlarray = append(htmlarray, strhtml)
	}
	for _, respinfo := range resp {
		resparray = append(resparray, respinfo)
	}

	for endpage > startpage {
		startpage++

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("startpage and endpage|%s|%s|%d|%d", pname, pcid, startpage, endpage)

		parray2, _, resp2 := aic.ExtractSHGSByPage(pname, pcid, startpage)
		for _, strjson := range parray2 {
			htmlarray = append(htmlarray, strjson)
		}
		for _, respinfo := range resp2 {
			resparray = append(resparray, respinfo)
		}

	}

	return htmlarray, resparray
}
