package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	//"log"
	"strings"
	"time"
)

type NeiMengGuAIC struct {
	AICBase
}

func NewNeiMengGuAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *NeiMengGuAIC {
	aic := NeiMengGuAIC{}
	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *NeiMengGuAIC) extractCreditID(data string) string {
	var start int
	var newdata string
	start = -1
	if strings.Contains(data, "GSpublicity") {
		start = strings.Index(data, "href=\"../")

		end := strings.Index(data, "\" target=")

		if start >= 0 && end >= 0 {
			newdata = data[start+len("href=\"../") : end]
		}
	} else {
		start = strings.Index(data, "href=\"")

		end := strings.Index(data, "\" target=")

		if start >= 0 && end >= 0 {
			newdata = data[start+len("href=\"") : end]
		}
	}

	return newdata
}

func (aic *NeiMengGuAIC) getNMGInfoById(suburl string) (string, string) {
	if strings.Contains(suburl, "&amp;") {
		suburl = strings.Replace(suburl, "&amp;", "&", -1)
	}

	var url string
	if strings.Contains(suburl, "GSpublicity") {
		url = aic.Ecps_index + suburl
	} else {
		url = suburl
	}

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html, respinfo
	} else {
		//再用本地ip查
		status, html, _, respinfo = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html, respinfo
		}
	}
	return "", ""
}

func (aic *NeiMengGuAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {

	//刷首页
	//aic.DownUtil.GetHttpRequestByUrl(aic.Ecps_index, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试n次
	for i := 0; i < 10; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract NMG aic|%s|%s", pname, aic.Ecps_index)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_detail
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["textfield"] = pname
			postdata["code"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
				continue
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aic.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "GSpublicity") || strings.Contains(node.String(), "entityShow") || strings.Contains(node.String(), "GSZJGSPT") {
							html, respinfo := aic.getNMGInfoById(aic.extractCreditID(node.String()))

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aic.SleepMS > 0 {
								time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aic.Ecps_cap), len(*result))
	}

	return palldata, resparray
}
