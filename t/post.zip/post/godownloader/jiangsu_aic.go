package godownloader

import (
	//"bytes"
	//"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	//"io/ioutil"
	//"log"
	"net/http"
	//"net/url"
	"strings"
	"time"
)

type JiangSuDetail struct {
	suburl string
	org    string
	id     string
	seq    string
}

type JiangSuAIC struct {
	AICBase
}

func NewJiangSuAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *JiangSuAIC {
	aic := JiangSuAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

//func (aic *JiangSuAIC) postHTTP(hosturl string, extheaders map[string]string, postdata map[string]string,
//	reqcookie []*http.Cookie, needConvert bool) (int, string, []*http.Cookie, string) {
//
//	status := 500
//	var respcookie []*http.Cookie = nil
//	var respinfo string
//	var postbody string
//
//	for k, v := range postdata {
//		postbody += ("&" + k + "=" + v)
//	}
//
//	params := url.Values{}
//	for key, value := range postdata {
//		params.Set(key, value)
//	}
//
//	client := &http.Client{
//		Transport: &http.Transport{
//			Dial:                  dialTimeout,
//			DisableKeepAlives:     true,
//			ResponseHeaderTimeout: time.Duration(60) * time.Second,
//		},
//	}
//
//	postDataStr := params.Encode()
//	postDataBytes := []byte(postDataStr)
//	reqest, _ := http.NewRequest("POST", hosturl, bytes.NewReader(postDataBytes))
//
//	reqest.Header.Set("Accept", HEADER_ACCEPT)
//	reqest.Header.Set("Accept-Encoding", HEADER_ACCEPT_ENCODE)
//	reqest.Header.Set("User-Agent", HEADER_UA)
//	reqest.Header.Set("Content-Type", HEADER_CONTENT_TYPE)
//
//	for header, value := range extheaders {
//		reqest.Header.Set(header, value)
//	}
//
//	if reqcookie != nil {
//		for _, ck := range reqcookie {
//			reqest.AddCookie(ck)
//		}
//	}
//
//	startTime := time.Now().UnixNano()
//
//	//set status via query word
//	var strQueryWord string
//	for _, v := range aic.DownUtil.QueryWords {
//		strQueryWord += GetUrlEncode(v)
//	}
//	setStatus(strQueryWord, "post-downloader.http_req."+common.ExtractDomainOnly(hosturl))
//	crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req|%s|%s|POST", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl))
//
//	response, err := client.Do(reqest)
//
//	if err != nil {
//		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got error|%s", err.Error())
//		setStatus(strQueryWord, "post-downloader.http_req_fail."+common.ExtractDomainOnly(hosturl))
//		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_fail|%s|%s|POST", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl))
//
//	} else {
//		defer func() {
//			if response != nil && response.Body != nil {
//				response.Body.Close()
//			}
//		}()
//
//		if response.StatusCode == 200 {
//
//			downDuration := int64((time.Now().UnixNano() - startTime) / 1000000) //毫秒
//
//			setStatus(strQueryWord, "post-downloader.http_req_succ."+common.ExtractDomainOnly(hosturl))
//			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_succ|%s|%s|POST", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl))
//			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|download_time|%s|%s|POST|%d", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(statem.url), downDuration)
//
//			status = response.StatusCode
//			//get cookie
//			respcookie = response.Cookies()
//
//			//build respinfo
//			respinfo = "<real_url>POST:" + aic.filterRealURL(hosturl) + postbody + "</real_url>"
//			var strQueryWords string
//			for _, v := range aic.DownUtil.QueryWords {
//				strQueryWords += GetUrlEncode(v)
//			}
//			respinfo += "<query>" + strQueryWords + "</query>"
//			respinfo += "<content_type>" + response.Header.Get("Content-Type") + "</content_type>"
//
//			html, err := ioutil.ReadAll(response.Body)
//			if needConvert {
//				cleaner := NewHTMLCleaner()
//
//				if err != nil {
//					crawlerlog.CrawlerLogInstance().RollLogger.DLogError("ReadAll got error|%s", err.Error())
//				} else {
//					utf8Html := cleaner.ToUTF8(html)
//					if utf8Html == nil {
//
//						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, conver to utf8 error|%s", hosturl)
//
//						return status, "", respcookie, respinfo
//					}
//
//					cleanHtml := cleaner.CleanHTML(utf8Html)
//					return status, string(cleanHtml), respcookie, respinfo
//				}
//			} else {
//				return status, string(html), respcookie, respinfo
//			}
//
//		} else {
//			status = response.StatusCode
//		}
//	}
//
//	return status, "", respcookie, respinfo
//}

func (aic *JiangSuAIC) filterRealURL(str string) string {
	for _, v := range aic.DownUtil.RtDownloaderAddrs {
		if strings.Contains(str, v) {
			start := strings.Index(str, v)
			if start >= 0 {
				substr, err := base64.URLEncoding.DecodeString(str[start+len(v):])
				if err == nil {

					return string(substr)
				} else {
					crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, DecodeString|%s", err.Error())
					return ""
				}

			}
		}
	}

	return str
}

func (aic *JiangSuAIC) getSSID() (string, []*http.Cookie) {
	url := aic.Ecps_index
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["showRecordLine"] = "0"
	postdata["specificQuery"] = "commonQuery"
	postdata["propertiesName"] = "ssid"
	//postdata["tmp"] = "Thu Apr 24 2014 15:27:42 GMT+0800 (CST)"
	postdata["finalSSID"] = "ssid"

	status, html, cookies, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil, false)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	start := strings.Index(html, "ssid\":\"")
	end := strings.Index(html, "\"}")
	if start >= 0 && end >= 0 {
		return html[start+len("ssid\":\"") : end], cookies
	}

	return "", nil
}

func (aic *JiangSuAIC) getQueryInfo(ssid string, pname string, cookies []*http.Cookie) (int, string) {
	url := aic.Ecps_other
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["name"] = pname
	postdata["ssid"] = ssid

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, false)

	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	return status, html
}

func (aic *JiangSuAIC) getDetailArray(html string) *[]JiangSuDetail {

	var detailArray []JiangSuDetail

	doc, err := gokogiri.ParseHtml([]byte(html))

	defer doc.Free()
	if err != nil {
		return nil
	}

	nodeArr, err := doc.Search("//a")
	if err != nil || len(nodeArr) == 0 {
		return nil
	}

	for _, node := range nodeArr {
		if len(node.String()) > 0 {
			str := node.String()
			start := strings.Index(str, "queryInfor(")
			end := strings.Index(str, "')")

			str = strings.Replace(str[start+len("queryInfor("):end+1], "'", "", -1)
			tmparray := strings.Split(str, ",")

			detail := JiangSuDetail{
				suburl: tmparray[0],
				org:    tmparray[1],
				id:     tmparray[2],
				seq:    tmparray[3],
			}

			detailArray = append(detailArray, detail)
		}
	}

	return &detailArray
}

//基本信息
func (aic *JiangSuAIC) getDetailBasicInfo(detailStrc *JiangSuDetail, ssid string, cookies []*http.Cookie) string {
	detailStrc.suburl = aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["org"] = detailStrc.org
	postdata["id"] = detailStrc.id
	postdata["seq_id"] = detailStrc.seq
	postdata["ssid"] = ssid
	postdata["specificQuery"] = "basicInfo"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(detailStrc.suburl, extheaders, postdata, cookies, false)
	if status != 200 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		return ""
	}

	return html
}

//投资人信息
func (aic *JiangSuAIC) getDetailInvestInfo(detailStrc *JiangSuDetail, ssid string, cookies []*http.Cookie) string {
	detailStrc.suburl = aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["CORP_ORG"] = detailStrc.org
	postdata["CORP_ID"] = detailStrc.id
	postdata["CORP_SEQ_ID"] = detailStrc.seq
	postdata["ssid"] = ssid
	postdata["specificQuery"] = "investmentInfor"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(detailStrc.suburl, extheaders, postdata, cookies, false)
	if status != 200 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		return ""
	}

	return html
}

//主要人员信息
func (aic *JiangSuAIC) getPersonnelInfo(detailStrc *JiangSuDetail, ssid string, cookies []*http.Cookie) string {
	detailStrc.suburl = aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["CORP_ORG"] = detailStrc.org
	postdata["CORP_ID"] = detailStrc.id
	postdata["CORP_SEQ_ID"] = detailStrc.seq
	postdata["ssid"] = ssid
	postdata["specificQuery"] = "personnelInformation"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(detailStrc.suburl, extheaders, postdata, cookies, false)
	if status != 200 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		return ""
	}

	return html
}

//分支机构信息
func (aic *JiangSuAIC) getBranchInfo(detailStrc *JiangSuDetail, ssid string, cookies []*http.Cookie) string {
	detailStrc.suburl = aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["CORP_ORG"] = detailStrc.org
	postdata["CORP_ID"] = detailStrc.id
	postdata["CORP_SEQ_ID"] = detailStrc.seq
	postdata["ssid"] = ssid
	postdata["specificQuery"] = "branchOfficeInfor"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(detailStrc.suburl, extheaders, postdata, cookies, false)
	if status != 200 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		return ""
	}

	return html
}

//清算信息
func (aic *JiangSuAIC) getAccountInfo(detailStrc *JiangSuDetail, ssid string, cookies []*http.Cookie) string {
	detailStrc.suburl = "http://www.jsgsj.gov.cn:58888/ecipplatform/fipServlet.json?fipEnter=true"
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["CORP_ORG"] = detailStrc.org
	postdata["CORP_ID"] = detailStrc.id
	postdata["CORP_SEQ_ID"] = detailStrc.seq
	postdata["ssid"] = ssid
	postdata["specificQuery"] = "personnelInformation"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(detailStrc.suburl, extheaders, postdata, cookies, false)
	if status != 200 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		return ""
	}

	return html
}

func (aic *JiangSuAIC) ExtractCredit(pname string) ([]string, []string) {

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract JS aic|%s|%s", pname, aic.Ecps_index)

	var palldata []string
	var resparray []string

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//get ssid and cookie
	ssid, cookies := aic.getSSID()

	//parse query info
	status, html := aic.getQueryInfo(ssid, pname, cookies)
	if status == 200 {
		detailArray := aic.getDetailArray(html)
		if detailArray != nil {
			for j, v := range *detailArray {
				//基本信息
				basicInfo := aic.getDetailBasicInfo(&v, ssid, cookies)
				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS/5) * time.Millisecond)
				}

				//投资人信息
				investInfo := aic.getDetailInvestInfo(&v, ssid, cookies)
				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS/5) * time.Millisecond)
				}

				//主要人员信息
				personnelInfo := aic.getPersonnelInfo(&v, ssid, cookies)
				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS/5) * time.Millisecond)
				}

				//分支机构信息
				branchInfo := aic.getBranchInfo(&v, ssid, cookies)
				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS/5) * time.Millisecond)
				}

				//清算信息
				accountInfo := aic.getAccountInfo(&v, ssid, cookies)
				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS/5) * time.Millisecond)
				}

				html := "{\"basicInfo\":[" + basicInfo + "], \"investInfo\":[" + investInfo + "], \"personnelInfo\":[" + personnelInfo + "], \"branchInfo\":[" + branchInfo + "], \"accountInfo\":[" + accountInfo + "]}"

				//build respinfo
				respinfo := "<real_url>POST:" + aic.Ecps_detail + "&org=" + v.org + "&id=" + v.id + "&seq=" + v.seq + "</real_url>"
				var strQueryWords string
				for _, v := range aic.DownUtil.QueryWords {
					strQueryWords += GetUrlEncode(v)
				}
				respinfo += "<query>" + strQueryWords + "</query>"
				respinfo += "<content_type>" + "text/html;charset=utf-8" + "</content_type>"

				palldata = append(palldata, html)
				resparray = append(resparray, respinfo)

				crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", j, len(*detailArray)-1, aic.Ecps_index)
			}
		}

		return palldata, resparray

	}

	return nil, nil
}
