package godownloader

import (
	"testing"
	"fmt"
	"os"
)

func TestExtractSHGSGov(t *testing.T) {
	htmlarray, _ := ExtractSHGSGov("上海文广", "")
	
	fmt.Println("len(htmlarray):", len(htmlarray))
	
	gswriter, _ := os.Create("TestExtractSHGSGov.html")
	for _, v := range htmlarray{
		gswriter.WriteString(v)
	}
	
	gswriter.Close()
}

func TestGetGSInfoById(t *testing.T) {
	ret, _ := getGSInfoById("060000012003122900017", nil)

	if len(ret) < 20 {
		t.Error(ret)
	}
}

