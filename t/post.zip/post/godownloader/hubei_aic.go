package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

type HuBeiAIC struct {
	AICBase
}

func NewHuBeiAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *HuBeiAIC {
	aic := HuBeiAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

//func (aic *HuBeiAIC) isHBPageCorrect(str *string) bool {
//	if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "ImageReady Slices") {
//		return false
//	} else if strings.Contains(*str, "此IP今天已查询") || strings.Contains(*str, "抱歉，无数据") {
//		return false
//	} else {
//		return true
//	}
//}

func (aic *HuBeiAIC) extractHuBeiCreditId(data string) string {
	start := strings.Index(data, "showJbxx(")
	end := strings.Index(data, ")\">")

	if start >= 0 && end >= 0 {
		substr := data[start+len("showJbxx(") : end]

		tmpstr := strings.Split(substr, ",")
		if len(tmpstr) == 5 {
			return tmpstr[0][1 : len(tmpstr[0])-1]
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("eror, not valid substr:%s", substr)
		}
	}

	return ""
}

func (aic *HuBeiAIC) getHubeiCreditInfoById(url string, detailID string, cookies []*http.Cookie) (string, string) {
	var basicInfo, respInfo string

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(url+detailID, cookies, true)

	if status == 200 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			return "", ""
		}

		//extract iframe
		nodeArr, err := doc.Search("//iframe/@src")
		if err != nil {
			return "", ""
		}

		for _, node := range nodeArr {
			urlNode := aic.Ecps_index + node.String()
			status, tmpInfo, _, _ := aic.DownUtil.GetHttpRequestByUrl(urlNode, cookies, true)

			if status == 200 {
				basicInfo += tmpInfo + ","
			} else {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, getHubeiCreditInfoById status|%d", status)
			}
		}

		//build respinfo
		respInfo = "<real_url>POST:" + url + detailID + "</real_url>"
		var strQueryWord string
		for _, v := range aic.DownUtil.QueryWords {
			strQueryWord += GetUrlEncode(v)
		}
		respInfo += "<query>" + strQueryWord + "</query>"
		respInfo += "<content_type>text/html;charset=utf-8</content_type>"

		return basicInfo, respInfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, getHubeiCreditInfoById status|%d", status)
		return "", ""
	}
}

func (aic *HuBeiAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl(aic.Ecps_index, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract HUBEI aic|%s|%s", pname, aic.Ecps_index)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_other
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["selectValue"] = pname
			postdata["password"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aic.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "showJbxx") {
							str := aic.extractHuBeiCreditId(node.String())

							html, respinfo := aic.getHubeiCreditInfoById(aic.Ecps_detail, str, cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d", i, len(nodeArr)-1)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aic.SleepMS > 0 {
								time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}
			
			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aic.Ecps_cap), len(*result))
	}

	return palldata, resparray
}
