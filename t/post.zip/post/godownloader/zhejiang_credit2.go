package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

//浙江信用2
type ZheJiangCreditAic struct {
	AICBase
}

func NewZheJiangCreditAic(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ZheJiangCreditAic {
	aic := ZheJiangCreditAic{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ZheJiangCreditAic) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码错误!") || strings.Contains(*str, "页面不存在.") || strings.Contains(*str, "暂无该类信息") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func (aic *ZheJiangCreditAic) extractZJC2Code(data string) string {
	//<a onclick='javascript:parent.showCode("10301833")' target='_ablank' title='衢州市安信汽车销售有限公司'>衢州市安信汽车销售有限公司</a>

	var newdata string
	start := strings.Index(data, "showCode(\"")
	end := strings.Index(data, "\")' target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("showCode(\"") : end]
	}

	return newdata
}

func (aic *ZheJiangCreditAic) extractZJC3Detail(code string, cookies []*http.Cookie) (string, string) {
	url := aic.Ecps_index + "/zjxwqy/checkCode.jsp?test=1&id=" + code

	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		var newdata string
		start := strings.Index(html, "window.open('/zjxwqy")
		end := strings.Index(html, "'); }else if(1==3)")

		if start >= 0 && end >= 0 {
			newdata = html[start+len("window.open('") : end]

			status, html, _, respinfo = aic.DownUtil.GetHttpRequestByUrl(aic.Ecps_index+newdata, cookies, true)
			if status == 200 || len(html) > 20 {
				return html, respinfo
			} else {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got not valid status|%d|%d|%s", status, len(html), code)
			}
		}
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got not valid status|%d|%s", status, code)
	}

	return "", ""
}

func (aic *ZheJiangCreditAic) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ZheJiangCreditAic AIC|%s", pname)

	url := aic.Ecps_other + GetUrlEncode(aic.Utf8ToGb2312(pname))
	status, html, cookies, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, nil, true)

	if status == 200 && len(html) > 20 {
		if isPageCorrect(&html) {
			doc, err := gokogiri.ParseHtml([]byte(html))

			defer doc.Free()
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
			}

			//extract link
			nodeArr, err := doc.Search("//a")
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error, can not found '//a'|%s", err.Error())
			}

			for i, node := range nodeArr {
				if strings.Contains(node.String(), "parent.showCode") {

					html, respinfo = aic.extractZJC3Detail(aic.extractZJC2Code(node.String()), cookies)

					crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

					palldata = append(palldata, html)
					resparray = append(resparray, respinfo)
				} else {
					if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
						crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
					}
				}

				time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			}

			return palldata, resparray
		}
	}

	return palldata, resparray
}
