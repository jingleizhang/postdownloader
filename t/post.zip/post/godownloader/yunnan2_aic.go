package godownloader

import (
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	//"encoding/base64"
	"encoding/json"
	//"log"
	"net/http"
	"strings"
	"time"
)

type YNCreditDetai struct {
	Text string `json:"text"`
	Url  string `json:"url"`
}

type YNCreditInfo struct {
	Message string          `json:"message"`
	Data    []YNCreditDetai `json:"data"`
	Success bool            `json:"success"`
}

//云南信用
type YNCreditAIC struct {
	AICBase
}

func NewYNCreditAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *YNCreditAIC {
	aic := YNCreditAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *YNCreditAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "查无相关数据") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func (aic *YNCreditAIC) getYNCreditDetail(suburl string, cookies []*http.Cookie) (string, string) {
	url := aic.Ecps_index + suburl

	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		//log.Println(html, respinfo)
		
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	return html, respinfo
}

func (aic *YNCreditAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract YuNanCredit AIC|%s", pname)

		//刷首页
		_, _, cookies, _ := aic.DownUtil.GetHttpRequestByUrl(aic.Ecps_other, nil, true)

		result, _, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, cookies)
		if result == nil || imgStr == "" {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error, result == nil or imgStr == nil |%s", pname)
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_detail
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["bcode"] = ""
			postdata["bname"] = pname
			postdata["searchType"] = "11"
			postdata["checkCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if aic.isPageCorrect(&html) {
					var ynJson YNCreditInfo

					err := json.Unmarshal([]byte(html), &ynJson)
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got json err|%d|%s", status, err.Error())
						continue
					}

					for _, v := range ynJson.Data {
						//log.Println(v)

						html, respinfo := aic.getYNCreditDetail(v.Url, cookies)

						palldata = append(palldata, html)
						resparray = append(resparray, respinfo)

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return palldata, resparray
}
