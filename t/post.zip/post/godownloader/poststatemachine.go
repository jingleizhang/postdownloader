package godownloader

import (
	"bytes"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

const (
	METHOD_INIT   = "INIT"  //init
	METHOD_GET    = "GET"   //http get
	METHOD_POST   = "POST"  //http post
	METHOD_CAP    = "CAP"   //captcha
	METHOD_FINISH = "WRITE" //success finish
	METHOD_FAIL   = "FAIL"  //fail finish
	METHOD_END    = "END"   //fail finish
)

type WebPage struct {
	Word         *[]string
	Link         string
	Html         string
	RespInfo     string
	DownloadedAt int64 //timestamp
	Postdata     *map[string]string
}

type PostDownloadStat struct {
	metricSender *graphite.Client

	pageDownCount  map[string]int
	pageWriteCount map[string]int

	postRecvCountTotal  int
	objRecvCountTotal   int
	pageDownCountTotal  int
	pageWriteCountTotal int
	writeDuration       int64

	postRecvChan          chan int
	pageDownChan          chan string
	pageWriteChan         chan string
	pageWriteDurationChan chan int64

	currentPath   string //page path to write
	pagewriter    *os.File
	flushFileSize int
	pageChan      chan (*[]WebPage) //for page flush
}

type PostStateMachine struct {
	url             string
	method          string
	headers         map[string]string
	postdata        map[string]string //for POST
	cookies         []*http.Cookie
	state_status    int
	state_count     int
	pagetitle       string //GET or POST:
	htmlcontent     *[]string
	respcontent     *[]string
	respinfo        string
	internal_params map[string]string
	query_word      []string //对应的object entity word
	pages           map[string]string
	downUtil        *DownloadUtil
	sleepms         int

	//	currentPath     string //page path to write
	//	pagewriter      *os.File
}

func ParseStateConf(entityObj *common.EntityObject, metaConf *common.PostMetaData, postConfs *[]common.PostCrawlerConf,
	stateArray *[]PostStateMachine, metricSender *graphite.Client) {
	if entityObj == nil || metaConf == nil || postConfs == nil || stateArray == nil {
		return
	}

	if len(entityObj.EntitySet) != 1 {
		//log.Println("error, len(entityObj.EntitySet) is not 1. entityObj.EntitySet:", entityObj.EntitySet)
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, len(entityObj.EntitySet) is not 1. len|%d", len(entityObj.EntitySet))
		return
	}

	stateParamMap := make(map[string]string)
	gotStateParamMap(entityObj, metaConf, &stateParamMap)

	//reverse internal map
	internalMetaR := make(map[string]string)
	for k, v := range metaConf.InternalMeta {
		internalMetaR[v] = k
	}

	if metricSender == nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, PostStateMachine.metricSender is empty")
	}

	for _, conf := range *postConfs {
		for _, v := range conf.PostState {
			result := true
			if v.ID == 1 {
				for _, paramv := range v.Params {
					if strings.HasPrefix(paramv, "@") {
						//Check, Is it in interalMeta?
						_, ok := internalMetaR[paramv[1:]]
						if !ok {
							_, ok = stateParamMap[paramv[1:]]
							if !ok {
								result = false
								break
							}
						}
					}
				}

				if result {

					//check tag
					object := entityObj.EntitySet[0]
					shouldCrawl := false

					if object.Tag != "" {
						//如果conf没有配置keyword，对含tag的object，不会爬取
						for _, word := range conf.Keywords {
							if strings.Contains(object.Tag, word) {
								shouldCrawl = true
								break
							}
						}
					} else {
						//对于没有tag的object，在所有website爬取
						shouldCrawl = true
					}

					//log.Println("-------got object:", object, ",v:", v, ", Keywords:", conf.Keywords, ", shouldCrawl:", shouldCrawl)
					if shouldCrawl {
						statem := buildStatePlan(&conf, &v, &stateParamMap, &internalMetaR, metricSender)
						*stateArray = append(*stateArray, *statem)

						//log.Println("-------append statem:", *statem)
					}
				}
			}
		}
	}

	//log.Println("finish ParseStateConf, entityObj:", entityObj.EntitySet, ", len(stateArray):", len(*stateArray))
}

func buildStatePlan(postConf *common.PostCrawlerConf, stateConf *common.PostCrawlerState, stateParamMap *map[string]string,
	internalMetaR *map[string]string, gclient *graphite.Client) *PostStateMachine {

	statem := NewPostStateMachine(gclient)

	statem.url = stateConf.URL
	statem.method = stateConf.Method
	for k, v := range postConf.Headers {
		statem.headers[k] = v
	}
	for k, v := range postConf.Pages {
		statem.pages[k] = v
	}
	statem.state_status = 1
	statem.state_count = postConf.PostStateCount

	statem.sleepms = postConf.SleepMS

	if stateConf.Method == METHOD_POST {
		for k, v := range stateConf.Params {
			if strings.HasPrefix(v, "@") {
				//Check, Is it in interalMeta?
				_, ok := (*internalMetaR)[v[1:]]
				if ok {
					//TODO 分页
					value := "0"
					if stateConf.ID == 1 {
						value = "1"
					}
					v = value
				} else {
					v = (*stateParamMap)[v[1:]]
				}
			}
			statem.postdata[k] = v
		}
	}

	return statem
}

func gotStateParamMap(entityObj *common.EntityObject, metaConf *common.PostMetaData, stateParamMap *map[string]string) {
	for k, v := range metaConf.ExternalMeta {
		for _, obj := range (*entityObj).EntitySet {
			if obj.Type == k {
				statev, ok := (*stateParamMap)[v]
				if !ok {
					//not found
					(*stateParamMap)[v] = obj.Name
				} else {
					log.Println("fatal error: found in stateParamMap.", statev, *entityObj, metaConf.ExternalMeta, *stateParamMap)
					continue
				}
			}
		}
	}
}

func NewPostStateMachine(gclient *graphite.Client) *PostStateMachine {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	stateMachine := PostStateMachine{
		headers:         make(map[string]string),
		internal_params: make(map[string]string),
		postdata:        make(map[string]string),
		pages:           make(map[string]string),
	}

	//set default method
	stateMachine.method = METHOD_GET

	//init status
	stateMachine.state_status = 0

	//set default header
	stateMachine.headers["Accept"] = HEADER_ACCEPT
	stateMachine.headers["Accept-Encoding"] = HEADER_ACCEPT_ENCODE
	stateMachine.headers["User-Agent"] = HEADER_UA
	stateMachine.headers["Content-Type"] = HEADER_CONTENT_TYPE

	stateMachine.downUtil = NewDownloadUtil(gclient)

	return &stateMachine
}

func checkStateAllFinish(stateArray *[]PostStateMachine) bool {
	for _, v := range *stateArray {
		if v.state_status == 0 {
			panic(fmt.Errorf("fatal error, got not inited statem."))
		}

		if v.method != METHOD_END {
			return false
		}
	}

	return true
}

func (statem *PostStateMachine) GetAllQueryWords() string {
	var strQueryWord string
	for _, v := range statem.query_word {
		if !strings.Contains(v, "aic") && !strings.Contains(v, "court") && !strings.Contains(v, "query") {
			strQueryWord += v
		}
	}

	return strQueryWord
}

func (stat *PostDownloadStat) FlushPages() {
	for {
		pageArray := <-stat.pageChan

		if pageArray == nil {
			continue
		}

		for _, page := range *pageArray {
			if !utf8.ValidString(page.Link) || !utf8.ValidString(page.Html) {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error, non utf8 link or htmlpage|%s", page)
				continue
			}

			if len(page.Html) == 0 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error, len(page.Html) is 0.|%s", page.Link)
				continue
			}

			startTime := time.Now().UnixNano()

			_, err := os.Stat("./postpages/" + stat.currentPath)
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("stat error, err|%s", err.Error())
				stat.pagewriter.Close()
				stat.currentPath = "post_" + strconv.FormatInt(time.Now().UnixNano(), 10) + ".tsv"
				stat.pagewriter, _ = os.OpenFile("./postpages/"+stat.currentPath, os.O_RDWR|os.O_CREATE, 0666)
			}

			if strings.Contains(page.Link, "&amp;") {
				page.Link = strings.Replace(page.Link, "&amp;", "&", -1)
			}

			//todo: 加timer，定期close文件

			stat.pagewriter.WriteString(strconv.FormatInt(page.DownloadedAt, 10))
			stat.pagewriter.WriteString("\t")
			stat.pagewriter.WriteString(page.Link)
			stat.pagewriter.WriteString("\t")
			stat.pagewriter.WriteString(page.Html)
			stat.pagewriter.WriteString("\t")
			stat.pagewriter.WriteString(page.RespInfo)
			stat.pagewriter.WriteString("\n")

			stat.pageWriteChan <- page.Link

			stat.flushFileSize += 1

			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("flushFileSize|%d", stat.flushFileSize)

			if common.PostdlConfigInstance().WritePageFreq > 0 && stat.flushFileSize >= common.PostdlConfigInstance().WritePageFreq {
				stat.pagewriter.Close()
				stat.currentPath = "post_" + strconv.FormatInt(time.Now().UnixNano(), 10) + ".tsv"
				var err error
				stat.pagewriter, err = os.Create("./postpages/" + stat.currentPath)
				if err != nil {
					crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, FlushPages|%s", err.Error())
					os.Exit(0)
				}
				stat.flushFileSize = 0
			}

			duration := int64((time.Now().UnixNano() - startTime) / 1000000) //毫秒
			stat.pageWriteDurationChan <- duration
		}

		if len(*pageArray) > 0 {
			page := (*pageArray)[0]

			var strQueryWord, vStr string
			for _, v := range *(page.Word) {
				strQueryWord += GetUrlEncode(v)
				if !strings.Contains(v, "aic") && !strings.Contains(v, "court") && !strings.Contains(v, "query") {
					vStr += v
				}
			}
			setStatus(strQueryWord, "post-downloader.write")
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|write|%s|%s", vStr, common.ExtractDomainOnly(page.Link))
		}
	}
}

func randArray(array []PostStateMachine) []PostStateMachine {
	random := rand.New(rand.NewSource(time.Now().UnixNano()))

	lenArray := len(array)

	for i := 0; i < lenArray; i++ {
		j := random.Int() % lenArray

		if i == j {
			continue
		}

		//swap
		t := array[i]
		array[i] = array[j]
		array[j] = t
	}

	return array
}

func StateExecute(postdl *PostDownloader, gopostChan *chan common.EntityObject) {

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, graphite.New|%s", err.Error())
	}

	for {
		v := <-(*gopostChan)

		stateArray := []PostStateMachine{}
		ParseStateConf(&v, postdl.postMetaConf, postdl.postCrawlerConf, &stateArray, metricSender)

		//将stateArray的顺序随机
		rArray := randArray(stateArray)

		//set status start query
		//		for _, obj := range v.EntitySet {
		//			setStatus(GetUrlEncode(obj.Name), "post-downloader.start")
		//		}

		var strQueryWord, vStr string
		strQueryWord += "aic."
		for _, e := range v.EntitySet {
			strQueryWord += GetUrlEncode(e.Name)
			vStr += e.Name
		}
		setStatus(strQueryWord, "post-downloader.recv")
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|obj_recv|%s|%d", vStr, len(rArray))

		//process all state
		for {
			if checkStateAllFinish(&rArray) {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("all state is finish, break. len(rArray)|%d|%s", len(rArray), v)

				break
			}

			for i := range rArray {
				StateHandler(&rArray[i], postdl.postDownStat)
			}
		}
	}
}

func extractLinkRealurl(url string) string {
	start := strings.Index(url, "<real_url>")
	end := strings.Index(url, "</real_url>")

	if start >= 0 && end >= 0 {
		return url[start+len("<real_url>") : end]
	}

	return ""
}

//TODO:changeStatus

func StateHandler(stateMachine *PostStateMachine, stat *PostDownloadStat) {
	//log.Println("start process state: ", stateMachine.url, stateMachine.state_status, stateMachine.state_count, stateMachine.postdata)

	if stateMachine.state_status > stateMachine.state_count {
		//fail
		if stateMachine.method != METHOD_END {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, not METHOD_END")
			stateMachine.method = METHOD_FAIL
		}
	}

	if stateMachine.method == METHOD_GET {
		//status, html := stateMachine.downUtil.GetHttpRequest(stateMachine)
		status, html, _, _ := stateMachine.downUtil.GetHttpRequestByUrl(stateMachine.url, stateMachine.cookies, true)
		if status != 200 || len(html) < 20 {
			stateMachine.state_status = stateMachine.state_count
			stateMachine.method = METHOD_FAIL
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, not 200 OK or empty html.|%d|%s", status, html)
		} else {
			stateMachine.state_status += 1
			*(stateMachine.htmlcontent) = append(*(stateMachine.htmlcontent), html)

			if stateMachine.state_status == stateMachine.state_count-1 {
				stateMachine.method = METHOD_FINISH
			}
		}

		stateMachine.state_status += 1
		if stateMachine.state_status == stateMachine.state_count-1 {
			stateMachine.method = METHOD_FINISH
		}

	} else if stateMachine.method == METHOD_POST {
		var aic IAICExtract
		var pname string

		if strings.Contains(stateMachine.url, "zhixing.court.gov.cn") {
			//人法执行
			zxname, _ := stateMachine.postdata["pname"]
			zxcid, _ := stateMachine.postdata["cardNum"]

			stateMachine.query_word = append(stateMachine.query_word, "court.")
			if zxname != "" {
				stateMachine.query_word = append(stateMachine.query_word, zxname)
			}
			if zxcid != "" {
				stateMachine.query_word = append(stateMachine.query_word, zxcid)
			}

			var strQueryWord string
			for _, v := range stateMachine.query_word {
				strQueryWord += GetUrlEncode(v)
			}
			setStatus(strQueryWord, "post-downloader.start")
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|obj_start|%s|%s", stateMachine.GetAllQueryWords(), common.ExtractDomainOnly(stateMachine.url))

			htmlArray, respArray := ExtractCourtGov(zxname, zxcid, stat.metricSender)
			stateMachine.htmlcontent = &htmlArray
			stateMachine.respcontent = &respArray

			if len(htmlArray) > 0 {
				stat.pageDownChan <- stateMachine.url
			}

			stateMachine.state_status += 1
			if stateMachine.state_status == stateMachine.state_count-1 {
				stateMachine.method = METHOD_FINISH
			}
		} else if strings.Contains(stateMachine.url, "shixin.court.gov.cn") {
			//人法失信
			sxname, _ := stateMachine.postdata["pName"]
			sxcid, _ := stateMachine.postdata["pCardNum"]

			stateMachine.query_word = append(stateMachine.query_word, "court.")
			if sxname != "" {
				stateMachine.query_word = append(stateMachine.query_word, sxname)
			}
			if sxcid != "" {
				stateMachine.query_word = append(stateMachine.query_word, sxcid)
			}

			var strQueryWord string
			for _, v := range stateMachine.query_word {
				strQueryWord += GetUrlEncode(v)
			}
			setStatus(strQueryWord, "post-downloader.start")
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|obj_start|%s|%s", stateMachine.GetAllQueryWords(), common.ExtractDomainOnly(stateMachine.url))

			court := NewShiXinCourt(SHIXIN_GOV_URL, SHIXIN_DETAIL_URL, SHIXIN_REFER, SHIXIN_ORIGIN, SHIXIN_HOST, 100, stat.metricSender)
			htmlArray, respArray := court.ExtractCredit(sxname, sxcid)
			stateMachine.htmlcontent = &htmlArray
			stateMachine.respcontent = &respArray

			if len(htmlArray) > 0 {
				stat.pageDownChan <- stateMachine.url
			}

			stateMachine.state_status += 1
			if stateMachine.state_status == stateMachine.state_count-1 {
				stateMachine.method = METHOD_FINISH
			}
		} else if strings.Contains(stateMachine.url, "sgs.gov") {
			//上海工商
			searchType, ok := stateMachine.postdata["searchType"]
			if !ok {
				log.Println("error, can not find searchType in ", stateMachine.postdata, stateMachine.url)
			} else {
				sgsname := ""
				sgscid := ""
				if searchType == "1" {
					sgsname, _ = stateMachine.postdata["keyWords"]
				} else if searchType == "2" {
					sgscid, _ = stateMachine.postdata["keyWords"]
				}

				stateMachine.query_word = append(stateMachine.query_word, "aic.")
				if sgsname != "" {
					stateMachine.query_word = append(stateMachine.query_word, sgsname)
				}
				if sgscid != "" {
					stateMachine.query_word = append(stateMachine.query_word, sgscid)
				}

				var strQueryWord string
				for _, v := range stateMachine.query_word {
					strQueryWord += GetUrlEncode(v)
				}
				setStatus(strQueryWord, "post-downloader.start")
				crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|obj_start|%s|%s", stateMachine.GetAllQueryWords(), common.ExtractDomainOnly(stateMachine.url))

				shAIC := NewShangHaiAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
				htmlArray, resparray := shAIC.ExtractSHGSGov(sgsname, sgscid)
				stateMachine.htmlcontent = &htmlArray
				stateMachine.respcontent = &resparray

				for _, v := range shAIC.DownUtil.QueryWords {
					stateMachine.query_word = append(stateMachine.query_word, v)
				}

				if len(htmlArray) > 0 {
					stat.pageDownChan <- stateMachine.url
				}

				stateMachine.state_status += 1
				if stateMachine.state_status == stateMachine.state_count-1 {
					stateMachine.method = METHOD_FINISH
				}
			}
		} else if strings.Contains(stateMachine.url, "gxqyxygs.gov.cn") || strings.Contains(stateMachine.url, "220.182.3.99") || strings.Contains(stateMachine.url, "222.171.175.16") {
			//广西工商, 西藏工商, 黑龙江工商
			pname, _ = stateMachine.postdata["entName"]
			aic = NewAICBase(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "218.95.241.36") || strings.Contains(stateMachine.url, "222.143.24.157") || strings.Contains(stateMachine.url, "ahcredit.gov.cn") {
			//青海工商, 河南工商, 安徽工商
			pname, _ = stateMachine.postdata["entName"]
			aic = NewAICBase(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.xjaic.gov.cn") || strings.Contains(stateMachine.url, "gsxt.scaic.gov.cn") {
			//新疆工商, 四川工商
			pname, _ = stateMachine.postdata["maent.entname"]
			aic = NewXinJiangAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "218.26.1.108") {
			//山西工商
			pname, _ = stateMachine.postdata["name"]
			aic = NewShanXiAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "221.232.141.250") || strings.Contains(stateMachine.url, "gsxt.jxaic.gov.cn") {
			//湖北工商, 江西工商
			pname, _ = stateMachine.postdata["selectValue"]
			aic = NewHuBeiAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.ngsh.gov.cn") {
			//宁夏工商
			pname, _ = stateMachine.postdata["selectValue"]
			aic = NewNingXiaAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "218.57.139.24") {
			//山东工商
			pname, _ = stateMachine.postdata["param"]
			aic = NewShanDongAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "www.jsgsj.gov.cn") {
			//江苏工商
			pname, _ = stateMachine.postdata["name"]
			aic = NewJiangSuAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "qyxy.baic.gov.cn/wap") {
			//北京工商/wap
			pname, _ = stateMachine.postdata["queryStr"]
			aic = NewBeiJingAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "qyxy.baic.gov.cn/lucene") {
			//北京工商/pc
			pname, _ = stateMachine.postdata["queryStr"]
			aic = NewBeijingAIC2(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "nmgs.gov.cn") || strings.Contains(stateMachine.url, "211.141.74.198:8081") || strings.Contains(stateMachine.url, "gsxt.gdgs.gov.cn") {
			//内蒙古工商, 吉林工商, 广东工商
			pname, _ = stateMachine.postdata["textfield"]
			aic = NewNeiMengGuAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "aic.hainan.gov.cn") {
			//海南工商
			pname, _ = stateMachine.postdata["textfield"]
			aic = NewNeiMengGuAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.saic.gov.cn/zjgs") {
			//工商总局
			pname, _ = stateMachine.postdata["textfield"]
			aic = NewChinaAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsaic.gov.cn") {
			//甘肃工商
			pname, _ = stateMachine.postdata["queryVal"]
			aic = NewGanSuAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "202.98.60.118") {
			//重庆企业
			pname, _ = stateMachine.postdata["txtqy"]
			aic = NewChongQingAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "xysjpt.lncredit.gov.cn") {
			//信用辽宁
			pname, _ = stateMachine.postdata["cxnr"]
			aic = NewLiaoNingAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.hnaic.gov.cn") {
			//湖南工商
			pname, _ = stateMachine.postdata["KW"]
			aic = NewHuNanAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "hncredit.gov.cn") {
			//湖南信用
			pname, _ = stateMachine.postdata["cx_qymc"]
			aic = NewHuNanCreditAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.zjaic.gov.cn") {
			//浙江工商
			pname, _ = stateMachine.postdata["name"]
			aic = NewZJAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "gsxt.gzgs.gov.cn") {
			//贵州工商
			pname, _ = stateMachine.postdata["q"]
			aic = NewGuiZhouAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "hebscztxyxx.gov.cn") {
			//河北工商
			pname, _ = stateMachine.postdata["condition.entName"]
			aic = NewHeBeiAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "www.tjaic.gov.cn") {
			//天津工商
			pname, _ = stateMachine.postdata["qymc"]
			aic = NewTianJinAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "wsgs.fjaic.gov.cn") {
			//福建工商
			pname, _ = stateMachine.postdata["etpsName"]
			aic = NewFJAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "www.cncpsp.org.cn") {
			//云南信用
			pname, _ = stateMachine.postdata["bname"]
			aic = NewYNCreditAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "117.22.252.219") {
			//陕西工商
			pname, _ = stateMachine.postdata["entname"]
			aic = NewShaanXiAIC(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		} else if strings.Contains(stateMachine.url, "www.zjcredit.gov.cn:8090") {
			//浙江信用2
			pname, _ = stateMachine.postdata["entname"]
			aic = NewZheJiangCreditAic(stateMachine.headers, stateMachine.pages, stateMachine.url, stateMachine.sleepms, stat.metricSender)
		}

		if pname != "" {
			//	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
			//	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)
			//	stateMachine.query_word = append(stateMachine.query_word, pname)

			htmlArray, respArray := aic.ExtractCredit(pname)
			stateMachine.htmlcontent = &htmlArray
			stateMachine.respcontent = &respArray

			if len(htmlArray) > 0 {
				stat.pageDownChan <- stateMachine.url
			}

			if len(stateMachine.query_word) == 0 {
				for _, v := range aic.GetUtil().QueryWords {
					stateMachine.query_word = append(stateMachine.query_word, v)
				}
			}

			stateMachine.state_status += 1
			if stateMachine.state_status == stateMachine.state_count-1 {
				stateMachine.method = METHOD_FINISH
			}
		}

		//stateMachine.state_status += 1

		//		status, html, _ := PostHTTPRequest(stateMachine)
		//		if status != 200 || len(html) < 20 {
		//			stateMachine.state_status = stateMachine.state_count
		//			stateMachine.method = METHOD_FAIL
		//			log.Println("error, not 200 OK or empty html. ", status, html)
		//		} else {
		//			stateMachine.state_status += 1
		//			//stateMachine.htmlcontent = html
		//			*(stateMachine.htmlcontent) = append(*(stateMachine.htmlcontent), html)
		//			if stateMachine.state_status == stateMachine.state_count-1 {
		//				stateMachine.method = METHOD_FINISH
		//			}
		//		}

	} else if stateMachine.method == METHOD_FINISH {
		if len(*(stateMachine.htmlcontent)) == 0 {
			var strQueryWord string
			for _, v := range stateMachine.query_word {
				strQueryWord += GetUrlEncode(v)
			}
			setStatus(strQueryWord, "post-downloader.empty")
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|empty|%s|%s", stateMachine.GetAllQueryWords(), common.ExtractDomainOnly(stateMachine.url))
		}

		//write page
		var webPageArray []WebPage
		for i, htmlContent := range *(stateMachine.htmlcontent) {
			page := WebPage{
				Word:         &(stateMachine.query_word),
				Link:         extractLinkRealurl((*stateMachine.respcontent)[i]),
				Html:         htmlContent,
				RespInfo:     (*stateMachine.respcontent)[i],
				DownloadedAt: time.Now().Unix(),
				Postdata:     &(stateMachine.postdata)}

			webPageArray = append(webPageArray, page)
		}

		stat.pageChan <- &webPageArray

		stateMachine.state_status += 2
		stateMachine.method = METHOD_END

	} else if stateMachine.method == METHOD_FAIL {
		//1. write log
		//2. Is it necessary to restart crawler?
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", stateMachine.url)

		stateMachine.state_status += 2
		stateMachine.method = METHOD_END
	} else if stateMachine.method == METHOD_END {
		//nothing
		return
	} else {
		log.Println("fatal error: not valid method ", stateMachine.method)
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, not valid method|%s", stateMachine.method)
	}

	//log.Println("finish process state: ", stateMachine.url, stateMachine.state_status, stateMachine.state_count, stateMachine.method, stateMachine.postdata)
}

func NewPostDownloadStat() *PostDownloadStat {
	postDownStat := PostDownloadStat{
		pageDownCount:  make(map[string]int),
		pageWriteCount: make(map[string]int),

		postRecvChan:          make(chan int, 40960),
		pageDownChan:          make(chan string, 20480),
		pageWriteChan:         make(chan string, 20480),
		pageWriteDurationChan: make(chan int64, 20480),

		pageChan: make(chan *[]WebPage, 10240),
	}

	var err error
	postDownStat.metricSender, err = graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, graphite.New|%s", err.Error())
	}

	//init captcha samples dir
	os.Mkdir(common.PostdlConfigInstance().CaptchaSampleDir, os.FileMode(0777))

	//init page writer
	postDownStat.currentPath = "post_" + strconv.FormatInt(time.Now().UnixNano(), 10) + ".tsv"
	os.Mkdir("./postpages/", os.FileMode(0777))
	postDownStat.pagewriter, err = os.Create("./postpages/" + postDownStat.currentPath)
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
		os.Exit(0)
	}

	return &postDownStat
}

func (stat *PostDownloadStat) printMemStats() {
	var mem runtime.MemStats
	runtime.ReadMemStats(&mem)
	buf := bytes.NewBuffer(nil)
	buf.WriteString(strings.Repeat("=", 24) + "\n")
	buf.WriteString("Memory Profile:\n")
	buf.WriteString(fmt.Sprintf("\tAlloc: %d Kb\n", mem.Alloc/1024))
	buf.WriteString(fmt.Sprintf("\tTotalAlloc: %d Kb\n", mem.TotalAlloc/1024))
	buf.WriteString(fmt.Sprintf("\tNumGC: %d\n", mem.NumGC))
	buf.WriteString(fmt.Sprintf("\tGoroutines: %d\n", runtime.NumGoroutine()))
	buf.WriteString(strings.Repeat("=", 72))
	log.Println(buf.String())
}

func (stat *PostDownloadStat) doDownloadStat() {
	random := rand.New(rand.NewSource(time.Now().UnixNano()))

	for {
		select {
		case <-stat.postRecvChan:
			stat.postRecvCountTotal += 1

		case link := <-stat.pageDownChan:
			domain := common.ExtractMainDomain(link)
			domain = strings.Replace(domain, ".", "_", -1)
			stat.pageDownCount[domain] += 1
			stat.pageDownCountTotal += 1

		case link := <-stat.pageWriteChan:
			domain := common.ExtractMainDomain(link)
			domain = strings.Replace(domain, ".", "_", -1)
			stat.pageWriteCount[domain] += 1
			stat.pageWriteCountTotal += 1

		case stat.writeDuration = <-stat.pageWriteDurationChan:
			stat.metricSender.Timing("crawler.post-downloader."+common.GetHostName()+".pagewrite_time", stat.writeDuration, 1.0)
			stat.metricSender.Timing("crawler.post-downloader.pagewrite_time", stat.writeDuration, 1.0)
		}

		if random.Float32() < 0.1 {
			stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".postRecvCountTotal", int64(stat.postRecvCountTotal), 1.0)
			stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".objRecvCountTotal", int64(stat.objRecvCountTotal), 1.0)

			stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".pageDownCountTotal", int64(stat.pageDownCountTotal), 1.0)
			for domain, downcount := range stat.pageDownCount {
				stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".pageDownCount."+domain, int64(downcount), 1.0)
			}

			stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".pageWriteCountTotal", int64(stat.pageWriteCountTotal), 1.0)
			for domain, downcount := range stat.pageWriteCount {
				stat.metricSender.Gauge("crawler.post-downloader."+common.GetHostName()+".pageWriteCount."+domain, int64(downcount), 1.0)
			}

			stat.metricSender.Timing("crawler.post-downloader."+common.GetHostName()+".pagewrite_time", stat.writeDuration, 1.0)
			stat.metricSender.Timing("crawler.post-downloader.pagewrite_time", stat.writeDuration, 1.0)

			//stat.printMemStats()
		}
	}
}
