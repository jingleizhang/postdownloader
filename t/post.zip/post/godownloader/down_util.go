package godownloader

import (
	"bufio"
	"bytes"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"encoding/json"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

//captcha crack result
type BinaryImage struct {
	Width, Height, Size int
	Data                []byte
}

//captcha crack result
type Result struct {
	Label      string
	Weight     float64
	Components []BinaryImage
}

type DownloadUtil struct {
	MetricSender      *graphite.Client
	QueryWords        []string
	RtDownloaderAddrs []string    //for simple http get
	GoContext         *URLContext //for proxy
	UseProxy          bool        //阿里云
}

func NewDownloadUtil(gclient *graphite.Client) *DownloadUtil {
	downUtil := DownloadUtil{}

	downUtil.MetricSender = gclient
	downUtil.RtDownloaderAddrs = downUtil.GetRealtimeHttpList()
	downUtil.UseProxy = true
	rand.Seed(time.Now().UTC().UnixNano())
	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish NewDownloadUtil()")

	return &downUtil
}

func (downUtil *DownloadUtil) SetUseProxy(useProxy bool) {
	downUtil.UseProxy = useProxy
}

func (downUtil *DownloadUtil) GetRtDownloaderAddr() string {
	if len(downUtil.RtDownloaderAddrs) == 0 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, len(downUtil.RtDownloaderAddrs) is 0.")
		return ""
	}
	return downUtil.RtDownloaderAddrs[rand.Intn(len(downUtil.RtDownloaderAddrs))]
}

func (downUtil *DownloadUtil) GetAllQueryWords() string {
	var strQueryWord string
	for _, v := range downUtil.QueryWords {
		if !strings.Contains(v, "aic") && !strings.Contains(v, "court") && !strings.Contains(v, "query") {
			strQueryWord += v
		}
	}

	return strQueryWord
}

func (downUtil *DownloadUtil) GetHttpRequestByUrl(url string, cookies []*http.Cookie, needClean bool) (status int, html string, respcookie []*http.Cookie, respinfo string) {
	status = 500
	respcookie = nil

	client := &http.Client{
		//CheckRedirect: nil,
		Transport: &http.Transport{
			Dial:                  dialTimeout,
			DisableKeepAlives:     true,
			ResponseHeaderTimeout: time.Duration(common.PostdlConfigInstance().DownloadTimeout) * time.Second,
		},
	}
	reqest, _ := http.NewRequest("GET", url, nil)

	if cookies != nil {
		for _, ck := range cookies {
			reqest.AddCookie(ck)
		}
	}

	startTime := time.Now().UnixNano()

	var strQueryWord string
	for _, v := range downUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}

	setStatus(strQueryWord, "post-downloader.http_req."+common.ExtractDomainOnly(url))
	crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req|%s|%s|GET", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url))

	response, err := client.Do(reqest)

	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
		setStatus(strQueryWord, "post-downloader.http_req_fail."+common.ExtractDomainOnly(url))
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_fail|%s|%s|GET||%s", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), err.Error())

	} else {
		defer func() {
			if response != nil && response.Body != nil {
				response.Body.Close()
			}
		}()

		status = response.StatusCode
		respcookie = response.Cookies()

		if status == 200 {
			downDuration := int64((time.Now().UnixNano() - startTime) / 1000000) //毫秒
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|download_time|%s|%s|GET|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), downDuration)

			html, err := ioutil.ReadAll(response.Body)
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error: ReadAll error|%s", err.Error())
			} else {
				setStatus(strQueryWord, "post-downloader.http_req_succ."+common.ExtractDomainOnly(url))
				crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_succ|%s|%s|GET|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), len(html))

				resp := "<real_url>" + downUtil.filterRealURL(url) + "</real_url>"
				var strQueryWords string
				for _, v := range downUtil.QueryWords {
					strQueryWords += GetUrlEncode(v)
				}
				resp += "<query>" + strQueryWords + "</query>"
				resp += "<content_type>" + response.Header.Get("Content-Type") + "</content_type>"

				//log.Println(status, respcookie)

				if needClean {
					cleaner := NewHTMLCleaner()

					utf8Html := cleaner.ToUTF8(html)
					if utf8Html == nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, conver to utf8 error|%s|%d", url, needClean)
						return status, "", respcookie, ""
					}

					cleanHtml := cleaner.CleanHTML(utf8Html)

					return status, string(cleanHtml), respcookie, resp
				} else {
					return status, string(html), respcookie, resp
				}
			}
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("got status code|%d", response.StatusCode)
		}
	}

	return status, "", nil, ""
}

func (downUtil *DownloadUtil) PostHTTPRequestByUrl(hosturl string, extheaders map[string]string, postdata map[string]string,
	reqcookie []*http.Cookie, needClean bool) (int, string, []*http.Cookie, string) {
	status := 500
	var respcookie []*http.Cookie = nil
	var respinfo string
	var postbody string

	for k, v := range postdata {
		postbody += ("&" + k + "=" + v)
	}

	params := url.Values{}
	for key, value := range postdata {
		params.Set(key, value)
	}

	client := &http.Client{
		//CheckRedirect: nil,
		Transport: &http.Transport{
			Dial:                  dialTimeout,
			DisableKeepAlives:     true,
			ResponseHeaderTimeout: time.Duration(common.PostdlConfigInstance().DownloadTimeout) * time.Second,
		},
	}

	postDataStr := params.Encode()
	postDataBytes := []byte(postDataStr)
	reqest, _ := http.NewRequest("POST", hosturl, bytes.NewReader(postDataBytes))

	reqest.Header.Set("Accept", HEADER_ACCEPT)
	reqest.Header.Set("Accept-Encoding", HEADER_ACCEPT_ENCODE)
	reqest.Header.Set("User-Agent", HEADER_UA)
	reqest.Header.Set("Content-Type", HEADER_CONTENT_TYPE)

	for header, value := range extheaders {
		reqest.Header.Set(header, value)
	}

	if reqcookie != nil {
		for _, ck := range reqcookie {
			reqest.AddCookie(ck)
		}
	}

	startTime := time.Now().UnixNano()

	//set status via query word
	var strQueryWord string
	for _, v := range downUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	setStatus(strQueryWord, "post-downloader.http_req."+common.ExtractDomainOnly(hosturl))
	crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req|%s|%s|POST", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl))

	response, err := client.Do(reqest)

	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error|%s", err.Error())
		setStatus(strQueryWord, "post-downloader.http_req_fail."+common.ExtractDomainOnly(hosturl))
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_fail|%s|%s|POST|%s", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl), err.Error())

	} else {
		defer func() {
			if response != nil && response.Body != nil {
				response.Body.Close()
			}
		}()

		if response.StatusCode == 200 {

			downDuration := int64((time.Now().UnixNano() - startTime) / 1000000) //毫秒
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|download_time|%s|%s|POST|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl), downDuration)

			setStatus(strQueryWord, "post-downloader.http_req_succ."+common.ExtractDomainOnly(hosturl))
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|http_req_succ|%s|%s|POST", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(hosturl))

			status = response.StatusCode
			//get cookie
			respcookie = response.Cookies()

			cleaner := NewHTMLCleaner()
			html, err := ioutil.ReadAll(response.Body)
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got ReadAll error|%s", err.Error())
			} else {
				//build respinfo
				respinfo = "<real_url>POST:" + downUtil.filterRealURL(hosturl) + postbody + "</real_url>"
				var strQueryWords string
				for _, v := range downUtil.QueryWords {
					strQueryWords += GetUrlEncode(v)
				}
				respinfo += "<query>" + strQueryWords + "</query>"
				respinfo += "<content_type>" + response.Header.Get("Content-Type") + "</content_type>"

				if needClean {
					utf8Html := cleaner.ToUTF8(html)
					if utf8Html == nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, conver to utf8 error|%s", hosturl)

						return status, "", respcookie, respinfo
					}

					cleanHtml := cleaner.CleanHTML(utf8Html)
					return status, string(cleanHtml), respcookie, respinfo
				} else {
					return status, string(html), respcookie, respinfo
				}
			}
		} else {
			status = response.StatusCode
			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("got status code|%d|%s", response.StatusCode, hosturl)
		}
	}

	return status, "", respcookie, respinfo
}

//刷验证码
func (downUtil *DownloadUtil) Post2Captha(url string, reqCookies []*http.Cookie) (*[]Result, []*http.Cookie, string, int64) {
	output := []Result{}
	var duration int64 //验证码服务的耗时, ms

	//get random captcha_service host
	random := rand.New(rand.NewSource(time.Now().UnixNano()))
	tmpServiceArray := strings.Split(common.PostdlConfigInstance().CapConfHost, ";")
	captchaServiceStr := tmpServiceArray[random.Int()%len(tmpServiceArray)]

	crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_start|%s", common.ExtractDomainOnly(url))
	crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_start|%s|%s", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url))

	status, imgstr, cookies, respinfo := downUtil.GetHttpRequestByUrl(url, reqCookies, false)

	if status == 200 && len(imgstr) > 10 {
		//for debug
		//		os.Remove("1.png")
		//		writer, err := os.Create("1.png")
		//		if err != nil {
		//			log.Println(err)
		//			return nil, nil, "", 0
		//		}
		//		writer.Write([]byte(imgstr))
		//		writer.Close()

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_req_start|%s", common.ExtractDomainOnly(captchaServiceStr))
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_req_start|%s|%s|%s", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr))

		captchaStartTime := time.Now().UnixNano()

		imgformatStr := "png"
		if strings.Contains(respinfo, "jpg") || strings.Contains(respinfo, "jpeg") {
			imgformatStr = "jpg"
		} else if strings.Contains(respinfo, "gif") {
			imgformatStr = "gif"
		} else if strings.Contains(respinfo, "bmp") {
			imgformatStr = "bmp"
		}

		//get cracked captcha in json
		headers := make(map[string]string)
		postdata := make(map[string]string)
		postdata["img"] = imgstr
		postdata["format"] = "json"
		postdata["link"] = url
		postdata["imgformat"] = imgformatStr

		status, html, _, _ := downUtil.PostHTTPRequestByUrl(captchaServiceStr, headers, postdata, nil, false)

		//metric response time
		duration = int64((time.Now().UnixNano() - captchaStartTime) / 1000000) //毫秒
		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_response_time|%s|%s|%d", common.ExtractDomainOnly(captchaServiceStr), common.ExtractDomainOnly(url), duration)
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_response_time|%s|%s|%s|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr), duration)

		if status != 200 {
			crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_req_fail|%s|%d", common.ExtractDomainOnly(captchaServiceStr), status)
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_req_fail|%s|%s|%s|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr), status)

			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, got status code|%d|%s", status, captchaServiceStr)

			return nil, nil, imgstr, duration
		}

		jsonerr := json.Unmarshal([]byte(html), &output)
		if jsonerr != nil {
			log.Println("got json error:", jsonerr, ", html:", html, ", urL:", url)
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("json error|%s", jsonerr)

			crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_req_fail|%s|%s", common.ExtractDomainOnly(captchaServiceStr), jsonerr)
			crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_req_fail|%s|%s|%s|%s", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr), jsonerr)
			return nil, nil, imgstr, duration
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_req_succ|%s|%d", common.ExtractDomainOnly(captchaServiceStr), len(output))
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_req_succ|%s|%s|%s|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr), len(output))

		return &output, cookies, imgstr, duration
	} else {
		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_fail|%s|%d", common.ExtractDomainOnly(url), status)
		crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|ocr_fail|%s|%s|%s|%d", downUtil.GetAllQueryWords(), common.ExtractDomainOnly(url), common.ExtractDomainOnly(captchaServiceStr), status)

		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error to get Captcha, status code|%d|%d|%s", status, len(imgstr), url)
	}

	return nil, nil, imgstr, duration
}

func GetUrlEncode(str string) string {
	newstr := "http://127.0.0.1/?a=" + str
	newurl, err := url.Parse(newstr)
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got encoder error|%s", err.Error())
		return ""
	}

	newquery := newurl.Query().Encode()
	start := strings.Index(newquery, "=")
	if start > 0 {
		newstr = newquery[start+1:]
	} else {
		newstr = ""
	}

	//newstr := base64.URLEncoding.EncodeToString([]byte(str))
	return newstr
}

func (downUtil *DownloadUtil) getCreditInfoById(url string, detailID string) (string, string) {
	var status int
	var html, respinfo string

	//先去rtd查
	rtd := downUtil.GetRtDownloaderAddr()
	status, html, _, respinfo = downUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url+detailID)), nil, true)
	if status == 200 && len(html) > 20 {
		return html, respinfo
	} else {
		//再用本地ip查
		status, html, _, respinfo = downUtil.GetHttpRequestByUrl(url+detailID, nil, true)
		if status == 200 {
			return html, respinfo
		} else {
			return "", ""
		}
	}
}

//去掉real time downloader的前缀
func (downUtil *DownloadUtil) filterRealURL(str string) string {
	for _, v := range downUtil.RtDownloaderAddrs {
		if strings.Contains(str, v) {
			start := strings.Index(str, v)
			if start >= 0 {
				linkbyte, err := base64.URLEncoding.DecodeString(str[start+len(v):])

				if err == nil {
					return string(linkbyte)
				} else {
					return ""
				}
			}
		}
	}

	return str
}

func (downUtil *DownloadUtil) GetRealtimeHttpList() []string {
	ret := []string{}
	f, err := os.Open(RTHTTP_FILE)
	if err == nil {
		r := bufio.NewReader(f)
		for {
			line, err := r.ReadString('\n')
			if err != nil {
				break
			}
			line = strings.Trim(line, "\n")
			ret = append(ret, line)
		}
	} else {
		log.Println("open realtime_downloader.list got error:", err)
		return ret
	}

	defer f.Close()
	return ret
}

func (downUtil *DownloadUtil) doRTDRequest() (int, string, []http.Cookie, string) {
	if downUtil.GoContext != nil {
		rtd, ok := downUtil.GoContext.GetRtdAddr()
		if ok {
			var buff bytes.Buffer
			//encode context
			buff = EncodeContext(*(downUtil.GoContext))

			postProxy := make(map[string]string)
			postProxy["type"] = "goproxy"
			postProxy["context"] = buff.String()

			log.Println("doRequest(), rtd:", rtd)
			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("doRequest(), rtd|%s", rtd)

			status, html, _, _ := downUtil.PostHTTPRequestByUrl(rtd, nil, postProxy, nil, false)
			if status == 200 && len(html) > 10 {
				//decode context
				var newbuff bytes.Buffer
				newbuff.WriteString(html)
				context := DecodeContext(newbuff)

				return context.Status, context.Html, context.CookiesResp, context.Respinfo
			} else {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, GetRtdAddr() error.")
		}
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error, downUtil.GoContext is empty.")
	}

	return 500, "", nil, ""
}

func (downUtil *DownloadUtil) DoProxyGet(url string, headers map[string]string, postdata map[string]string, cookies []*http.Cookie, convert2UTF8 bool) (int, string, []*http.Cookie, string) {
	downUtil.GoContext = NewURLContext(url, METHOD_GET, DEFAULT_TIMEOUT, headers, postdata, cookies, convert2UTF8)
	status, html, cookiesResp, respInfo := downUtil.doRTDRequest()

	var cookiesArray []*http.Cookie
	for _, v := range cookiesResp {
		cookiesArray = append(cookiesArray, &v)
	}
	return status, html, cookiesArray, respInfo
}

func (downUtil *DownloadUtil) DoProxyPost(url string, headers map[string]string, postdata map[string]string, cookies []*http.Cookie, convert2UTF8 bool) (int, string, []*http.Cookie, string) {
	downUtil.GoContext = NewURLContext(url, METHOD_POST, DEFAULT_TIMEOUT, headers, postdata, cookies, convert2UTF8)
	status, html, cookiesResp, respInfo := downUtil.doRTDRequest()

	var cookiesArray []*http.Cookie
	for _, v := range cookiesResp {
		cookiesArray = append(cookiesArray, &v)
	}
	return status, html, cookiesArray, respInfo
}

func (downUtil *DownloadUtil) GetHttp(url string, headers map[string]string, postdata map[string]string, cookies []*http.Cookie, convert2UTF8 bool) (int, string, []*http.Cookie, string) {
	var status int
	var html, respinfo string
	var respCookies []*http.Cookie

	if downUtil.UseProxy {
		status, html, respCookies, respinfo = downUtil.DoProxyGet(url, headers, postdata, cookies, convert2UTF8)
		if status == 200 {
			return status, html, respCookies, respinfo
		}
	}

	//如果UseProxy是true, 且proxy失败
	status, html, respCookies, respinfo = downUtil.GetHttpRequestByUrl(url, cookies, convert2UTF8)
	return status, html, respCookies, respinfo
}

func (downUtil *DownloadUtil) PostHttp(url string, headers map[string]string, postdata map[string]string, cookies []*http.Cookie, convert2UTF8 bool) (int, string, []*http.Cookie, string) {
	var status int
	var html, respinfo string
	var respCookies []*http.Cookie

	if downUtil.UseProxy {

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("start DoProxyPost()|%s", url)

		status, html, respCookies, respinfo = downUtil.DoProxyPost(url, headers, postdata, cookies, convert2UTF8)
		if status == 200 {
			return status, html, respCookies, respinfo
		}
	}

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("start PostHTTPRequestByUrl()|%s", url)
	status, html, respCookies, respinfo = downUtil.PostHTTPRequestByUrl(url, headers, postdata, cookies, convert2UTF8)
	
	log.Println(status, html, respCookies, respinfo)
	
	return status, html, respCookies, respinfo
}
