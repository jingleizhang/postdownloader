package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

type ShanDongAIC struct {
	AICBase
}

func NewShanDongAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ShanDongAIC {
	aic := ShanDongAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ShanDongAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "<font color=\"red\"> 验证码输入错误 </font>") {
		return false
	} else {
		return true
	}
}

func (aic *ShanDongAIC) extractSDSubUrl(data string) string {
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		//input:
		//	/shandong/gsjbxx?pripid=370522001011992112692408&enttype=3100
		tmpstr := strings.Split(data[start+len("href=\""):end], "?")
		if len(tmpstr) == 2 {
			return tmpstr[1]
		}
	}

	return ""
}

//基本信息
func (aic *ShanDongAIC) getBasicInfo(suburl string, cookies []*http.Cookie) string {
	url := aic.Ecps_index + "/shandong/gsjbxx?" + suburl

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()
	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

//企业公示信息
func (aic *ShanDongAIC) getCorpPubInfo(suburl string, cookies []*http.Cookie) string {
	url := aic.Ecps_index + "/shandong/qygsAction?" + suburl

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()
	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanDongAIC) getSDAsicInfo(suburl string, cookies []*http.Cookie) (string, string) {
	var html, respinfo string

	basicInfo := aic.getBasicInfo(suburl, cookies)
	corpPubInfo := aic.getCorpPubInfo(suburl, cookies)

	html = basicInfo + "," + corpPubInfo

	respinfo = "<real_url>POST:" + aic.Ecps_index + "/shandong/gsjbxx?" + suburl + "</real_url>"
	var strQueryWord string
	for _, v := range aic.DownUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	respinfo += "<query>" + strQueryWord + "</query>"
	respinfo += "<content_type>text/html; charset=utf-8</content_type>"

	return html, respinfo
}

func (aic *ShanDongAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl("http://218.57.139.24/shandong/shandong.jsp", nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract SD aic|%s|%s", pname, aic.Ecps_index)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_other
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["param"] = pname
			postdata["securityCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aic.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))
					defer doc.Free()
					if err != nil {
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "gsjbxx") {
							suburl := aic.extractSDSubUrl(node.String())
							if strings.Contains(suburl, "&amp;") {
								suburl = strings.Replace(suburl, "&amp;", "&", -1)
							}

							html, respinfo := aic.getSDAsicInfo(suburl, cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aic.SleepMS > 0 {
								time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aic.Ecps_cap), len(*result))
	}

	return palldata, resparray
}
