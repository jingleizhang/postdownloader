package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"fmt"
	"github.com/moovweb/gokogiri"
	"strings"
	"time"
)

type ShanXiAIC struct {
	AICBase
}

func NewShanXiAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ShanXiAIC {
	aic := ShanXiAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ShanXiAIC) extractSubURL(html string) string {
	start := strings.Index(html, "BusinessPub")
	end := strings.Index(html, "\" target")
	if start >= 0 && end >= 0 {
		return html[start:end]
	}
	return ""
}

//输入格式：EntClass=50
func (aic *ShanXiAIC) extractSXValue(str string, key string) (string, bool) {
	substr := strings.Split(str, "=")
	if len(substr) == 2 {
		if substr[0] == key {
			return substr[1], true
		}
	}

	return "", false
}

//http://218.26.1.108/Portal/BusinessPub.aspx?EntID=2c93d78931181b4401311d9d898a3e79&EntClass=50&EntType=4900&RegNO=141025600011571
func (aic *ShanXiAIC) extractSXEntInfo(link string) (string, string, string) {
	if strings.Contains(link, "&amp;") {
		link = strings.Replace(link, "&amp;", "&", -1)
	}

	var entID, entClass, entType string

	sublink := strings.Split(link, "?")
	if len(sublink) != 2 {
		return entID, entClass, entType
	}

	sublink = strings.Split(sublink[1], "&")
	for _, str := range sublink {
		v, ok := aic.extractSXValue(str, "EntID")
		if ok {
			entID = v
		}

		v, ok = aic.extractSXValue(str, "EntClass")
		if ok {
			entClass = v
		}

		v, ok = aic.extractSXValue(str, "EntType")
		if ok {
			entType = v
		}
	}

	return entID, entClass, entType
}

func (aic *ShanXiAIC) getSXChangeInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BChangeInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanXiAIC) getSXBasicInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BRegisInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanXiAIC) getSXInvestInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BEntInvestInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanXiAIC) getSXPersonInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BPersonInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanXiAIC) getSXBranchInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BBranchInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

//清算信息
func (aic *ShanXiAIC) getSXClearingInfo(entClass string, entType string, entID string) string {
	url := aic.Ecps_index + "BClearingInfo.aspx?EntClass=" + entClass + "&EntType=" + entType + "&EntID=" + entID

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html
		}
	}

	return ""
}

func (aic *ShanXiAIC) buildSXAsicInfo(url string) (string, string) {
	var html, respinfo string

	entID, entClass, entType := aic.extractSXEntInfo(url)

	basicInfo := aic.getSXBasicInfo(entClass, entType, entID)
	changeInfo := aic.getSXChangeInfo(entClass, entType, entID)
	investInfo := aic.getSXInvestInfo(entClass, entType, entID)
	personInfo := aic.getSXPersonInfo(entClass, entType, entID)
	branchInfo := aic.getSXBranchInfo(entClass, entType, entID)
	clearingInfo := aic.getSXClearingInfo(entClass, entType, entID)

	html = basicInfo + "," + changeInfo + "," + investInfo + "," + personInfo + "," + branchInfo + "," + clearingInfo

	respinfo = "<real_url>" + url + "</real_url>"
	var strQueryWord string
	for _, v := range aic.DownUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	respinfo += "<query>" + strQueryWord + "</query>"
	respinfo += "<content_type>text/html; charset=utf-8</content_type>"

	return html, respinfo
}

func (aic *ShanXiAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl(aic.Ecps_index, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ShanXi aic|%s|%s", pname, aic.Ecps_index)

		//转unicode格式
		var queryStr string
		for _, v := range pname {
			newstr := fmt.Sprintf("%U", v)
			queryStr += fmt.Sprint("%u" + newstr[2:])
		}

		url := aic.Ecps_detail + queryStr

		status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			doc, err := gokogiri.ParseHtml([]byte(html))

			defer doc.Free()
			if err != nil {
				return palldata, resparray
			}

			//extract link
			nodeArr, err := doc.Search("//a")
			if err != nil {
				return palldata, resparray
			}

			for i, node := range nodeArr {
				if strings.Contains(node.String(), "BusinessPub.aspx") {

					html, respinfo := aic.buildSXAsicInfo(aic.Ecps_index + aic.extractSubURL(node.String()))

					crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

					palldata = append(palldata, html)
					resparray = append(resparray, respinfo)

					if aic.SleepMS > 0 {
						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}
				} else {
					if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
						crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
					}
				}
			}

			return palldata, resparray
		}
	}

	return nil, nil
}
