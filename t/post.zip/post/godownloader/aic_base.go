package godownloader

import (
	"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"fmt"
	"github.com/moovweb/gokogiri"
	"io/ioutil"
	"os"
	"strings"
	"time"
)

type IAICExtract interface {
	ExtractCredit(pname string) (palldata []string, resparray []string)
	GetUtil() *DownloadUtil
}

//抽取工商信息，基类
type AICBase struct {
	Ecps_index  string //主页
	Ecps_cap    string //验证码页
	Ecps_detail string //详情页
	Ecps_other  string //
	Host        string //header host
	Origin      string //header origin
	Referer     string //header referer

	Tag      string //province etc
	DownUtil *DownloadUtil
	SleepMS  int
}

func (aic *AICBase) SetHeaders(headers map[string]string) {
	value, ok := headers["Host"]
	if ok {
		aic.Host = value
	}

	value, ok = headers["Origin"]
	if ok {
		aic.Origin = value
	}

	value, ok = headers["Referer"]
	if ok {
		aic.Referer = value
	}
}

func (aic *AICBase) SetECPSInfo(pages map[string]string) {
	value, ok := pages["index"]
	if ok {
		aic.Ecps_index = value
	}

	value, ok = pages["captcha"]
	if ok {
		aic.Ecps_cap = value
	}

	value, ok = pages["detail"]
	if ok {
		aic.Ecps_detail = value
	}

	value, ok = pages["other"]
	if ok {
		aic.Ecps_other = value
	}
}

func (aic *AICBase) SetSleep(ms int) {
	aic.SleepMS = ms
}

func (aic *AICBase) SetTag(tag string) {
	aic.Tag = tag
}

func (aic *AICBase) GetUtil() *DownloadUtil {
	return aic.DownUtil
}

func NewAICBase(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *AICBase {
	aic := AICBase{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aicbase *AICBase) Utf8ToGb2312(str string) string {
	encoder := mahonia.NewEncoder("gb2312")
	newstr, ok := encoder.ConvertStringOK(str)
	if !ok {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got encoder error:%s", str)
		return ""
	}
	return newstr
}

func (aicbase *AICBase) SetStatusStart() {
	var strQueryWord string
	for _, v := range aicbase.DownUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	setStatus(strQueryWord, "post-downloader.start")
	crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|obj_start|%s|%s", aicbase.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aicbase.Ecps_index))
}

func (aicbase *AICBase) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func (aicbase *AICBase) saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aicbase *AICBase) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl(aicbase.Ecps_index, nil, false)

	aicbase.DownUtil.QueryWords = append(aicbase.DownUtil.QueryWords, "aic.")
	aicbase.DownUtil.QueryWords = append(aicbase.DownUtil.QueryWords, pname)

	aicbase.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract aic|%s|%s", aicbase.Ecps_index, pname)

		time.Sleep(time.Duration(aicbase.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aicbase.DownUtil.Post2Captha(aicbase.Ecps_cap, nil)
		if result == nil || cookies == nil {
			//log.Println("fatal error, result or cookie is nil.")
			continue
		}

		for ir, r := range *result {
			//log.Println("label:", r.Label, r.Weight)

			url := aicbase.Ecps_index
			extheaders := make(map[string]string)
			extheaders["Referer"] = aicbase.Referer
			extheaders["Origin"] = aicbase.Origin
			extheaders["Host"] = aicbase.Host

			postdata := make(map[string]string)
			postdata["entName"] = pname
			postdata["checkNo"] = r.Label

			status, html, _, _ := aicbase.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s|%d", status, len(html))
			}

			if status == 200 {
				if aicbase.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aicbase.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "businessPublicity") {
							html, respinfo := aicbase.DownUtil.getCreditInfoById(aicbase.Ecps_detail, extractCreditId(node.String()))

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aicbase.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aicbase.SleepMS > 0 {
								time.Sleep(time.Duration(aicbase.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aicbase.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aicbase.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aicbase.saveCaptchaSample(imgStr, aicbase.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}
			
			time.Sleep(time.Duration(aicbase.SleepMS) * time.Millisecond)
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aicbase.Ecps_cap), len(*result))
	}

	return palldata, resparray
}
