package godownloader

import (
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	"strconv"
	"strings"
	"time"
)

const (
	SHIXIN_REFER  = "http://shixin.court.gov.cn/"
	SHIXIN_ORIGIN = "http://shixin.court.gov.cn"
	SHIXIN_HOST   = "shixin.court.gov.cn"

	SHIXIN_GOV_URL    = "http://shixin.court.gov.cn/search"
	SHIXIN_DETAIL_URL = "http://shixin.court.gov.cn/detail?id="
)

//人法基本信息
type CourtBase struct {
	Refer        string
	Origin       string
	Host         string
	Sleepms      int
	MetricSender *graphite.Client
}

type ShiXinCourt struct {
	CourtBase
	shixin_gov_url    string
	shixin_detail_url string
}

func NewShiXinCourt(index string, detail_url string, refer string, origin string, host string, ms int, gclient *graphite.Client) *ShiXinCourt {
	court := ShiXinCourt{}

	court.shixin_gov_url = index
	court.shixin_detail_url = detail_url
	court.Refer = refer
	court.Origin = origin
	court.Host = host
	court.Sleepms = ms
	court.MetricSender = gclient

	return &court
}

func (court *ShiXinCourt) getCourtInfoById(detailID string, down *(DownloadUtil)) (string, string) {
	url := court.shixin_detail_url + detailID

	//先去rtd查
	rtd := down.GetRtDownloaderAddr()

	status, html, _, resp := down.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html, resp
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//再用本地ip查
		status, html, _, resp = down.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html, resp
		}
	}

	return "", ""
}

func (court *ShiXinCourt) extractGotoPage(data string) int {
	start := strings.Index(data, "gotoPage(")
	end := strings.Index(data, ")")

	if start >= 0 && end >= 0 {
		ret, _ := strconv.Atoi(data[start+len("gotoPage(") : end])
		return ret
	}
	return 0
}

func (court *ShiXinCourt) ExtractCourtByPage(pname string, pcid string, pagestart int, gclient *graphite.Client) ([]string, int, []string) {
	var parray []string
	var resparray []string
	totalpages := 0

	url := court.shixin_gov_url
	extheaders := make(map[string]string)
	extheaders["Referer"] = court.Refer
	extheaders["Origin"] = court.Origin
	extheaders["Host"] = court.Host

	postdata := make(map[string]string)
	postdata["currentPage"] = strconv.Itoa(pagestart)
	postdata["pName"] = pname
	postdata["pCardNum"] = pcid
	postdata["pProvince"] = "0"

	downUtil := NewDownloadUtil(gclient)
	if pname != "" {
		downUtil.QueryWords = append(downUtil.QueryWords, pname)
	}
	if pcid != "" {
		downUtil.QueryWords = append(downUtil.QueryWords, pcid)
	}

	status, html, _, _ := downUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil, true)
	if status == 200 && len(html) > 50 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			return parray, totalpages, resparray
		}

		//extract id
		nodeArr, err := doc.Search("//a/@id")
		if err != nil || len(nodeArr) == 0 {
			return parray, totalpages, resparray
		}

		for _, node := range nodeArr {
			if len(node.String()) > 0 {
				pjson, resp := court.getCourtInfoById(node.String(), downUtil)
				parray = append(parray, pjson)
				resparray = append(resparray, resp)

				if court.Sleepms > 0 {
					time.Sleep(time.Duration(court.Sleepms) * time.Millisecond)
				}
			}
		}

		//extract total page
		nodeArr, err = doc.Search("//a/@onclick")
		if err != nil {
			return parray, totalpages, resparray
		}
		if len(nodeArr) > 0 {
			totalpages = court.extractGotoPage(nodeArr[len(nodeArr)-1].String())
		}

	}

	return parray, totalpages, resparray
}

func (court *ShiXinCourt) ExtractCredit(pname string, pcid string) (palldata []string, resparray []string) {
	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do ExtractShixin|%s|%s", pname, pcid)

	startpage := 1

	parray, endpage, rarray := court.ExtractCourtByPage(pname, pcid, startpage, court.MetricSender)
	for _, strjson := range parray {
		palldata = append(palldata, strjson)
	}
	for _, resp := range rarray {
		resparray = append(resparray, resp)
	}

	for endpage > startpage {
		startpage++

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("startpage and endpage|%s|%s|%d|%d", pname, pcid, startpage, endpage)

		parray2, _, resparray2 := court.ExtractCourtByPage(pname, pcid, startpage, court.MetricSender)
		for _, strjson := range parray2 {
			palldata = append(palldata, strjson)
		}
		for _, resp := range resparray2 {
			resparray = append(resparray, resp)
		}
	}

	return palldata, resparray
}
