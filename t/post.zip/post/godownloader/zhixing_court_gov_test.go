package godownloader

import (
	"fmt"
	"os"
	"testing"
)

func TestExtractCourtGov(t *testing.T) {
	htmlarray, _ := ExtractCourtGov("张磊", "")

	fmt.Println("len(htmlarray):", len(htmlarray))

	gswriter, _ := os.Create("TestExtractCourtByPage.html")
	for _, v := range htmlarray {
		gswriter.WriteString(v)
	}

	gswriter.Close()

//	if len(ret) < 5 {
//		t.Error(ret, count)
//	}
}
