package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	//"log"
	"encoding/base64"
	"net/http"
	"strings"
	"time"
)

//天津工商
type TianJinAIC struct {
	AICBase
}

func NewTianJinAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *TianJinAIC {
	aic := TianJinAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func (aic *TianJinAIC) extractSuburl(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *TianJinAIC) extractTJDetail(suburl string, cookies []*http.Cookie) (string, string) {
	url := aic.Ecps_index + suburl

	respinfo := "<real_url>" + url + "</real_url>"
	var strQueryWord string
	for _, v := range aic.DownUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	respinfo += "<query>" + strQueryWord + "</query>"
	respinfo += "<content_type>text/html; charset=utf-8</content_type>"

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), cookies, true)
	if status == 200 && len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
		if status == 200 || len(html) > 20 {
			return html, respinfo
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
		}
	}

	return "", ""
}

func (aic *TianJinAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract TianJin AIC|%s", pname)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_other
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["qymc"] = pname
			postdata["yzmv"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if isPageCorrect(&html) {
					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						return palldata, resparray
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						return palldata, resparray
					}

					if len(nodeArr) == 0 {
						break
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "target") {
							suburl := aic.extractSuburl(node.String())
							if !strings.Contains(suburl, "http") {
								html, respinfo := aic.extractTJDetail(suburl, cookies)
								crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

								palldata = append(palldata, html)
								resparray = append(resparray, respinfo)

							} else {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), suburl)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return palldata, resparray
}
