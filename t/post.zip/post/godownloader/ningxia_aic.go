package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

type NingXiaAIC struct {
	AICBase
}

func NewNingXiaAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *NingXiaAIC {
	aic := NingXiaAIC{}
	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *NingXiaAIC) extractHuBeiCreditId(data string) string {
	start := strings.Index(data, "showJbxx(")
	end := strings.Index(data, ")\">")

	if start >= 0 && end >= 0 {
		substr := data[start+len("showJbxx(") : end]

		return substr
	}

	return ""
}

//showJbxx('6401023606118','9999','明达电子','6401023606118','2')
func (aic *NingXiaAIC) getCreditInfoById(detailID string, cookies []*http.Cookie) (string, string) {
	var basicInfo, respInfo string

	var nbxh, qylx, qymc, qylxFlag string

	tmpArray := strings.Split(detailID, ",")
	if len(tmpArray) != 5 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error, not valaid detailID|%s", detailID)
		return "", ""
	}

	if len(tmpArray[0]) > 2 {
		nbxh = tmpArray[0][1 : len(tmpArray[0])-1]
	}
	if len(tmpArray[1]) > 2 {
		qylx = tmpArray[1][1 : len(tmpArray[1])-1]
	}
	if len(tmpArray[2]) > 2 {
		qymc = tmpArray[2][1 : len(tmpArray[2])-1]
	}
	//	if len(tmpArray[3]) > 2 {
	//		zch = tmpArray[3][1 : len(tmpArray[3])-1]
	//	}
	if len(tmpArray[4]) > 2 {
		qylxFlag = tmpArray[4][1 : len(tmpArray[4])-1]
	}

	nqymc := base64.URLEncoding.EncodeToString([]byte(qymc))

	url := "http://gsxt.ngsh.gov.cn/ECPS/qyxxgsAction_initQyxyxxMain.action"
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["qymc"] = nqymc
	postdata["qylx"] = qylx
	postdata["nbxh"] = nbxh
	postdata["qylxFlag"] = qylxFlag

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	if status == 200 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			return "", ""
		}

		//extract iframe
		nodeArr, err := doc.Search("//iframe/@src")
		if err != nil {
			return "", ""
		}

		if len(nodeArr) == 0 {
			return "", ""
		}

		for _, node := range nodeArr {
			urlNode := aic.Ecps_index + node.String()

			status, tmpInfo, _, _ := aic.DownUtil.GetHttpRequestByUrl(urlNode, cookies, true)

			if status == 200 {
				basicInfo += tmpInfo + ","
			}
		}

		//build respinfo
		respInfo = "<real_url>POST:" + url + "?nqymc=" + nqymc + "&nbxh=" + nbxh + "&qylx=" + qylx + "&qylxFlag=" + qylxFlag + "</real_url>"
		var strQueryWord string
		for _, v := range aic.DownUtil.QueryWords {
			strQueryWord += GetUrlEncode(v)
		}
		respInfo += "<query>" + strQueryWord + "</query>"
		respInfo += "<content_type>text/html;charset=utf-8</content_type>"

		return basicInfo, respInfo
	} else {
		return "", ""
	}
}

func (aic *NingXiaAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl(aic.Ecps_index, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract NingXia aic|%s|%s", pname, aic.Ecps_index)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_other
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["selectValue"] = pname
			postdata["password"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aic.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "showJbxx") {
							str := aic.extractHuBeiCreditId(node.String())

							html, respinfo := aic.getCreditInfoById(str, cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aic.SleepMS > 0 {
								time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aic.Ecps_cap), len(*result))
		}
	}

	return palldata, resparray
}
