package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"encoding/base64"
	"github.com/moovweb/gokogiri"
	//"log"
	"net/http"
	"strconv"
	"strings"
	"time"
)

//const (
//	BAIC_REFER  = "http://qyxy.baic.gov.cn/wap/creditWapAction!QueryEnt20130412.dhtml"
//	BAIC_ORIGIN = "http://qyxy.baic.gov.cn"
//	BAIC_HOST   = "qyxy.baic.gov.cn"
//
//	BAIC_INDEX  = "http://qyxy.baic.gov.cn"
//	BAIC_PUB    = "http://qyxy.baic.gov.cn/wap/creditWapAction!QueryEnt20130412.dhtml"
//	BAIC_DETAIL = "http://qyxy.baic.gov.cn/xycx/queryCreditAction!qyxq_view.dhtml?reg_bus_ent_id="
//)

type BeiJingAIC struct {
	AICBase
}

func NewBeiJingAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *BeiJingAIC {
	aic := BeiJingAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *BeiJingAIC) extractCreditId(data string) string {
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" style=")

	if start >= 0 && end >= 0 {
		return data[start+len("href=\"") : end]
	}

	return ""
}

func (aic *BeiJingAIC) extractJumpPage(data string) int {
	start := strings.Index(data, "jumppage(")
	end := strings.Index(data, ");return")

	if start >= 0 && end >= 0 {
		tmpArray := strings.Split(data[start+len("jumppage("):end], ",")
		if len(tmpArray) > 0 {
			ret, _ := strconv.Atoi(tmpArray[0][1 : len(tmpArray[0])-1])
			return ret
		}
	}
	return 0
}

func (aic *BeiJingAIC) getDetailInfo(suburl string, cookies []*http.Cookie) (string, string) {
	url := aic.Ecps_index + suburl

	if strings.Contains(url, "&amp;") {
		url = strings.Replace(url, "&amp;", "&", -1)
	}

	respinfo := "<real_url>" + url + "</real_url>"
	var strQueryWord string
	for _, v := range aic.DownUtil.QueryWords {
		strQueryWord += GetUrlEncode(v)
	}
	respinfo += "<query>" + strQueryWord + "</query>"
	respinfo += "<content_type>text/html; charset=utf-8</content_type>"

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), nil, true)
	if status == 200 && len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		//status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, nil, true)
		if status == 200 {
			return html, respinfo
		}
	}

	return "", ""
}

func (aic *BeiJingAIC) ExtractCreditByPage(pname string, pagestart int) (palldata []string, resparray []string, totalpages int) {
	totalpages = 0

	url := aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["queryStr"] = pname
	postdata["module"] = ""
	postdata["idFlag"] = "qyxy"
	postdata["key_word"] = pname
	postdata["SelectPageSize"] = "30"
	postdata["EntryPageNo"] = "1"
	postdata["pageNo"] = strconv.Itoa(pagestart)
	postdata["pageSize"] = "30"
	postdata["clear"] = "true"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	if status == 200 {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
			return palldata, resparray, totalpages
		}

		//extract link
		nodeArr, err := doc.Search("//a")
		if err != nil {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
			return palldata, resparray, totalpages
		}

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		for _, node := range nodeArr {
			if strings.Contains(node.String(), "reg_bus_ent_id") {
				id := aic.extractCreditId(node.String())

				html, respinfo := aic.getDetailInfo(id, nil)

				palldata = append(palldata, html)
				resparray = append(resparray, respinfo)

				time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			} else {
				if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
				}
			}
		}

		//extract total page
		for _, node := range nodeArr {
			if strings.Contains(node.String(), "title=\"尾页\"") {
				totalpages = aic.extractJumpPage(node.String())
			}
		}
	}

	return palldata, resparray, totalpages
}

func (aic *BeiJingAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {

	startpage := 1

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract BeiJing aic|%s|%s", pname, aic.Ecps_index)

	parray, rarray, totalpage := aic.ExtractCreditByPage(pname, startpage)
	for _, str := range parray {
		palldata = append(palldata, str)
	}
	for _, resp := range rarray {
		resparray = append(resparray, resp)
	}

	//只抓第一页
	for totalpage > startpage {
		startpage++

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("startpage and totalpage|%s|%d|%d", pname, startpage, totalpage)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		parray2, rarray2, _ := aic.ExtractCreditByPage(pname, startpage)
		for _, str := range parray2 {
			palldata = append(palldata, str)
		}
		for _, resp := range rarray2 {
			resparray = append(resparray, resp)
		}
	}

	return parray, resparray
}
