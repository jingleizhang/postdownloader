package godownloader

import (
	//"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	//"fmt"
	//"io/ioutil"
	//"log"
	"strings"
	"time"
)

const (
	ZJ_ECPS_INDEX  = "http://gsxt.zjaic.gov.cn/search/"
	ZJ_ECPS_CAP    = "http://gsxt.zjaic.gov.cn/common/captcha/doReadKaptcha.do"
	ZJ_ECPS_PUB    = "http://gsxt.zjaic.gov.cn/search/doGetAppSearchResultIn.do"
	ZJ_ECPS_DETAIL = ""

	ZJ_HOST   = "gsxt.zjaic.gov.cn"
	ZJ_ORIGIN = "http://gsxt.zjaic.gov.cn"
	ZJ_REFER  = "http://gsxt.zjaic.gov.cn/search/doGetAppSearchResultIn.do"
)

//浙江工商
type ZJAIC struct {
	AICBase
}

func NewZJAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ZJAIC {
	aic := ZJAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ZJAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func (aic *ZJAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 4; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ZJ AIC|%s", pname)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(ZJ_ECPS_CAP, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := ZJ_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = ZJ_REFER
			extheaders["Origin"] = ZJ_ORIGIN
			extheaders["Host"] = ZJ_HOST

			postdata := make(map[string]string)
			postdata["name"] = pname
			postdata["verifyCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}
