package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	//"log"
	"net/http"
	"strings"
	"time"
)

const (
	HEBEI_ECPS_INDEX  = "http://www.hebscztxyxx.gov.cn/notice/"
	HEBEI_ECPS_CAP    = "http://www.hebscztxyxx.gov.cn/notice/img.captcha?type=3&ra=0.14000600553117692"
	HEBEI_ECPS_PUB    = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntList"
	HEBEI_ECPS_DETAIL = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntInfoMainCountry.do"

	HEBEI_HOST   = "www.hebscztxyxx.gov.cn"
	HEBEI_ORIGIN = "http://www.hebscztxyxx.gov.cn"
	HEBEI_REFER  = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntList"
)

//河北工商
type HeBeiAIC struct {
	AICBase
}

func NewHeBeiAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *HeBeiAIC {
	aic := HeBeiAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *HeBeiAIC) extractHeBeiSuburl(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *HeBeiAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "您查询的信息") {
		return true
	} else {
		return false
	}
}

func (aic *HeBeiAIC) extractHeBeiDetail(suburl string, cookies []*http.Cookie) (string, string) {
	url := HEBEI_ECPS_INDEX + suburl
	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	return "", ""
}

func (aic *HeBeiAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract HeBeiAIC|%s", pname)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(HEBEI_ECPS_CAP, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			queryURL := HEBEI_ECPS_PUB + "?condition.pageNo=1&condition.entName=" + GetUrlEncode(pname) + "&condition.code=" + r.Label
			status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(queryURL, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), queryURL)
			}

			if status == 200 && len(html) > 20 {
				if aic.isPageCorrect(&html) {
					doc, err := gokogiri.ParseHtml([]byte(html))
					defer doc.Free()
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "queryEntInfoMainCountry") {
							html, respinfo = aic.extractHeBeiDetail(aic.extractHeBeiSuburl(node.String()), cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}
