package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"strconv"
	"strings"
	"time"
)

type ChongQingAIC struct {
	AICBase
}

func NewChongQingAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ChongQingAIC {
	aic := ChongQingAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ChongQingAIC) isCQPageCorrect(str *string) bool {
	if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "抱歉，找不到您要的页面") {
		return false
	} else {
		return true
	}
}

func (aic *ChongQingAIC) extractCQDetail(html string) (palldata []string, resparray []string) {
	doc, err := gokogiri.ParseHtml([]byte(html))

	defer doc.Free()
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("ParseHtml error|%s", err.Error())
		return palldata, resparray
	}

	//extract link
	nodeArr, err := doc.Search("//tr[@onclick]")
	if err != nil {
		return palldata, resparray
	}

	for i, node := range nodeArr {
		if strings.Contains(node.String(), "view(document.all.tableform,'varqymc')") {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d", i, len(nodeArr)-1)

			inputArray, err := node.Search("input")
			if err != nil {
				return palldata, resparray
			}

			var pkvalue, qytype, intzt, varbz string
			qytype = "qy"
			for _, input := range inputArray {
				attributes := input.Attributes()
				if attributes["name"].String() == "gsj_qybase_index" {
					pkvalue = attributes["value"].String()
				}
				if attributes["name"].String() == "intzt" {
					intzt = attributes["value"].String()
				}
				if attributes["name"].String() == "varbz" {
					varbz = attributes["value"].String()
				}
			}

			detailURL := aic.Ecps_index + "/lhzx/xycxAction.do?pkvalue=" + pkvalue + "&type=" + qytype + "&intzt=" + intzt + "&varbz=" + varbz

			status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(detailURL, nil, true)
			if status == 200 {
				palldata = append(palldata, html)
				resparray = append(resparray, respinfo)

			} else {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got search error, status: %d", status)
			}

			if aic.SleepMS > 0 {
				time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			}
		} else {
			if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
				crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
			}
		}
	}

	return palldata, resparray
}

func (aic *ChongQingAIC) extractCreditIndexPage(pname string) (palldata []string, resparray []string, totalpage int) {
	totalpage = 0

	url := aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["radio"] = "qy"
	postdata["qytype"] = "varqymc"
	postdata["qyysf"] = "2"
	postdata["txtqy"] = aic.Utf8ToGb2312(pname) //企业名称, gbk
	postdata["querytj"] = "1"
	postdata["querytype"] = "qy"                  //qy:企业, gt:个体
	postdata["varzch"] = ""                       //注册号
	postdata["varqymc"] = aic.Utf8ToGb2312(pname) //企业名称, gbk
	postdata["varfddbr"] = ""                     //法定代表人
	postdata["varysf"] = "2"
	postdata["intzt"] = "1"
	postdata["message"] = aic.Utf8ToGb2312("企业(机构)名称") //gbk

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil, true)
	if status == 200 {
		tmpAllData, tmpResp := aic.extractCQDetail(html)

		for _, v := range tmpAllData {
			palldata = append(palldata, v)
		}
		for _, v := range tmpResp {
			resparray = append(resparray, v)
		}

		//get total records
		var totalPages, recordsPerPage int
		recordsPerPage = 10
		if strings.Contains(html, "条记录") {
			end := strings.Index(html, "条记录")
			start := strings.LastIndex(html[:end], "nowrap>")

			totalRecords, _ := strconv.Atoi(strings.Trim(html[start+len("nowrap>"):end], ""))

			if totalRecords > 0 {
				totalPages = totalRecords / recordsPerPage
				if (totalRecords % recordsPerPage) > 0 {
					totalPages += 1
				}
			}

			crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("totalRecords|%d|totalPages|%d", totalRecords, totalPages)
		}

	}

	return palldata, resparray, totalpage
}

func (aic *ChongQingAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//_, _, cookies, _ := aic.DownUtil.GetHttpRequestByUrl(CQ_ECPS_PUB, nil, false)
	//log.Println("cookies:", cookies)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	palldata, resparray, totalpage := aic.extractCreditIndexPage(pname)

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract CQ aic|%s|%d", pname, totalpage)

	//TODO: 如果有多页，开始翻页处理

	return palldata, resparray
}
