package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

type XinJiangAIC struct {
	AICBase
}

func NewXinJiangAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *XinJiangAIC {
	aic := XinJiangAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *XinJiangAIC) extractXJCreditId(data string) (string, string) {
	start := strings.Index(data, "openView(")
	end := strings.Index(data, ")\" style")

	var newdata string
	if start >= 0 && end >= 0 {
		newdata = data[start+len("openView(") : end]
	} else {
		return "", ""
	}

	tmparray := strings.Split(newdata, ",")
	if len(tmparray) == 3 {
		return tmparray[0][1 : len(tmparray[0])-1], tmparray[1][1 : len(tmparray[1])-1]
	}

	return "", ""
}

func (aic *XinJiangAIC) getXJCreditInfo(url string, aicid string, aictype string, reqcookie []*http.Cookie) (int, string, string) {
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["method"] = "qyInfo"
	postdata["maent.pripid"] = aicid
	postdata["maent.entbigtype"] = aictype

	status, html, _, respinfo := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, reqcookie, true)
	return status, html, respinfo
}

func (aic *XinJiangAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//GetHttpRequestByUrl(aic.Ecps_index, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	aic.SetStatusStart()

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract XinJiang aic|%s|%s", pname, aic.Ecps_index)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)

		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := aic.Ecps_index
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["yzmYesOrNo"] = ""
			postdata["cxym"] = "cxlist"
			postdata["maent.entname"] = aic.Utf8ToGb2312(pname)
			postdata["yzm"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_succ|%s|%d|%d", common.ExtractDomainOnly(aic.Ecps_cap), len(*result), ir)

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "openView") {

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							aicid, aictype := aic.extractXJCreditId(node.String())
							_, html, respinfo := aic.getXJCreditInfo(aic.Ecps_detail, aicid, aictype, cookies)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							if aic.SleepMS > 0 {
								time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}
			
			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}

		crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("captcha|ocr_finish_fail|%s|%d|-1", common.ExtractDomainOnly(aic.Ecps_cap), len(*result))
	}

	return palldata, resparray

}
