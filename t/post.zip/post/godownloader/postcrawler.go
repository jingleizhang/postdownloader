package godownloader

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"io"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const (
	//Default Headers
	HEADER_ACCEPT        = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
	HEADER_ACCEPT_ENCODE = "deflate,sdch" //"gzip,deflate,sdch"
	HEADER_UA            = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36"
	HEADER_CONTENT_TYPE  = "application/x-www-form-urlencoded; param=value"
	//HEADER_CONTENT_TYPE  = "application/x-www-form-urlencoded"

	RTD_FILE        = "rtd.list"
	RTHTTP_FILE     = "realtime_downloader.list"
	DEFAULT_TIMEOUT = 60
)

type PostDownloader struct {
	metricSender    *graphite.Client
	postCrawlerConf *[]common.PostCrawlerConf
	postMetaConf    *common.PostMetaData
	gopostChans     []chan common.EntityObject
	postDownStat    *PostDownloadStat
}

func dialTimeout(network, addr string) (net.Conn, error) {
	timeout := time.Duration(common.PostdlConfigInstance().DownloadTimeout) * time.Second
	deadline := time.Now().Add(timeout)
	c, err := net.DialTimeout(network, addr, timeout)
	if err != nil {
		return nil, err
	}
	c.SetDeadline(deadline)
	return c, nil
}

func setStatus(query, status string) {
	if query == "" {
		return
	}

	client := &http.Client{
		Transport: &http.Transport{
			Dial:                  dialTimeout,
			DisableKeepAlives:     false,
			ResponseHeaderTimeout: time.Duration(common.PostdlConfigInstance().DownloadTimeout) * time.Second,
		},
	}

	urlStr := "http://redis.crawler.bdp.cc:8080/LPUSH/" + query + "/" + strconv.FormatInt(time.Now().Unix(), 10) + "." + status

	req, err := http.NewRequest("GET", urlStr, nil)
	if err != nil {
		return
	}
	resp, err := client.Do(req)
	if err != nil || resp == nil || resp.Body == nil {
		return
	}
	defer resp.Body.Close()
	ioutil.ReadAll(resp.Body)
}

//for anhui, heilongjiang, beijing, etc
func extractCreditId(data string) string {
	start := strings.Index(data, "id=")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		return data[start+len("id=") : end]
	}

	return ""
}

//init config
func (self *PostDownloader) initPostConfJson() (int, int) {
	downUtil := NewDownloadUtil(self.metricSender)
	status, websiteConf, _, _ := downUtil.GetHttpRequestByUrl(common.PostdlConfigInstance().PostConfHost, nil, false)
	if status != 200 || len(websiteConf) == 0 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal err: got empty PostConfHost.")
		return 0, 0
	}
	self.postCrawlerConf = common.NewPostConf(websiteConf)

	status, metaConf, _, _ := downUtil.GetHttpRequestByUrl(common.PostdlConfigInstance().MetaConfHost, nil, false)
	if status != 200 || len(websiteConf) == 0 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal err: got empty MetaConfHost.")
	}
	self.postMetaConf = common.NewMetaDataConf(metaConf)

	return len(*self.postCrawlerConf), len(self.postMetaConf.ExternalMeta)
}

//init timer task
func (self *PostDownloader) timerFetchTask() {
	go func() {
		self.initPostConfJson()
		//log.Println("got timer: ", len(*self.postCrawlerConf), len(self.postMetaConf.ExternalMeta), len(self.postMetaConf.InternalMeta))
	}()
}

//postCrawlerConf
func (self *PostDownloader) GetPostConf() *[]common.PostCrawlerConf {
	return self.postCrawlerConf
}

func (self *PostDownloader) initTimerTask() {
	timer := time.NewTicker(60 * time.Second)
	for {
		select {
		case <-timer.C:
			self.timerFetchTask()
		}
	}
}

func resetCaptchaMetrics(metricSender *graphite.Client) {
	metricSender.Gauge("crawler.post-downloader.captcha.ocr_start_total", 0, 1.0)
	metricSender.Gauge("crawler.post-downloader.captcha.resp_not200_total", 0, 1.0)
	metricSender.Gauge("crawler.post-downloader.captcha.resp_notjson_total", 0, 1.0)
	metricSender.Gauge("crawler.post-downloader.captcha.ocr_fail_total", 0, 1.0)
	metricSender.Gauge("crawler.post-downloader.captcha.ocr_succ_total", 0, 1.0)
}

func NewPostDownloader(stat *PostDownloadStat) *PostDownloader {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	resetCaptchaMetrics(stat.metricSender)

	postdl := PostDownloader{}
	postdl.metricSender = stat.metricSender

	postdl.initPostConfJson()
	go postdl.initTimerTask()

	postdl.postDownStat = stat

	postdl.gopostChans = make([]chan common.EntityObject, common.PostdlConfigInstance().GoPostChanCount)
	for i := 0; i < common.PostdlConfigInstance().GoPostChanCount; i++ {
		postdl.gopostChans[i] = make(chan common.EntityObject, 300)
	}

	go postdl.postDownStat.doDownloadStat()

	go postdl.postDownStat.FlushPages()

	for i := 0; i < common.PostdlConfigInstance().GoPostChanCount; i++ {
		go StateExecute(&postdl, &(postdl.gopostChans[i]))
	}

	return &postdl
}

//func (postdl *PostDownloader) PorcessGopost() {
//	for {
//		v := <-postdl.gopostChan
//
//		//StateExecute(v, postdl)
//		go StateExecute(v, postdl)
//
//		time.Sleep(time.Duration(1) * time.Second)
//	}

//for i := 0; i < common.PostdlConfigInstance().GoPostChanCount; i++ {
//	go StateExecute(v, postdl, postdl.gopostChans[i])
//}
//}

func (postdl *PostDownloader) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	defer func() {
		if recvr := recover(); recvr != nil {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error and recover|%s", recvr)
		}
	}()

	random := rand.New(rand.NewSource(time.Now().UnixNano()))

	if r.Method == METHOD_GET {
		io.WriteString(w, "I'm alive")
		//log.Println("response GET request from ", r.RemoteAddr, r.URL)
	} else if r.Method == METHOD_POST {
		r.ParseForm()

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("got Form|%s", r.Form)

		for k, v := range r.Form {
			if k == "gopost" {
				postObjArray := common.NewPostObjectEntity(strings.Join(v, ""))

				for _, v := range *postObjArray {
					index := random.Int() % common.PostdlConfigInstance().GoPostChanCount
					postdl.gopostChans[index] <- v

					postdl.postDownStat.objRecvCountTotal += 1

					crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("got post data|%s|chan index|%d", v, index)
				}

				postdl.postDownStat.postRecvChan <- 1
			}
		}
		io.WriteString(w, "got post data.")
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("response POST request from|%s|%s", r.RemoteAddr, r.URL)
	}
}
