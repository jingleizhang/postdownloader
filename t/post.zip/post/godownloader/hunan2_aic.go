package godownloader

import (
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"net/http"
	"strings"
	"time"
)

const (
	HN2_ECPS_INDEX  = "http://www.hncredit.gov.cn/search/"
	HN2_ECPS_CAP    = "http://www.hncredit.gov.cn/2013/inc/Code.aspx?p=0.8424497516825795"
	HN2_ECPS_PUB    = "http://www.hncredit.gov.cn/2013/server/qylist_ajax.aspx"
	HN2_ECPS_DETAIL = "http://www.hncredit.gov.cn/search/qy_public.aspx"

	HN2_HOST   = "www.hncredit.gov.cn"
	HN2_ORIGIN = "http://www.hncredit.gov.cn"
	HN2_REFER  = "http://www.hncredit.gov.cn/search/search_qy.html"
)

//湖南信用
type HuNanCreditAIC struct {
	AICBase
}

func NewHuNanCreditAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *HuNanCreditAIC {
	aic := HuNanCreditAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *HuNanCreditAIC) extarctHNCreditID(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *HuNanCreditAIC) getDetailInfo(suburl string, cookies []*http.Cookie) (string, string) {

	url := HN2_ECPS_INDEX + suburl
	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	return "", ""
}

func (aic *HuNanCreditAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract HuNanCreditAIC|%s", pname)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(HN2_ECPS_CAP, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			queryURL := HN2_ECPS_PUB + "?code=" + r.Label + "&cx_qymc=" + GetUrlEncode(pname) + "&cx_gszch=&cx_zzjgdm=&cx_fddbr="
			status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(queryURL, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), queryURL)
			}

			if status == 200 && len(html) > 20 {
				doc, err := gokogiri.ParseHtml([]byte(html))
				defer doc.Free()
				if err != nil {
					crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
					continue
				}

				//extract link
				nodeArr, err := doc.Search("//a")
				if err != nil {
					continue
				}

				for i, node := range nodeArr {
					if strings.Contains(node.String(), "qy_public.aspx") {
						html, respinfo := aic.getDetailInfo(aic.extarctHNCreditID(node.String()), cookies)

						crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

						palldata = append(palldata, html)
						resparray = append(resparray, respinfo)

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}
				}

				//save img to disk
				aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

				return palldata, resparray
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}
	return nil, nil
}
