package godownloader

import (
	"crawler/post/crawlerlog"
	"crawler/post/graphite"
	"net/http"
	"strings"
	"time"
)

const (
	HN_ECPS_INDEX  = "http://gsxt.hnaic.gov.cn"
	HN_ECPS_CAP    = "http://gsxt.hnaic.gov.cn/VerifierImage.jpg?noCache=1402482488594"
	HN_ECPS_PUB    = "http://gsxt.hnaic.gov.cn/ZjQueryRegList"
	HN_ECPS_DETAIL = "http://gsxt.hnaic.gov.cn/ZjRegObjGet"

	HN_HOST   = "gsxt.hnaic.gov.cn"
	HN_ORIGIN = "http://gsxt.hnaic.gov.cn"
	HN_REFER  = "http://gsxt.hnaic.gov.cn/gjzj/query_list.html"
)

type HuNanAIC struct {
	AICBase
}

func NewHuNanAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *HuNanAIC {
	aic := HuNanAIC{}

	aic.DownUtil = NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *HuNanAIC) extractCreditID(data string) string {
	var newdata string
	start := strings.Index(data, "A=\"")
	end := strings.Index(data, "\" B=")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("A=\"") : end]
	}

	return newdata
}

func (aic *HuNanAIC) getInfoById(id string, cookies []*http.Cookie) (string, string) {
	url := aic.Ecps_detail
	extheaders := make(map[string]string)
	extheaders["Referer"] = "http://gsxt.hnaic.gov.cn/gjzj/credit_info.html"
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["ID"] = id
	postdata["ZCH"] = "1"

	cookie := http.Cookie{Name: "ID", Value: id, Path: "/", MaxAge: 86400}
	cookies = append(cookies, &cookie)

	cookie2 := http.Cookie{Name: "ZCH", Value: "1", Path: "/", MaxAge: 86400}
	cookies = append(cookies, &cookie2)

	time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

	status, html, _, respinfo := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)

		postdata["ZCH"] = "0"

		cookie := http.Cookie{Name: "ID", Value: id, Path: "/", MaxAge: 86400}
		cookies = append(cookies, &cookie)

		cookie2 := http.Cookie{Name: "ZCH", Value: "1", Path: "/", MaxAge: -1}
		cookies = append(cookies, &cookie2)

		cookie3 := http.Cookie{Name: "ZCH", Value: "0", Path: "/", MaxAge: 86400}
		cookies = append(cookies, &cookie3)
		status, html, _, respinfo = aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
	}

	if status == 200 {
		return html, respinfo
	}

	return "", ""
}

func (aic *HuNanAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, "aic.")
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract HuNanAIC|%s", pname)

		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(aic.Ecps_cap, nil)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := HN_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = aic.Referer
			extheaders["Origin"] = aic.Origin
			extheaders["Host"] = aic.Host

			postdata := make(map[string]string)
			postdata["KW"] = pname
			postdata["SN"] = r.Label
			postdata["MZ"] = "1"
			postdata["QG"] = "2"

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					xmlArray := strings.Split(html, "><")
					for i, xml := range xmlArray {
						id := aic.extractCreditID(xml)
						if len(id) > 0 {
							html, respinfo := aic.getInfoById(id, cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(xmlArray)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)
						}
					}

					//save img to disk
					aic.saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}
