package godownloader

import (
	//"fmt"
	//"net/http"
	"testing"
)

//func TestGetCourtInfoById(t *testing.T) {
//	did := "76409264"
////	postdl := NewPostDownloader()
////	fmt.Println("postdl:\n", postdl)
//	ret := getCourtInfoById(did)
//	if len(ret) < 20 {
//		t.Error(ret)
//	}
//
//}
//
//func TestGetHttpRequest(t *testing.T) {
//	statem := NewPostStateMachine()
//	statem.url = "http://www.baidu.com"
//
//	status, ret := GetHttpRequest(statem)
//	if status != 200 || len(ret) < 20 {
//		t.Error(ret)
//	}
//}
//
//func TestExtractGotoPage(t *testing.T) {
////	postdl := NewPostDownloader()
////	fmt.Println("postdl:\n", postdl)
//	
//	ret := extractGotoPage("gotoPage(27)")
//	if ret != 27 {
//		t.Error(ret)
//	}
//}

func TestInitPostConfJson(t *testing.T) {
	postdownstat := NewPostDownloadStat()
	postdl := NewPostDownloader(postdownstat)
	lenPostConf, lenMetaConf := postdl.initPostConfJson()

	if lenPostConf == 0 || lenMetaConf == 0 {
		t.Error("postCrawlerConf:\n", postdl.postCrawlerConf, "postMetaConf:\n", postdl.postMetaConf)
	}
}
