package godownloader

import (
	"bytes"
	"crawler/post/crawlerlog"
	"encoding/gob"
	//"log"
	"bufio"
	"math/rand"
	"net/http"
	"os"
	"strings"
)

type URLContext struct {
	//http request
	URL          string
	Method       string //GET/POST
	timeout      int    //秒
	CookiesReq   []http.Cookie
	Headers      map[string]string
	PostData     map[string]string //utf8
	Convert2Utf8 bool              //对于抓到的页面，是否转码

	//http response
	Status      int
	Html        string
	CookiesResp []http.Cookie
	Respinfo    string //for crawler

	RtdHosts []string //for http get/post with cookie
}

func NewURLContextDefault(url string, method string, timeout int) *URLContext {
	context := URLContext{
		URL:          url,
		Method:       method,
		timeout:      timeout,
		Headers:      make(map[string]string),
		PostData:     make(map[string]string),
		Convert2Utf8: false,
	}

	context.Headers["Accept"] = HEADER_ACCEPT
	context.Headers["Accept-Encoding"] = HEADER_ACCEPT_ENCODE
	context.Headers["User-Agent"] = HEADER_UA
	context.Headers["Content-Type"] = HEADER_CONTENT_TYPE

	context.loadRtdList()

	return &context
}

func (context *URLContext) SetTimeout(timeout int) {
	context.timeout = timeout
}

func (context *URLContext) SetConvert(doConvert bool) {
	context.Convert2Utf8 = doConvert
}

//http://127.0.0.1:9110/proxy
func (context *URLContext) loadRtdList() {
	f, err := os.Open(RTD_FILE)
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
		return
	}

	r := bufio.NewReader(f)
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			break
		}
		line = strings.Trim(line, "\n")
		if strings.Contains(line, "http://") {
			context.RtdHosts = append(context.RtdHosts, line)
		}
	}
}

func (context *URLContext) GetRtdAddr() (string, bool) {
	if len(context.RtdHosts) == 0 {
		return "", false
	}
	return context.RtdHosts[rand.Intn(len(context.RtdHosts))], true
}

func NewURLContext(url string, method string, timeout int, headers map[string]string, data map[string]string, cookies []*http.Cookie, clean bool) *URLContext {
	context := NewURLContextDefault(url, method, timeout)

	if headers != nil {
		for k, v := range headers {
			context.Headers[k] = v
		}
	}

	if data != nil {
		for k, v := range data {
			context.PostData[k] = v
		}
	}

	if cookies != nil {
		for _, v := range cookies {
			context.CookiesReq = append(context.CookiesReq, *v)
		}
	}

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish NewURLContext()|%s", url)

	return context
}

func EncodeContext(context URLContext) bytes.Buffer {
	var buff bytes.Buffer
	enc := gob.NewEncoder(&buff)

	err := enc.Encode(context)
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("enc.Encode error|%s", err.Error())
	}
	return buff
}

func DecodeContext(buff bytes.Buffer) *URLContext {
	dec := gob.NewDecoder(&buff)

	var context URLContext
	err := dec.Decode(&context)
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("enc.Decode error|%s", err.Error())
	}
	return &context
}
