package main

import (
	"bytes"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"database/sql"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"strconv"
	"strings"

	_ "github.com/Go-SQL-Driver/MySQL"
	//"time"
)

const (
	DB_USER = "crawler"
	DB_PASS = "crawler"
	//DB_HOST       = "192.168.2.106"
	DB_HOST       = "10.181.10.50"
	DB_PORT       = 3306
	DB_NAME       = "crawler_stat"
	DB_TABLE_CAPT = "captcha_stat_"
	DB_TABLE_POST = "post_stat_"

	SQL_LOG = "log/sql_log"
)

type GoSql struct {
	User     string
	Pass     string
	Host     string
	Port     int
	DBName   string
	LogName  string
	StatDate string //指定统计日期，格式20140604
	db       *sql.DB
	blog     *crawlerlog.BaseLog
}

//province.txt
func GetProvinceMap(path string) map[string]string {
	province_map := make(map[string]string)

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
	} else {
		strArray := strings.Split(string(text), "\n")
		for _, v := range strArray {
			tmpArray := strings.Split(v, "|")
			if len(tmpArray) == 2 {
				province_map[tmpArray[0]] = tmpArray[1]
			}
		}
	}

	return province_map
}

//将domian替换成省市名称
func FilterStatFile(path string, province_map map[string]string) string {
	var new_file_buffer string
	new_path := path + ".new"
	writeSum := 1024

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
	} else {
		strArray := strings.Split(string(text), "\n")

		os.Remove(new_path)

		index := 0
		primary_id := 0
		for _, v := range strArray {
			if len(v) <= 2 || len(v) > 256 {
				log.Println("continue:", len(v), v)
				continue
			}

			index += 1
			primary_id += 1

			v = strings.Replace(v, "_", ".", -1)
			tmpArray := strings.Split(v, "|")
			if len(tmpArray) < 7 {
				log.Println("error, str len is less than 8:", v)
				continue
			}

			//replace province
			mapv, ok := province_map[tmpArray[6]]
			if ok {
				tmpArray[6] = mapv
			}

			new_file_buffer += strconv.Itoa(primary_id) + "|"
			for _, buf := range tmpArray {
				new_file_buffer += (buf + "|")
			}
			new_file_buffer += "\n"

			if index >= writeSum {
				//write
				f, err := os.OpenFile(new_path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
				if err != nil {
					log.Fatalln("got error:", err, new_path)
				}
				n, err := f.Write([]byte(new_file_buffer))
				if err == nil && n < len([]byte(new_file_buffer)) {
					err = io.ErrShortWrite
				}
				if err1 := f.Close(); err == nil {
					err = err1
				}
				if err != nil {
					log.Println("finish write, err:", err)
				}

				new_file_buffer = ""
				index = 0
			}
		}
	}

	if new_file_buffer != "" {
		//write
		f, err := os.OpenFile(new_path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
		if err != nil {
			log.Fatalln("got error:", err, new_path)
		}
		n, err := f.Write([]byte(new_file_buffer))
		if err == nil && n < len([]byte(new_file_buffer)) {
			err = io.ErrShortWrite
		}
		if err1 := f.Close(); err == nil {
			err = err1
		}
		if err != nil {
			log.Println("finish write, err:", err)
		}
	}

	return new_path
}

/*
//将domian替换成省市名称
func FilterStatFile(path string, province_map map[string]string) string {
	new_path := path + ".new"

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
	} else {
		os.Remove(new_path)

		var new_file_buffer string

		strArray := strings.Split(string(text), "\n")
		for _, v := range strArray {
			if len(v) <= 2 {
				continue
			}

			v = strings.Replace(v, "_", ".", -1)
			isFound := false

			tmpArray := strings.Split(v, "|")
			if len(tmpArray) < 7 {
				log.Println("error, str len is not 7. ", v)
				continue
			}

			//replace province
			mapv, ok := province_map[tmpArray[6]]
			if ok {
				tmpArray[7] = mapv
			}

			for _, p := range province_list {
				pArray := strings.Split(p, "|")
				if len(pArray) < 2 {
					log.Println("error, province_list len is not 2. ", p)
					continue
				}

				if strings.Contains(tmpArray[6], pArray[0]) {
					buf := strings.Replace(v, tmpArray[6], pArray[1], -1) + "\n"
					new_file_buffer += buf
					isFound = true
				} else if len(tmpArray) >= 8 && strings.Contains(tmpArray[7], pArray[0]) {
					buf := strings.Replace(v, tmpArray[7], pArray[1], -1) + "\n"
					new_file_buffer += buf
					isFound = true
				}

				if isFound {
					break
				}
			}

			if !isFound {
				new_file_buffer += v + "\n"
			}
		}

		ioutil.WriteFile(new_path, []byte(new_file_buffer), os.FileMode(0666))
	}

	return new_path
}
*/

func DoMultiScp(fileName string) {
	hostList := [...]string{"c52", "c53", "c54", "c55", "c60", "c61", "c62", "c63", "c64", "c65", "c66", "c67", "c68", "c69", "c70"}

	os.Mkdir("./stat", os.FileMode(0777))
	for _, host := range hostList {
		os.Mkdir("./stat", os.FileMode(0777))
		os.Mkdir("stat/"+host, os.FileMode(0777))

		os.Remove("stat/" + host + "/" + fileName)

		cmd := exec.Command("scp", "-P", "2222", "crawler@"+host+":/data/crawler/log/"+fileName, "stat/"+host)
		var out bytes.Buffer
		cmd.Stdout = &out
		err := cmd.Run()
		if err != nil {
			log.Fatalln("cmd fatal error:", err)
		}

		log.Printf("cmd out scp %s, %s, %s\n", host, fileName, out.String())
	}

	newFile := "stat/" + fileName
	for _, host := range hostList {
		text, _ := ioutil.ReadFile("stat/" + host + "/" + fileName)
		if len(text) > 0 {
			f, err := os.OpenFile(newFile, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
			if err != nil {
				log.Fatalln("got error:", err)
			}
			n, err := f.Write([]byte(text))
			if err == nil && n < len([]byte(text)) {
				err = io.ErrShortWrite
			}
			if err1 := f.Close(); err == nil {
				err = err1
			}
			if err != nil {
				log.Println("finish write, err:", err)
			}
		}
	}
}

func NewGoSql(user string, pass string, host string, port int, dbname string, log string, date string) *GoSql {
	gosql := GoSql{}

	gosql.User = user
	gosql.Pass = pass
	gosql.Host = host
	gosql.Port = port
	gosql.DBName = dbname
	gosql.LogName = log
	gosql.StatDate = date

	gosql.Init()

	return &gosql
}

func (gosql *GoSql) SetStatDate(date string) {
	gosql.StatDate = date
}

func (gosql *GoSql) initLog(name string) {
	if name == "" {
		log.Fatalln("fatal err: logname is not valid.", name)
	}

	os.Mkdir("./log", os.FileMode(0777))

	gosql.blog = crawlerlog.NewBaseLog(name, crawlerlog.LOG_SHIFT_BY_DAY, 0, crawlerlog.LOG_FATAL|crawlerlog.LOG_ERROR|crawlerlog.LOG_INFO)
}

func (gosql *GoSql) Init() {
	gosql.initLog(gosql.LogName)

	dbstr := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8", gosql.User, gosql.Pass, gosql.Host, gosql.Port, gosql.DBName)

	gosql.blog.DLogInfo("dbstr:%s", dbstr)

	db, err := sql.Open("mysql", dbstr)
	if err != nil || db == nil {
		panic(err)
	}

	gosql.db = db
}

func (gosql *GoSql) Create_table_stat(tbprefix string) {
	table_name := tbprefix + gosql.StatDate //DB_TABLE_CAPT
	sqlStr := "DROP TABLE IF EXISTS `" + table_name + "`;"

	log.Println("do create table, table_name:", table_name)

	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err := gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}

	sqlStr = "CREATE TABLE `" + table_name + "` ( " +
		"`id` int not null," +
		"`ip` varchar(255) DEFAULT ''," +
		"`date` varchar(255) DEFAULT ''," +
		"`file` varchar(255) DEFAULT ''," +
		"`level` varchar(255) DEFAULT ''," +
		"`type` varchar(255) DEFAULT ''," +
		"`ocr_state` varchar(255) DEFAULT ''," +
		"`address` varchar(255) DEFAULT ''," +
		"`str1` varchar(255) DEFAULT ''," +
		"`str2` varchar(255) DEFAULT '', " +
		"PRIMARY key (id)" +
		") ENGINE=MyISAM DEFAULT CHARSET=utf8;"

	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err = gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}
}

//postdl_capt_stat_20140604
/*
mysql -h 10.105.75.246 -ucrawler -pcrawler -e 'load data local infile "/tmp/postdl_capt_stat_20140604.new" into table crawler_stat.captcha_stat_20140604 character set utf8 fields TERMINATED by "|"'
*/
func (gosql *GoSql) Load_file(filename string, tbprefix string) {
	//prepare file
	datafile := FilterStatFile(filename, GetProvinceMap("province.txt"))
	log.Println("got new datafile:", datafile)

	table_name := tbprefix + gosql.StatDate

	cmdStr := fmt.Sprintf("mysql -h %s -u%s -p%s -e ", gosql.Host, gosql.User, gosql.Pass)
	cmdLoad := "'load data local infile \"./" + datafile + "\" into table crawler_stat." + table_name + " character set utf8 fields TERMINATED by \"|\"' "

	tmpShName := "loadData.sh"

	ioutil.WriteFile(tmpShName, []byte(cmdStr+cmdLoad), os.FileMode(0777))

	//exec
	cmd := exec.Command("sh", tmpShName)
	var out bytes.Buffer
	cmd.Stdout = &out
	err := cmd.Run()
	if err != nil {
		log.Fatalln("cmd fatal error:", err)
	}
	log.Printf("cmd out: %q\n", out.String())

	os.Remove(tmpShName)
}

//全部识别次数，成功获取验证码图片和cookie数
func (gosql *GoSql) StatStartCount(tbprefix string) (int, int) {
	var cntstart, cntreqstart int

	table_name := tbprefix + gosql.StatDate
	sqlStr := "select count(*) as cnt from " + table_name + " where ocr_state = 'ocr.start'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var cnt string
		err = rows.Scan(&cnt)
		if err != nil {
			panic(err)
		}

		cntstart, _ = strconv.Atoi(cnt)
	}

	sqlStr = "select count(*) as cnt from " + table_name + " where ocr_state = 'ocr.req.start'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)
	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var cnt string
		err = rows2.Scan(&cnt)
		if err != nil {
			panic(err)
		}

		cntreqstart, _ = strconv.Atoi(cnt)
	}

	return cntstart, cntreqstart
}

//成功/失败识别次数
func (gosql *GoSql) StatFinishSuccFail(tbprefix string) (int, int) {
	var succsum, failsum int

	table_name := tbprefix + gosql.StatDate
	sqlStr := "select count(*) as s from " + table_name + " where ocr_state = 'ocr.finish.succ'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var s string
		err = rows.Scan(&s)
		if err != nil {
			panic(err)
		}

		succsum, _ = strconv.Atoi(s)
	}

	sqlStr = "select count(*) as s from " + table_name + " where ocr_state = 'ocr.finish.fail'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var s string
		err = rows2.Scan(&s)
		if err != nil {
			panic(err)
		}

		failsum, _ = strconv.Atoi(s)
	}

	return succsum, failsum
}

func (gosql *GoSql) StatReqSuccFail(tbprefix string) (int, int) {
	var succsum, failsum int

	table_name := tbprefix + gosql.StatDate
	sqlStr := "select count(*) as s from " + table_name + " where ocr_state = 'ocr.req.succ'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var s string
		err = rows.Scan(&s)
		if err != nil {
			panic(err)
		}

		succsum, _ = strconv.Atoi(s)
	}

	sqlStr = "select count(*) as s from " + table_name + " where ocr_state = 'ocr.req.fail'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var s string
		err = rows2.Scan(&s)
		if err != nil {
			panic(err)
		}

		failsum, _ = strconv.Atoi(s)
	}

	return succsum, failsum
}

func (gosql *GoSql) StatOcrFail(tbprefix string) int {
	var ocrfail int

	table_name := tbprefix + gosql.StatDate
	sqlStr := "select count(*) as s from " + table_name + " where ocr_state = 'ocr.fail'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var s string
		err = rows.Scan(&s)
		if err != nil {
			panic(err)
		}

		ocrfail, _ = strconv.Atoi(s)
	}
	return ocrfail
}

//成功识别:平均耗时，60s超时的个数
/*
select avg(atime) from
(
select cast(str2 as unsigned) as atime from captcha_stat_20140604 where ocr_state = "ocr.response.time"
) as a
where atime <= 60000
*/
func (gosql *GoSql) StatAvgSuccTime(tbprefix string) (float64, int) {
	var avgTime float64
	var sumTimeout int
	table_name := tbprefix + gosql.StatDate

	sqlStr := fmt.Sprintf("select avg(atime) as t from (select cast(str2 as unsigned) as atime from %s where ocr_state = 'ocr.response.time' ) as a where atime <= 60000", table_name)

	//sqlStr := "select avg(str2) as avgt from " + table_name + " where ocr_state = 'ocr.response.time'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var t string
		err = rows.Scan(&t)
		if err != nil {
			panic(err)
		}

		avgTime, _ = strconv.ParseFloat(t, 64)
	}

	sqlStr = fmt.Sprintf("select count(*) as t from (select cast(str2 as unsigned) as atime from %s where ocr_state = 'ocr.response.time' ) as a where atime > 60000", table_name)
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)
	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var t string
		err = rows2.Scan(&t)
		if err != nil {
			panic(err)
		}

		sumTimeout, _ = strconv.Atoi(t)
	}

	return avgTime, sumTimeout
}

//平均返回结果个数，平均第N个成功
func (gosql *GoSql) StatRespJsonCount(tbprefix string) (float64, float64) {
	var avgJsonCnt, avgSuccIndex float64
	table_name := tbprefix + gosql.StatDate
	sqlStr := "select avg(str1) as s1, avg(str2) as s2 from " + table_name + " where ocr_state = 'ocr.finish.succ'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var s1, s2 string
		err = rows.Scan(&s1, &s2)
		if err != nil {
			panic(err)
		}

		avgJsonCnt, _ = strconv.ParseFloat(s1, 64)
		avgSuccIndex, _ = strconv.ParseFloat(s2, 64)
	}

	return avgJsonCnt, avgSuccIndex
}

func (gosql *GoSql) GetReport() string {
	cntstart, cntreqstart := gosql.StatStartCount(DB_TABLE_CAPT)
	succsum, failsum := gosql.StatFinishSuccFail(DB_TABLE_CAPT)
	avgTime, sumTimeout := gosql.StatAvgSuccTime(DB_TABLE_CAPT)
	reqsuccsum, reqfailsum := gosql.StatReqSuccFail(DB_TABLE_CAPT)
	ocrfail := gosql.StatOcrFail(DB_TABLE_CAPT)
	avgJsonCnt, avgSuccIndex := gosql.StatRespJsonCount(DB_TABLE_CAPT)

	txtStr := fmt.Sprint("cntstart:", cntstart, ", cntreqstart:", cntreqstart, ", succsum:", succsum, ", failsum:", failsum, ", avgTime:", avgTime, ", reqsuccsum:", reqsuccsum, ", reqfailsum:", reqfailsum, ", ocrfail:", ocrfail, ", avgJsonCnt:", avgJsonCnt, ", avgSuccIndex:", avgSuccIndex)

	log.Println(txtStr)

	strbuf := "<html><body><h3>验证码统计</h3></br>"
	strbuf += fmt.Sprintf("统计日期:\t%s</br>", gosql.StatDate)
	strbuf += fmt.Sprintf("全部发起次数:\t%d, 占比: 100</br>", cntstart)
	strbuf += fmt.Sprintf("成功获取验证码:\t%d, 占比: %f</br>", cntreqstart, float64(cntreqstart)/float64(cntstart))
	strbuf += fmt.Sprintf("成功得到验证码结果:\t%d, 占比: %f</br>", reqsuccsum, float64(reqsuccsum)/float64(cntstart))
	strbuf += fmt.Sprintf("验证码识别失败:\t%d, 占比: %f (含60s超时)</br>", reqfailsum, float64(reqfailsum)/float64(cntstart))
	strbuf += fmt.Sprintf("验证码60s超时数量:\t%d, 占比: %f</br>", sumTimeout, float64(sumTimeout)/float64(cntstart))
	strbuf += fmt.Sprintf("破解失败:\t%d, 占比: %f (验证码服务返回不是200)</br>", ocrfail, float64(ocrfail)/float64(cntstart))
	strbuf += fmt.Sprintf("成功破解验证码:\t%d, 占比: %f</br>", succsum, float64(succsum)/float64(cntstart))
	strbuf += fmt.Sprintf("没有成功破解验证码:\t%d, 占比: %f</br>", failsum, float64(failsum)/float64(cntstart))
	strbuf += fmt.Sprintf("验证码平均响应时间:\t%f ms (不含60s超时)</br>", avgTime)
	strbuf += fmt.Sprintf("验证码平均返回结果个数:\t%f, 平均第%f个成功</br>", avgJsonCnt, avgSuccIndex)
	strbuf += "</body></html>"

	ioutil.WriteFile("capt_report.html", []byte(strbuf), os.FileMode(0666))

	//smtp
	user := "jingleizhang@creditease.cn"
	password := ""
	host := "10.181.10.20:25"
	to := "jingleizhang@creditease.cn; weiguozhu@creditease.cn"
	subject := "Captcha Daily Stat " + common.GetDateStr()

	log.Println("send email start")
	err := common.SendMail(user, password, host, to, subject, strbuf, "html")
	if err != nil {
		log.Println("send mail error!")
		log.Println(err)
	} else {
		log.Println("send mail success!")
	}

	return strbuf
}

func main() {
	var dateStr string
	if len(os.Args) < 2 {
		dateStr = common.GetDateStr()
	} else {
		dateStr = os.Args[1]
		if len(dateStr) != 8 {
			log.Println("not valid date:", dateStr)
			return
		}
	}

	DoMultiScp("postdl_capt_stat_" + dateStr)

	gosql := NewGoSql(DB_USER, DB_PASS, DB_HOST, DB_PORT, DB_NAME, SQL_LOG, dateStr)

	gosql.Create_table_stat(DB_TABLE_CAPT)
	fileName := "stat/postdl_capt_stat_" + gosql.StatDate
	gosql.Load_file(fileName, DB_TABLE_CAPT)
	str := gosql.GetReport()
	log.Println(str)
}
