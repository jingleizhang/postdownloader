#!/bin/bash

for shname in `ls stat/`
do
  name=`echo "$shname" | awk -F. '{print $1}'`      
  echo $name
  cat stat/$name/postdl_stat_20140528  >> stat_20140528
done


for (( i=1; i<=300; i++));
do
  echo $i
  echo 'http://zjecredit.org/zjecredit/pages/newsphoto/20130613083750000.jsp?page=$i'
  #wget
  sleep 30
done
