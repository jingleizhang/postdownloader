package main

import (
	"bufio"
	"bytes"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"database/sql"
	"fmt"
	_ "github.com/Go-SQL-Driver/MySQL"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

const (
	DB_USER = "crawler"
	DB_PASS = "crawler"
	//DB_HOST       = "192.168.2.106"
	DB_HOST       = "10.181.10.50"
	DB_PORT       = 3306
	DB_NAME       = "crawler_stat"
	DB_TABLE_CAPT = "captcha_stat_"
	DB_TABLE_POST = "postdl_stat_"

	SQL_LOG = "log/sql_log"

	//状态定义
	STATE_OBJ_RECV      = "obj.recv"
	STATE_OBJ_START     = "obj.start"
	STATE_HTTP_REQ      = "http.req"
	STATE_HTTP_REQ_SUCC = "http.req.succ"
	STATE_HTTP_REQ_FAIL = "http.req.fail"
	STATE_OCR_START     = "ocr.start"
	STATE_OCR_FAIL      = "ocr.fail"
	STATE_DOWNTIME      = "download.time"
	STATE_WRITE         = "write"
	STATE_EMPTY         = "empty"
)

type GoSql struct {
	User     string
	Pass     string
	Host     string
	Port     int
	DBName   string
	LogName  string
	StatDate string //指定统计日期，格式20140604
	db       *sql.DB
	blog     *crawlerlog.BaseLog
}

type KeyState struct {
	date    int
	state   string
	keyword string
	address string
	str1    string
	num1    int
	str3    string
}

//province.txt
func GetProvinceMap(path string) map[string]string {
	province_map := make(map[string]string)

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
	} else {
		strArray := strings.Split(string(text), "\n")
		for _, v := range strArray {
			tmpArray := strings.Split(v, "|")
			if len(tmpArray) == 2 {
				province_map[tmpArray[0]] = tmpArray[1]
			}
		}
	}

	return province_map
}

//将domian替换成省市名称
func FilterStatFile(path string, province_map map[string]string) string {
	var new_file_buffer string
	new_path := path + ".new"
	writeSum := 1024

	os.Remove(new_path)
	var index, primary_id int

	f, err := os.Open(path)
	defer f.Close()
	if nil == err {
		buff := bufio.NewReader(f)
		for {
			v, err := buff.ReadString('\n')
			if err != nil || io.EOF == err {
				break
			}

			if len(v) <= 2 || len(v) > 512 {
				log.Println("continue:", len(v), v)
				continue
			}

			index += 1
			primary_id += 1

			v = strings.Replace(v, "_", ".", -1)
			tmpArray := strings.Split(v, "|")
			if len(tmpArray) < 8 {
				log.Println("error, str len is less than 8:", v)
				continue
			}

			//replace province
			mapv, ok := province_map[tmpArray[7]]
			if ok {
				tmpArray[7] = mapv
			}

			new_file_buffer += strconv.Itoa(primary_id) + "|"
			for _, buf := range tmpArray {
				new_file_buffer += (buf + "|")
			}
			new_file_buffer += "\n"
			
			if index >= writeSum {
				//write
				f, err := os.OpenFile(new_path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
				if err != nil {
					log.Fatalln("got error:", err, new_path)
				}
				n, err := f.Write([]byte(new_file_buffer))
				if err == nil && n < len([]byte(new_file_buffer)) {
					err = io.ErrShortWrite
				}
				if err1 := f.Close(); err == nil {
					err = err1
				}
				if err != nil {
					log.Println("finish write, err:", err)
				}

				new_file_buffer = ""
				index = 0
			}
		}
	}

	//	text, err := ioutil.ReadFile(path)
	//	if err != nil {
	//		log.Fatal("fatal error: ", err.Error())
	//	} else {
	//		strArray := strings.Split(string(text), "\n")
	//
	//		os.Remove(new_path)
	//
	//		index := 0
	//		primary_id := 0
	//		for _, v := range strArray {
	//			if len(v) <= 2 || len(v) > 512 {
	//				log.Println("continue:", len(v), v)
	//				continue
	//			}
	//
	//			index += 1
	//			primary_id += 1
	//
	//			v = strings.Replace(v, "_", ".", -1)
	//			tmpArray := strings.Split(v, "|")
	//			if len(tmpArray) < 8 {
	//				log.Println("error, str len is less than 8:", v)
	//				continue
	//			}
	//
	//			//replace province
	//			mapv, ok := province_map[tmpArray[7]]
	//			if ok {
	//				tmpArray[7] = mapv
	//			}
	//
	//			new_file_buffer += strconv.Itoa(primary_id) + "|"
	//			for _, buf := range tmpArray {
	//				new_file_buffer += (buf + "|")
	//			}
	//			new_file_buffer += "\n"
	//
	//			if index >= writeSum {
	//				//write
	//				f, err := os.OpenFile(new_path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
	//				if err != nil {
	//					log.Fatalln("got error:", err, new_path)
	//				}
	//				n, err := f.Write([]byte(new_file_buffer))
	//				if err == nil && n < len([]byte(new_file_buffer)) {
	//					err = io.ErrShortWrite
	//				}
	//				if err1 := f.Close(); err == nil {
	//					err = err1
	//				}
	//				if err != nil {
	//					log.Println("finish write, err:", err)
	//				}
	//
	//				new_file_buffer = ""
	//				index = 0
	//			}
	//		}
	//	}

	if new_file_buffer != "" {
		//write
		f, err := os.OpenFile(new_path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
		if err != nil {
			log.Fatalln("got error:", err, new_path)
		}
		n, err := f.Write([]byte(new_file_buffer))
		if err == nil && n < len([]byte(new_file_buffer)) {
			err = io.ErrShortWrite
		}
		if err1 := f.Close(); err == nil {
			err = err1
		}
		if err != nil {
			log.Println("finish write, err:", err)
		}
	}

	return new_path
}

func DoMultiScp(fileName string) {
	hostList := [...]string{"c52", "c53", "c54", "c55", "c60", "c61", "c62", "c63", "c64", "c65", "c66", "c67", "c68", "c69", "c70"}
	//hostList := [...]string{"c63", "c64", "c65"}

	for _, host := range hostList {
		os.Mkdir("./stat", os.FileMode(0777))
		os.Mkdir("stat/"+host, os.FileMode(0777))

		os.Remove("stat/" + host + "/" + fileName)

		cmd := exec.Command("scp", "-P", "2222", "crawler@"+host+":/data/crawler/log/"+fileName, "stat/"+host)
		var out bytes.Buffer
		cmd.Stdout = &out
		err := cmd.Run()
		if err != nil {
			log.Fatalln("cmd fatal error:", err, cmd)
		}

		log.Printf("cmd out scp %s, %s, %s\n", host, fileName, out.String())
	}

	newFile := "stat/" + fileName
	for _, host := range hostList {
		text, _ := ioutil.ReadFile("stat/" + host + "/" + fileName)
		if len(text) > 0 {
			f, err := os.OpenFile(newFile, os.O_WRONLY|os.O_CREATE|os.O_APPEND, os.FileMode(0666))
			if err != nil {
				log.Fatalln("got error:", err)
			}
			n, err := f.Write([]byte(text))
			if err == nil && n < len([]byte(text)) {
				err = io.ErrShortWrite
			}
			if err1 := f.Close(); err == nil {
				err = err1
			}
			if err != nil {
				log.Println("finish write, err:", err)
			}
		}
	}
}

func NewGoSql(user string, pass string, host string, port int, dbname string, log string, date string) *GoSql {
	gosql := GoSql{}

	gosql.User = user
	gosql.Pass = pass
	gosql.Host = host
	gosql.Port = port
	gosql.DBName = dbname
	gosql.LogName = log
	gosql.StatDate = date

	gosql.Init()

	return &gosql
}

func (gosql *GoSql) SetStatDate(date string) {
	gosql.StatDate = date
}

func (gosql *GoSql) initLog(name string) {
	if name == "" {
		log.Fatalln("fatal err: logname is not valid.", name)
	}

	os.Mkdir("./log", os.FileMode(0777))

	gosql.blog = crawlerlog.NewBaseLog(name, crawlerlog.LOG_SHIFT_BY_DAY, 0, crawlerlog.LOG_FATAL|crawlerlog.LOG_ERROR|crawlerlog.LOG_INFO)
}

func (gosql *GoSql) Init() {
	gosql.initLog(gosql.LogName)

	dbstr := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8", gosql.User, gosql.Pass, gosql.Host, gosql.Port, gosql.DBName)

	gosql.blog.DLogInfo("dbstr:%s", dbstr)

	db, err := sql.Open("mysql", dbstr)
	if err != nil || db == nil {
		panic(err)
	}

	gosql.db = db
}

func (gosql *GoSql) Create_table_postdl(tbprefix string) {
	table_name := tbprefix + gosql.StatDate //DB_TABLE_POST
	sqlStr := "DROP TABLE IF EXISTS `" + table_name + "`;"

	log.Println("do create table, table_name:", table_name)

	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err := gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}

	sqlStr = "CREATE TABLE `" + table_name + "` ( " +
		"`id` int not null," +
		"`ip` varchar(255) DEFAULT ''," +
		"`date` varchar(255) DEFAULT ''," +
		"`file` varchar(255) DEFAULT ''," +
		"`level` varchar(255) DEFAULT ''," +
		"`type` varchar(255) DEFAULT ''," +
		"`postdl_state` varchar(255) DEFAULT ''," +
		"`keyword` varchar(256) DEFAULT ''," +
		"`address` varchar(128) DEFAULT ''," +
		"`str1` varchar(255) DEFAULT 0," +
		"`num1` bigint DEFAULT 0," +
		"`str3` varchar(255) DEFAULT ''," +
		"PRIMARY key (id)" +
		") ENGINE=MyISAM DEFAULT CHARSET=utf8;"

	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err = gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}

	sqlStr = "ALTER TABLE " + table_name + " ADD INDEX index_state (postdl_state);"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err = gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}

	sqlStr = "ALTER TABLE " + table_name + " ADD INDEX index_keyword (keyword);"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err = gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}

	sqlStr = "ALTER TABLE " + table_name + " ADD INDEX index_num1 (num1);"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	stmt, err = gosql.db.Prepare(sqlStr)
	if err != nil {
		panic(err)
	}

	_, err = stmt.Exec()
	if err != nil {
		panic(err)
	}
}

func (gosql *GoSql) Load_file(filename string, tbprefix string) {
	//prepare file
	datafile := FilterStatFile(filename, GetProvinceMap("province.txt"))
	//log.Println("got new datafile:", datafile)

	table_name := tbprefix + gosql.StatDate

	cmdStr := fmt.Sprintf("mysql -h %s -u%s -p%s -e ", gosql.Host, gosql.User, gosql.Pass)
	cmdLoad := "'load data local infile \"./" + datafile + "\" into table crawler_stat." + table_name + " character set utf8 fields TERMINATED by \"|\"' "

	tmpShName := "loadData.sh"

	ioutil.WriteFile(tmpShName, []byte(cmdStr+cmdLoad), os.FileMode(0777))

	//exec
	cmd := exec.Command("sh", tmpShName)
	var out bytes.Buffer
	cmd.Stdout = &out
	err := cmd.Run()
	if err != nil {
		log.Fatalln("cmd fatal error:", err, cmd)
	}
	log.Printf("cmd out: %q\n", out.String())

	os.Remove(tmpShName)
}

//obj接收数，关键词接收数
func (gosql *GoSql) StatPostdlRecv(tbprefix string) (int, int) {
	var objRecv, keyRecv int

	table_name := tbprefix + gosql.StatDate

	sqlStr := "select count(*) as cnt from " + table_name + " where postdl_state = 'obj.recv'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var cnt string
		err = rows.Scan(&cnt)
		if err != nil {
			panic(err)
		}

		objRecv, _ = strconv.Atoi(cnt)
	}

	sqlStr = "select count(distinct keyword) as cnt from " + table_name + " where postdl_state = 'obj.recv'"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var cnt string
		err = rows2.Scan(&cnt)
		if err != nil {
			panic(err)
		}

		keyRecv, _ = strconv.Atoi(cnt)
	}

	return objRecv, keyRecv
}

//取所有的keyword
func (gosql *GoSql) StatKeywordArray(tbprefix string) []string {
	var keyArray []string

	table_name := tbprefix + gosql.StatDate

	sqlStr := "select distinct keyword from " + table_name
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var keyword string
		err = rows.Scan(&keyword)
		if err != nil {
			panic(err)
		}

		if keyword != "" {
			keyArray = append(keyArray, keyword)
		}
	}

	return keyArray
}

//判断一个keyword是不是成功完成
// return:  1: 成功write
//			2: empty, 无http/ocr失败
//			3: empty, http/ocr失败
//			4: 未执行完，只有recv状态
//			0: 其它
func (gosql *GoSql) IsKeywordSucc(keyStateTmpArray []KeyState) int {
	var result int
	var isFoundRecv, isFoundWrite, isFoundEmpty, isHttpFail, isOcrFail bool //false

	for _, v := range keyStateTmpArray {
		if v.state == STATE_OBJ_RECV {
			isFoundRecv = true
		}

		if v.state == STATE_WRITE {
			isFoundWrite = true
		}

		if v.state == STATE_EMPTY {
			isFoundEmpty = true
		}

		if v.state == STATE_HTTP_REQ_FAIL {
			isHttpFail = true
		}

		if v.state == STATE_OCR_FAIL {
			isOcrFail = true
		}
	}

	if isFoundRecv && isFoundWrite {
		result = 1
	} else if isFoundRecv && isFoundEmpty && !isHttpFail && !isOcrFail {
		result = 2
	} else if isFoundRecv && isFoundEmpty && (isHttpFail && isOcrFail) {
		result = 3
	} else if isFoundRecv && !isFoundWrite && !isFoundEmpty && !isHttpFail && !isOcrFail {
		result = 4
	}

	return result
}

//统计每个key是不是成功完成
func (gosql *GoSql) StatKeyFinish(tbprefix string, keyArray []string) ([]string, []string, []string, []string, []string) {
	var keyArraySuccWrite, keyArraySuccEmpty, keyArrayFail, keyArrayUnknown, keyOnlyRecv []string

	table_name := tbprefix + gosql.StatDate
	for _, v := range keyArray {
		var keyStateTmpArray []KeyState
		sqlStr := "select date, postdl_state, keyword, address, str1, num1, str3 from " + table_name + " where keyword = '" + v + "' order by date"
		gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

		rows, err := gosql.db.Query(sqlStr)
		if err != nil {
			panic(err)
		}

		defer rows.Close()

		for rows.Next() {
			var date, postdl_state, keyword, address, str1, num1, str3 string
			err = rows.Scan(&date, &postdl_state, &keyword, &address, &str1, &num1, &str3)
			if err != nil {
				panic(err)
			}

			keystate := KeyState{}
			if date != "" {
				keystate.date, _ = strconv.Atoi(date)
			}
			keystate.state = postdl_state
			keystate.keyword = keyword
			keystate.address = address
			keystate.str1 = str1
			keystate.num1, _ = strconv.Atoi(num1)
			keystate.str3 = str3

			keyStateTmpArray = append(keyStateTmpArray, keystate)
		}

		//log.Println("keyStateTmpArray:", keyStateTmpArray)

		result := gosql.IsKeywordSucc(keyStateTmpArray)
		if result == 1 {
			keyArraySuccWrite = append(keyArraySuccWrite, v)
		} else if result == 2 {
			keyArraySuccEmpty = append(keyArraySuccEmpty, v)
		} else if result == 3 {
			keyArrayFail = append(keyArrayFail, v)
		} else if result == 4 {
			keyOnlyRecv = append(keyOnlyRecv, v)
		} else {
			keyArrayUnknown = append(keyArrayUnknown, v)
		}
	}

	return keyArraySuccWrite, keyArraySuccEmpty, keyArrayFail, keyOnlyRecv, keyArrayUnknown
}

func (gosql *GoSql) StatHttpReqStatus(tbprefix string) (string, string, string) {
	table_name := tbprefix + gosql.StatDate

	map_httpsucc := make(map[string]int) //key:{POST|GET}.{$address}
	map_httpfail := make(map[string]int)
	var str_succ, str_fail, str_ratio string

	//succ
	sqlStr := "select count(*) cnt, str1, address from " + table_name + " where postdl_state='http.req.succ' group by address, str1 order by cnt desc"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows2, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows2.Close()

	for rows2.Next() {
		var cnt, str1, address string
		err = rows2.Scan(&cnt, &str1, &address)
		if err != nil {
			panic(err)
		}

		if str1 == "GET" || str1 == "POST" {
			map_httpsucc[str1+"."+address], _ = strconv.Atoi(cnt)
			str_succ += cnt + "|" + str1 + "|" + address + "\n"
		}
	}

	//fail
	sqlStr = "select count(*) cnt, str1, address from " + table_name + " where postdl_state='http.req.fail' group by address, str1 order by cnt desc"
	gosql.blog.DLogInfo("sqlStr:%s, table_name:%s", sqlStr, table_name)

	rows, err := gosql.db.Query(sqlStr)
	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var cnt, str1, address string
		err = rows.Scan(&cnt, &str1, &address)
		if err != nil {
			panic(err)
		}

		if str1 == "GET" || str1 == "POST" {
			map_httpfail[str1+"."+address], _ = strconv.Atoi(cnt)
			str_fail += cnt + "|" + str1 + "|" + address + "\n"

			//统计成功率
			cnt2, ok := map_httpsucc[str1+"."+address]
			if ok {
				cnt1, _ := strconv.Atoi(cnt)
				succ_ratio := float64(cnt1) / float64(cnt1+cnt2)
				str_ratio += cnt + "|" + strconv.Itoa(cnt1+cnt2) + "|" + fmt.Sprintf("%f|%s\n", succ_ratio, str1+"."+address)
			}
		}
	}

	return str_succ, str_fail, str_ratio
}

func (gosql *GoSql) GetReport() string {
	objRecv, keyRecv := gosql.StatPostdlRecv(DB_TABLE_POST)
	keyArray := gosql.StatKeywordArray(DB_TABLE_POST)
	keyArraySuccWrite, keyArraySuccEmpty, keyArrayFail, keyOnlyRecv, keyArrayUnknown := gosql.StatKeyFinish(DB_TABLE_POST, keyArray)
	str_succ, str_fail, str_ratio := gosql.StatHttpReqStatus(DB_TABLE_POST)

	txtStr := fmt.Sprint("objRecv:", objRecv, ", keyRecv:", keyRecv, ", keyArray:", keyArray) + "\n"
	txtStr += fmt.Sprint("keyArraySuccWrite:", len(keyArraySuccWrite), keyArraySuccWrite) + "\n"
	txtStr += fmt.Sprint("keyArraySuccEmpty:", len(keyArraySuccEmpty), keyArraySuccEmpty) + "\n"
	txtStr += fmt.Sprint("keyArrayFail:", len(keyArrayFail), keyArrayFail) + "\n"
	txtStr += fmt.Sprint("keyArrayUnknown:", len(keyArrayUnknown), keyArrayUnknown) + "\n"
	txtStr += fmt.Sprint("keyOnlyRecv:", len(keyOnlyRecv), keyOnlyRecv) + "\n"
	txtStr += fmt.Sprint("str_succ:", str_succ) + "\n"
	txtStr += fmt.Sprint("str_fail:", str_fail) + "\n"
	txtStr += fmt.Sprint("str_ratio:", str_ratio) + "\n"

	report_file_name := "postdl_state" + common.GetDateStr() + ".txt"
	ioutil.WriteFile(report_file_name, []byte(txtStr), os.FileMode(0666))

	user := "jingleizhang@creditease.cn"
	password := ""
	host := "10.181.10.20:25"
	to := "jingleizhang@creditease.cn; weiguozhu@creditease.cn"
	subject := "Postdl Daily Stat " + common.GetDateStr()

	err := common.SendMail(user, password, host, to, subject, "<html><body>"+report_file_name+" is ready</body></html>", "html")
	if err != nil {
		log.Println("send mail error!")
		log.Println(err)
	} else {
		log.Println("send mail success!")
	}
	return txtStr
}

func main() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	var dateStr string
	if len(os.Args) < 2 {
		dateStr = common.GetDateStr()
	} else {
		dateStr = os.Args[1]
		if len(dateStr) != 8 {
			log.Println("not valid date:", dateStr)
			return
		}
	}

	DoMultiScp("postdl_post_stat_" + dateStr)

	gosql := NewGoSql(DB_USER, DB_PASS, DB_HOST, DB_PORT, DB_NAME, SQL_LOG, dateStr)
	fileName := "stat/postdl_post_stat_" + gosql.StatDate
	gosql.Create_table_postdl(DB_TABLE_POST)
	gosql.Load_file(fileName, DB_TABLE_POST)

	str := gosql.GetReport()
	log.Println(str)
}
