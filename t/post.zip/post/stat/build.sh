#!/bin/sh

export GOPATH=/code/go
STAT=/code/go/src/crawler/post/stat

cd ${STAT}
go build captcha/capt_stat.go
go build postdl/postdl_stat.go

scp -P2222 postdl_stat capt_stat crawler@10.181.10.52:/data/crawler/stat
cd - >& /dev/null
