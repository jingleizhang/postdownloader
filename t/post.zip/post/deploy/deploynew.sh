#!/bin/bash

PATH="/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin"

MailTool="/data/crawler/monitor/MailSender.py"

ProjectPath="/data/crawler"

#IP=$(/sbin/ifconfig|grep -A3 "eth0"|grep "inet addr"|awk '{print $2}'|awk -F':' '{print $2}')

#本机ip，用于跳过rm
local_ip="10.181.10.52"

#正式环境
nginx_ip="10.181.10.20"
godl_list="10.181.10.52 10.181.10.53 10.181.10.54 10.181.10.55 10.181.10.60 10.181.10.61 10.181.10.62 10.181.10.63 10.181.10.64 10.181.10.65 10.181.10.66 10.181.10.67 10.181.10.68 10.181.10.69 10.181.10.70"
redirector_list="10.181.10.71"
filter_list="10.181.10.51"
flume_list="10.181.10.52 10.181.10.53 10.181.10.54 10.181.10.55 10.181.10.60 10.181.10.61 10.181.10.62 10.181.10.63 10.181.10.64 10.181.10.65 10.181.10.66 10.181.10.67 10.181.10.68 10.181.10.69 10.181.10.70"
postdl_list="10.181.10.52 10.181.10.53 10.181.10.54 10.181.10.55 10.181.10.60 10.181.10.61 10.181.10.62 10.181.10.63 10.181.10.64 10.181.10.65 10.181.10.66 10.181.10.67 10.181.10.68 10.181.10.69 10.181.10.70"
config_list="10.181.10.50"
captcha_list="10.181.10.53 10.181.10.54 10.181.10.55 10.181.10.51 10.181.10.56 10.181.10.57 10.181.10.65 10.181.10.66 10.181.10.67 10.181.10.68"
monitor_list="10.181.10.50 10.181.10.51 10.181.10.52 10.181.10.53 10.181.10.54 10.181.10.55 10.181.10.56 10.181.10.57 10.181.10.60 10.181.10.61 10.181.10.62 10.181.10.63 10.181.10.64 10.181.10.65 10.181.10.66 10.181.10.67 10.181.10.68 10.181.10.69 10.181.10.70 10.181.10.71"
picdl_list="10.181.10.67 10.181.10.68 10.181.10.69 10.181.10.70"

function echo_proxy
{
    python get_proxy.py > proxy.list
    echo $(date +"%Y%m%d %H:%M") "finish proxy"
}

function deploy_godl
{
    #echo_proxy
    
    cd ${ProjectPath}
    rm -rf godl
    wget -nv http://${nginx_ip}/code/godl
    chmod a+x godl
    chmod a+x start.sh
    
    for ip in $godl_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "mkdir -p /data/crawler/pages && rm /data/crawler/godl"
            
            scp -P 2222 godl ${ip}:/data/crawler
            scp -P 2222 start.sh ${ip}:/data/crawler
            scp -P 2222 proxy.list ${ip}:/data/crawler
            scp -P 2222 config.json ${ip}:/data/crawler
            scp -P 2222 realtime_downloader.list ${ip}:/data/crawler
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart download"
    done
}

function deploy_picdl
{
    #echo_proxy
    
    cd ${ProjectPath}
    rm -rf pic_downloader
    rm -f log4go.xml
    wget -nv http://${nginx_ip}/code/pic_downloader
    wget -nv http://${nginx_ip}/code/log4go.xml
    chmod a+x pic_downloader
    
    for ip in $picdl_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "mkdir -p /data/crawler/images && mkdir -p /data/crawler/images.old && rm -f /data/crawler/pic_downloader"
            
            scp -P 2222 pic_downloader ${ip}:/data/crawler
            scp -P 2222 log4go.xml ${ip}:/data/crawler
            scp -P 2222 start_picdl.sh ${ip}:/data/crawler
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart picdl"
    done
}

function deploy_redirect
{
    cd ${ProjectPath}
    rm -rf godl
    wget -nv http://${nginx_ip}/code/godl
    chmod a+x godl
    chmod a+x redirector.sh
    
    for ip in $redirector_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "rm /data/crawler/godl"
            
            scp -P 2222 godl ${ip}:/data/crawler
            scp -P 2222 redirector.sh ${ip}:/data/crawler
            scp -P 2222 proxy.list ${ip}:/data/crawler
            scp -P 2222 config.json ${ip}:/data/crawler
            scp -P 2222 realtime_downloader.list ${ip}:/data/crawler
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart redirect"
    done    
}

function deploy_filter
{
    cd ${ProjectPath}
    rm -rf godl
    wget -nv http://${nginx_ip}/code/godl
    chmod a+x godl
    
    for ip in $filter_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "rm /data/crawler/godl"
            
            scp -P 2222 godl ${ip}:/data/crawler
            scp -P 2222 proxy.list ${ip}:/data/crawler
            scp -P 2222 config.json ${ip}:/data/crawler
            scp -P 2222 realtime_downloader.list ${ip}:/data/crawler
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart filter"
    done  
}

function deploy_postdl
{
    cd ${ProjectPath}
    rm -rf postdl
    wget -nv http://${nginx_ip}/code/postdl
    chmod a+x postdl
    rm -rf postdl.json
    wget -nv http://${nginx_ip}/code/postdl.json
    
    for ip in $postdl_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "rm /data/crawler/postdl"
            
            scp -P 2222 postdl ${ip}:/data/crawler
            scp -P 2222 postdl.json ${ip}:/data/crawler
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart postdl"
    done
}

#####todo: fix this#####
function deploy_config
{
    cd ${ProjectPath}
    rm -rf configserver
    wget -nv http://${nginx_ip}/code/configserver
    chmod a+x configserver
    rm -rf website.json
    wget -nv http://10.181.10.20/code/website.json
    rm -rf metadata.json
    wget -nv http://10.181.10.20/code/metadata.json
    
    for ip in $config_list
    do
        if [[ $ip != $local_ip ]] ; then
            #ssh -p 2222 ${ip} "rm /data/crawler/configserver"
            
            scp -P 2222 website.json ${ip}:/data/crawler
            scp -P 2222 metadata.json ${ip}:/data/crawler
        fi
        
        #ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart config"
    done
}

function deploy_captcha
{
    cd ${ProjectPath}
    rm -rf captcha_service
    wget -nv http://${nginx_ip}/code/captcha_service
    chmod a+x captcha_service
    rm masks.tar.gz
    wget -nv http://${nginx_ip}/code/masks.tar.gz
    
    for ip in $captcha_list
    do
        if [[ $ip != $local_ip ]] ; then
            ssh -p 2222 ${ip} "mkdir -p /data/crawler/captcha && rm /data/crawler/captcha/captcha_service"
            ssh -p 2222 ${ip} "rm /data/crawler/captcha/masks.tar.gz"
            
            scp -P 2222 captcha_service ${ip}:/data/crawler/captcha/
            scp -P 2222 masks.tar.gz ${ip}:/data/crawler/captcha/
            
            ssh -p 2222 ${ip} "cd /data/crawler/captcha && tar zxf masks.tar.gz"
        fi
        
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh restart captcha_service"
    done
}

function deploy_flume
{
    for ip in $flume_list
    do
        if [[ $ip != $local_ip ]] ; then
            scp -P 2222 ./flume/flume.sh ${ip}:/data/crawler/flume/
            ssh -p 2222 ${ip} "rm -rfv /data/crawler/pages/.flumespool/"
            ssh -p 2222 ${ip} "rm -rfv /data/crawler/postpages/.flumespool/"
        fi
        
        ssh -p 2222 ${ip} "mkdir -p /data/crawler/flume && /data/crawler/CrawlerMonitor.sh restart flume"
    done
}

function deploy_monitor
{
    cd ${ProjectPath}
    chmod a+x CrawlerMonitor.sh
    
    for ip in $monitor_list
    do
        if [[ $ip != $local_ip ]] ; then
            scp -P 2222 CrawlerMonitor.sh ${ip}:/data/crawler
            scp -P 2222 ./monitor/MailSender.py ${ip}:/data/crawler/monitor
            #scp -P 2222 ./monitor/argparse-1.2.1.tar.gz ${ip}:/data/crawler/monitor
            #scp -P 2222 ./monitor/chardet-2.2.1.tar.gz ${ip}:/data/crawler/monitor
            #scp -P 2222 ./monitor/ez_setup.py ${ip}:/data/crawler/monitor
            #scp -P 2222 ./monitor/setuptools-3.4.4.zip ${ip}:/data/crawler/monitor
            ssh -p 2222 ${ip} "mkdir -p /data/crawler/monitor/log"
        fi
        
        scp -P 2222 CrawlerMonitor.sh ${ip}:/data/crawler
    done 
}

function seeds_post
{
    echo "begin post"
    python post.py seeds.list
    
    sleep 1

    python generate_links.py > seq.list
    python post.py seq.list
    echo "finish post"
}

function deploy_all
{
    deploy_monitor
    
    deploy_godl
    deploy_picdl
    deploy_redirect
    sleep 10
    #deploy_filter
    #sleep 10
    seeds_post
    
    deploy_postdl
    deploy_config
    deploy_captcha
    
    deploy_flume
}

function stop_all
{
    deploy_monitor

    for ip in $godl_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop download"
    done    
    
    for ip in $picdl_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop picdl"
    done   
    
    for ip in $redirector_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop redirect"
    done  
    
    for ip in $filter_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop filter"
    done  
    
    for ip in $postdl_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop postdl"
    done
    
    #config
    
    for ip in $captcha_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop captcha_service"
    done   
    
    sleep 10
    
    for ip in $flume_list
    do
        ssh -p 2222 ${ip} "/data/crawler/CrawlerMonitor.sh stop flume"
    done  
}

if [ $# -eq 0 ]
then
    echo -e "Usage: $0 { godl | picdl | rediretor | filter | postdl | configserver | captcha | flume | monitor | all | stopall }"
    exit 1
fi

cd `dirname $0`

case $1 in
    godl)
    echo "DEPLOY godl..."
    deploy_godl
    echo "DEPLOY godl...done"
    ;;
    picdl)
    echo "DEPLOY picdl..."
    deploy_picdl
    echo "DEPLOY picdl...done"
    ;;
    redirector)
    echo "DEPLOY rediretor..."
    deploy_redirect
    echo "DEPLOY rediretor...done"
    ;;
    filter)
    echo "DEPLOY filter..."
    deploy_filter
    echo "DEPLOY filter...done"
    ;;
    postdl)
    echo "DEPLOY postdl..."
    deploy_postdl
    echo "DEPLOY postdl...done"
    ;;
    configserver)
    echo "DEPLOY configserver..."
    deploy_config
    echo "DEPLOY configserver...done"
    ;;
    captcha)
    echo "DEPLOY captcha..."
    deploy_captcha
    echo "DEPLOY captcha...done"
    ;;
    flume)
    echo "DEPLOY flume..."
    deploy_flume
    echo "DEPLOY flume...done"
    ;;
    monitor)
    echo "DEPLOY monitor..."
    deploy_monitor
    echo "DEPLOY monitor...done"
    ;;
    all)
    echo "DEPLOY crawler all..."
    deploy_all
    echo "DEPLOY crawler all...done"
    ;;
    stopall)
    echo "STOP crawler all..."
    stop_all
    echo "STOP crawler all...done"
    ;;
    post)
    seeds_post
    ;;
    *)
    echo -e "Usage: $0 { godl | redirector | filter | postdl | configserver | captcha | flume | monitor | all | stopall }"
esac

exit 0
