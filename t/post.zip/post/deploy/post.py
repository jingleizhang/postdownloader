import urllib2, json, urllib, sys, random, time

def post(body, host):
    try:
        print 'post to %s' % (host)
        data = urllib.urlencode({"links": json.dumps(body)})
        req = urllib2.Request(host, data)
        resp = urllib2.urlopen(req)
        time.sleep(0.1)
    except Exception, e:
        print e


body = {}
body["links"] = []
n = 0
for line in file(sys.argv[1]):
    n += 1
    link = line.strip()
    if len(link) > 128:
        continue
    body["links"].append(link)
    if len(body["links"]) % 500 == 0:
        if sys.argv[1] in ['seeds.list']:
            #post(body, 'http://10.181.10.52/download')
            post(body, 'http://127.0.0.1:8000/download')
        else:
            post(body, 'http://127.0.0.1:8100/redirect')
        body["links"] = []

if sys.argv[1] in ['seeds.list']:
    post(body, 'http://127.0.0.1:8000/download')
else:
    post(body, 'http://127.0.0.1:8100/redirect')
