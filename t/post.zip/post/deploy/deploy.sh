#!/bin/bash

#sudo pkill -9 nginx
#sudo /usr/local/nginx/sbin/nginx

cd /data/crawler/

echo "proxy"

#python get_proxy.py > proxy.list

echo "finish proxy"

cd /data/crawler
rm -rf godl
wget http://10.181.10.20/code/godl
chmod a+x godl
rm -rf postdl
wget http://10.181.10.20/code/postdl
chmod a+x postdl
rm -rf configserver
wget http://10.181.10.20/code/configserver
chmod a+x configserver
rm -rf website.json
wget http://10.181.10.20/code/website.json
rm -rf metadata.json
wget http://10.181.10.20/code/metadata.json
rm -rf captcha_service
wget http://10.181.10.20/code/captcha_service
chmod a+x captcha_service

ssh -p 2222 10.181.10.50 "rm /data/crawler/godl"
ssh -p 2222 10.181.10.53 "rm /data/crawler/godl"
ssh -p 2222 10.181.10.54 "rm /data/crawler/godl"
ssh -p 2222 10.181.10.55 "rm /data/crawler/godl"

scp -P 2222 godl 10.181.10.50:/data/crawler
scp -P 2222 godl 10.181.10.53:/data/crawler
scp -P 2222 godl 10.181.10.54:/data/crawler
scp -P 2222 godl 10.181.10.55:/data/crawler

ssh -p 2222 10.181.10.53 "rm /data/crawler/postdl"
ssh -p 2222 10.181.10.54 "rm /data/crawler/postdl"
ssh -p 2222 10.181.10.55 "rm /data/crawler/postdl"
ssh -p 2222 10.181.10.53 "rm /data/crawler/captcha/captcha_service"
ssh -p 2222 10.181.10.54 "rm /data/crawler/captcha/captcha_service"
ssh -p 2222 10.181.10.55 "rm /data/crawler/captcha/captcha_service"
ssh -p 2222 10.181.10.51 "rm /data/crawler/captcha/captcha_service"
ssh -p 2222 10.181.10.56 "rm /data/crawler/captcha/captcha_service"
ssh -p 2222 10.181.10.57 "rm /data/crawler/captcha/captcha_service"

scp -P 2222 website.json 10.181.10.50:/data/crawler
scp -P 2222 metadata.json 10.181.10.50:/data/crawler
scp -P 2222 postdl 10.181.10.53:/data/crawler
scp -P 2222 postdl 10.181.10.54:/data/crawler
scp -P 2222 postdl 10.181.10.55:/data/crawler
scp -P 2222 captcha_service 10.181.10.53:/data/crawler/captcha/captcha_service
scp -P 2222 captcha_service 10.181.10.54:/data/crawler/captcha/captcha_service
scp -P 2222 captcha_service 10.181.10.55:/data/crawler/captcha/captcha_service
scp -P 2222 captcha_service 10.181.10.51:/data/crawler/captcha/captcha_service
scp -P 2222 captcha_service 10.181.10.56:/data/crawler/captcha/captcha_service
scp -P 2222 captcha_service 10.181.10.57:/data/crawler/captcha/captcha_service

scp -P 2222 proxy.list 10.181.10.53:/data/crawler
scp -P 2222 proxy.list 10.181.10.54:/data/crawler
scp -P 2222 proxy.list 10.181.10.55:/data/crawler
scp -P 2222 realtime_downloader.list 10.181.10.53:/data/crawler
scp -P 2222 realtime_downloader.list 10.181.10.54:/data/crawler
scp -P 2222 realtime_downloader.list 10.181.10.55:/data/crawler
#scp proxy.list 10.181.10.43:/data/crawler

scp -P 2222 config.json 10.181.10.50:/data/crawler
scp -P 2222 config.json 10.181.10.53:/data/crawler
scp -P 2222 config.json 10.181.10.54:/data/crawler
scp -P 2222 config.json 10.181.10.55:/data/crawler
#scp config.json 10.181.10.43:/data/crawler

scp -P 2222 ./flume/flume.conf 10.181.10.53:/data/crawler/flume
scp -P 2222 ./flume/flume.conf 10.181.10.54:/data/crawler/flume
scp -P 2222 ./flume/flume.conf 10.181.10.55:/data/crawler/flume


scp -P 2222 redirector.sh 10.181.10.50:/data/crawler
scp -P 2222 start.sh 10.181.10.53:/data/crawler
scp -P 2222 start.sh 10.181.10.54:/data/crawler
scp -P 2222 start.sh 10.181.10.55:/data/crawler
#scp start.sh 10.181.10.43:/data/crawler

scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.50:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.51:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.52:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.53:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.54:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.55:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.56:/data/crawler
scp -P 2222 CrawlerMonitor.sh crawler@10.181.10.57:/data/crawler

echo "begin start service"

ssh -p 2222 10.181.10.50 "/data/crawler/CrawlerMonitor.sh restart redirect"
sleep 10

#ssh -p 2222 10.181.10.50 "/data/crawler/CrawlerMonitor.sh restart configserver"
ssh -p 2222 10.181.10.52 "/data/crawler/CrawlerMonitor.sh restart download"
ssh -p 2222 10.181.10.53 "/data/crawler/CrawlerMonitor.sh restart download"
ssh -p 2222 10.181.10.54 "/data/crawler/CrawlerMonitor.sh restart download"
ssh -p 2222 10.181.10.55 "/data/crawler/CrawlerMonitor.sh restart download"

ssh -p 2222 10.181.10.52 "/data/crawler/CrawlerMonitor.sh restart postdl"
ssh -p 2222 10.181.10.53 "/data/crawler/CrawlerMonitor.sh restart postdl"
ssh -p 2222 10.181.10.54 "/data/crawler/CrawlerMonitor.sh restart postdl"
ssh -p 2222 10.181.10.55 "/data/crawler/CrawlerMonitor.sh restart postdl"

ssh -p 2222 10.181.10.53 "/data/crawler/CrawlerMonitor.sh restart captcha_service"
ssh -p 2222 10.181.10.54 "/data/crawler/CrawlerMonitor.sh restart captcha_service"
ssh -p 2222 10.181.10.55 "/data/crawler/CrawlerMonitor.sh restart captcha_service"
ssh -p 2222 10.181.10.51 "/data/crawler/CrawlerMonitor.sh restart captcha_service"
ssh -p 2222 10.181.10.56 "/data/crawler/CrawlerMonitor.sh restart captcha_service"
ssh -p 2222 10.181.10.57 "/data/crawler/CrawlerMonitor.sh restart captcha_service"

sleep 20
echo "begin post"
python post.py seeds.list

python generate_links.py > seq.list
python post.py seq.list

sleep 10

ssh -p 2222 10.181.10.52 "/data/crawler/CrawlerMonitor.sh restart flume"
ssh -p 2222 10.181.10.53 "/data/crawler/CrawlerMonitor.sh restart flume"
ssh -p 2222 10.181.10.54 "/data/crawler/CrawlerMonitor.sh restart flume"
ssh -p 2222 10.181.10.55 "/data/crawler/CrawlerMonitor.sh restart flume"


