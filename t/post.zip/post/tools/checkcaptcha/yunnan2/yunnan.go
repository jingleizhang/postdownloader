package main

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	TianJin_ECPS_INDEX  = "http://www.cncpsp.org.cn/"
	TianJin_ECPS_CAP    = "http://www.cncpsp.org.cn/TradePriceAction.fhtml?action=getValidCode"
	TianJin_ECPS_PUB    = "http://www.cncpsp.org.cn/TradePriceAction.fhtml"
	TianJin_ECPS_DETAIL = "http://www.cncpsp.org.cn/TradePriceAction.fhtml?action=getCompBaseInfo"

	TianJin_HOST   = "www.cncpsp.org.cn"
	TianJin_ORIGIN = "http://www.cncpsp.org.cn"
	TianJin_REFER  = "http://www.cncpsp.org.cn/foodSafety/manage.jsp"
)

type YNCreditDetai struct {
	Text string `json:"text"`
	Url  string `json:"url"`
}

type YNCreditInfo struct {
	Message string          `json:"message"`
	Data    []YNCreditDetai `json:"data"`
	Success bool            `json:"success"`
}

//云南信用
type YNCreditAIC struct {
	godownloader.AICBase
}

func NewYNCreditAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *YNCreditAIC {
	aic := YNCreditAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "查无相关数据") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *YNCreditAIC) getYNCreditDetail(suburl string, cookies []*http.Cookie) (string, string) {
	indexURL := TianJin_ECPS_INDEX + suburl

	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	//postdata2 := make(map[string]string)

	//	status, html, _, respinfo := aic.DownUtil.PostHTTPRequestByUrl(indexURL, extheaders, postdata2, cookies, true)
	//	if status != 200 || len(html) < 20 {
	//		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), indexURL)
	//		return "", ""
	//	}

	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(indexURL, cookies, true)

	return html, respinfo
}

func (aic *YNCreditAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 1; i++ {
		time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)

		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract YuNanCredit AIC|%s", pname)

		//刷首页
		_, _, cookies, _ := aic.DownUtil.GetHttpRequestByUrl(TianJin_ECPS_PUB, nil, true)

		result, _, imgStr, duration := aic.DownUtil.Post2Captha(TianJin_ECPS_CAP, cookies)
		if result == nil || imgStr == "" {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got error, result == nil or imgStr == nil |%s", pname)
			continue
		}

		for ir, r := range *result {
			url := TianJin_ECPS_DETAIL
			extheaders := make(map[string]string)
			extheaders["Referer"] = TianJin_REFER
			extheaders["Origin"] = TianJin_ORIGIN
			extheaders["Host"] = TianJin_HOST

			postdata := make(map[string]string)
			postdata["bcode"] = ""
			postdata["bname"] = pname
			postdata["searchType"] = "11"
			postdata["checkCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if isPageCorrect(&html) {
					var ynJson YNCreditInfo

					err := json.Unmarshal([]byte(html), &ynJson)
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got json err|%d|%s", status, err.Error())
						continue
					}

					for _, v := range ynJson.Data {
						html, respinfo := aic.getYNCreditDetail(v.Url, cookies)

						palldata = append(palldata, html)
						resparray = append(resparray, respinfo)

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = TianJin_REFER
	headers["Origin"] = TianJin_ORIGIN
	headers["Host"] = TianJin_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewYNCreditAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("汽车")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
