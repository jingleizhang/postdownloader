package main

import (
	"crawler/post/common"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"github.com/moovweb/gokogiri"
	"log"
	//"strconv"
	"net/http"
	"strings"
	"time"
)

const (
	LN_ECPS_INDEX  = "http://xysjpt.lncredit.gov.cn/lndataquery/"
	LN_ECPS_CAP    = ""
	LN_ECPS_PUB    = "http://xysjpt.lncredit.gov.cn/lndataquery/Table_QueryList.aspx"
	LN_ECPS_DETAIL = "http://202.98.60.118:8088/lhzx/PtcxAction.do?method=creditQuery"

	LN_HOST   = "xysjpt.lncredit.gov.cn"
	LN_ORIGIN = "http://xysjpt.lncredit.gov.cn"
	LN_REFER  = ""
)

type LiaoNingAIC struct {
	godownloader.AICBase
}

func NewLiaoNingAIC(headers map[string]string, pages map[string]string, tag string, gclient *graphite.Client, ms int) *LiaoNingAIC {
	aic := LiaoNingAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *LiaoNingAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "当前查询没有获取任何数据记录") || strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "抱歉，找不到您要的页面") {
		return false
	} else {
		return true
	}
}

//<a href="Part_QueryDesc.aspx?id=120990172" title="鞍山华新图书文化有限公司，无不良记录且无失信信息。" target="_blank">鞍山华新图书文化有限公司</a>
func (aic *LiaoNingAIC) extractDetailHref(data string) string {
	start := strings.Index(data, "Part_QueryDesc.aspx?id=")
	end := strings.Index(data, "\" title")

	if start >= 0 && end >= 0 {
		return data[start+len("Part_QueryDesc.aspx?id=") : end]
	}

	return ""
}

//Base.Set_Url('handlers/Handler.ashx?id=000724684' + baseUrl);
func (aic *LiaoNingAIC) extractHandler(data string) string {
	start := strings.Index(data, "Base.Set_Url('")
	end := strings.Index(data, "' + baseUrl)")

	if start >= 0 && end >= 0 {
		return data[start+len("Base.Set_Url('") : end]
	}
	return ""
}

//todo: 企业信用

func (aic *LiaoNingAIC) getBasicInfo(suburl string, cookie []*http.Cookie) (string, string) {
	handler_url := LN_ECPS_INDEX + "handlers/Handler.ashx?id=" + suburl + "&type=CompanyInfo&level=B&typeID=typeQYJBXX&typeName=%u4F01%u4E1A%u57FA%u672C%u4FE1%u606F"
	status, html, _, resp := aic.DownUtil.GetHttpRequestByUrl(handler_url, cookie, true)
	if status == 200 {
	
		return html, resp
	} else {
		log.Println("error, status is ", status, handler_url)
	}

	return "", ""
}

func (aic *LiaoNingAIC) extractLNDetail(html string, cookie []*http.Cookie) (palldata []string, resparray []string) {
	if aic.isPageCorrect(&html) {
		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			log.Println("fatal error: ", err.Error())
			return palldata, resparray
		}

		//extract link
		nodeArr, err := doc.Search("//a")
		if err != nil {
			log.Println("fatal error: ", err.Error(), len(nodeArr))
			return palldata, resparray
		}

		for i, node := range nodeArr {
			if strings.Contains(node.String(), "Part_QueryDesc") {
				detail_url := aic.extractDetailHref(node.String())

				log.Println("finish extract ", i, len(nodeArr)-1, node, detail_url)

				htmlinfo, respinfo := aic.getBasicInfo(detail_url, cookie)

				palldata = append(palldata, htmlinfo)
				resparray = append(resparray, respinfo)

				if aic.SleepMS > 0 {
					time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
				}
			}
		}
	} else {
		log.Println("error, page is not correct.")
	}

	//log.Println("len(palldata), len(resparray):", len(palldata), len(resparray))

	return palldata, resparray
}

func (aic *LiaoNingAIC) extractCreditIndexPage(pname string) (palldata []string, resparray []string, totalpage int) {
	cxnr := godownloader.GetUrlEncode(aic.Utf8ToGb2312(pname))
	detailURL := LN_ECPS_PUB + "?cxnr=" + cxnr + "&cxfw=QYMC-&szdq=&hylx=&ztlx=&pageNum=1&Token=$Token$"
	status, html, cookie, _ := aic.DownUtil.GetHttpRequestByUrl(detailURL, nil, true)

	log.Println(detailURL, status, html)

	tmpAllData, tmpResp := aic.extractLNDetail(html, cookie)

	for _, v := range tmpAllData {
		palldata = append(palldata, v)
	}
	for _, v := range tmpResp {
		resparray = append(resparray, v)
	}

	return palldata, resparray, 0
}

func (aic *LiaoNingAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//_, _, cookies, _ := aic.DownUtil.GetHttpRequestByUrl(LN_ECPS_INDEX, nil, false)
	//log.Println("cookies:", cookies)

	log.Println("do Extract LiaoNing aic:", pname)

	palldata, resparray, totalpage := aic.extractCreditIndexPage(pname)

	log.Println("totalpage:", totalpage)

	//TODO: 如果有多页，开始翻页处理

	return palldata, resparray
}

func main() {
	pname := "图书文化"

	headers := make(map[string]string)
	headers["Referer"] = LN_REFER
	headers["Origin"] = LN_ORIGIN
	headers["Host"] = LN_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewLiaoNingAIC(headers, pages, "", metricSender, 100)

	palldata, resparray := aic.ExtractCredit(pname)

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
