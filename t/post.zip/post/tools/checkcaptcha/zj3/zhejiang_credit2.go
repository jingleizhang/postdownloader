package main

import (
	"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	//"encoding/base64"
	"fmt"
	"github.com/moovweb/gokogiri"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	ZheJiangCredit_ECPS_INDEX  = "http://www.zjcredit.gov.cn:8090"
	ZheJiangCredit_ECPS_CAP    = ""
	ZheJiangCredit_ECPS_PUB    = "http://www.zjcredit.gov.cn:8090/zjxwqy/info/infoListMore.jsp"
	ZheJiangCredit_ECPS_DETAIL = ""

	ZheJiangCredit_HOST   = "www.zjcredit.gov.cn"
	ZheJiangCredit_ORIGIN = "http://www.zjcredit.gov.cn"
	ZheJiangCredit_REFER  = "http://www.zjcredit.gov.cn/zjcreditweb/html/enterpriseList.jsp"
)

//浙江信用2
type ZheJiangCreditAic struct {
	godownloader.AICBase
}

func NewZheJiangCreditAic(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ZheJiangCreditAic {
	aic := ZheJiangCreditAic{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码错误!") || strings.Contains(*str, "页面不存在.") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func Utf8ToGb2312(str string) string {
	encoder := mahonia.NewEncoder("gb2312")
	newstr, ok := encoder.ConvertStringOK(str)
	if !ok {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got encoder error:%s", str)
		return ""
	}
	return newstr
}

func (aic *ZheJiangCreditAic) extractZJC2Code(data string) string {
	//<a onclick='javascript:parent.showCode("10301833")' target='_ablank' title='衢州市安信汽车销售有限公司'>衢州市安信汽车销售有限公司</a>

	var newdata string
	start := strings.Index(data, "showCode(\"")
	end := strings.Index(data, "\")' target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("showCode(\"") : end]
	}

	return newdata
}

func (aic *ZheJiangCreditAic) extractZJC3Detail(code string, cookies []*http.Cookie) (string, string) {
	url := ZheJiangCredit_ECPS_INDEX + "/zjxwqy/checkCode.jsp?test=1&id=" + code

	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		var newdata string
		start := strings.Index(html, "window.open('/zjxwqy")
		end := strings.Index(html, "'); }else if(1==3)")

		if start >= 0 && end >= 0 {
			newdata = html[start+len("window.open('") : end]

			status, html, _, respinfo = aic.DownUtil.GetHttpRequestByUrl(ZheJiangCredit_ECPS_INDEX+newdata, cookies, true)
			if status == 200 || len(html) > 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got not valid status|%d|%s", status, code)
				return html, respinfo
			}
		}
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got not valid status|%d|%s", status, code)
	}

	return "", ""
}

func (aic *ZheJiangCreditAic) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ZheJiangCreditAic AIC|%s", pname)

	url := ZheJiangCredit_ECPS_PUB + "?sslm=001&areaCode=&jgdm=&yyzz=&qymc=" + godownloader.GetUrlEncode(Utf8ToGb2312(pname)) + "&frdb=&jyfw=&xyd="
	status, html, cookies, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, nil, true)

	if status == 200 && len(html) > 20 {
		if isPageCorrect(&html) {
			doc, err := gokogiri.ParseHtml([]byte(html))

			defer doc.Free()
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
			}

			//extract link
			nodeArr, err := doc.Search("//a")
			if err != nil {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error, can not found '//a'|%s", err.Error())
			}

			for i, node := range nodeArr {
				if strings.Contains(node.String(), "parent.showCode") {

					html, respinfo = aic.extractZJC3Detail(aic.extractZJC2Code(node.String()), cookies)

					crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

					palldata = append(palldata, html)
					resparray = append(resparray, respinfo)
				} else {
					if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
						crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
					}
				}

				time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			}

			return palldata, resparray
		}
	}

	return palldata, resparray
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = ZheJiangCredit_REFER
	headers["Origin"] = ZheJiangCredit_ORIGIN
	headers["Host"] = ZheJiangCredit_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewZheJiangCreditAic(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("汽车")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
