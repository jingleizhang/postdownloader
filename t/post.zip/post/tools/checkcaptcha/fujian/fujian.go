package main

import (
	//"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	"github.com/moovweb/gokogiri"
	//"encoding/json"
	"encoding/base64"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	FJ_ECPS_INDEX  = "http://wsgs.fjaic.gov.cn"
	FJ_ECPS_CAP    = "http://wsgs.fjaic.gov.cn/creditpub/govRandValidate?time=1402719182481"
	FJ_ECPS_PUB    = "http://wsgs.fjaic.gov.cn/creditpub/etpsInfo.do?method=queryGov"
	FJ_ECPS_DETAIL = ""

	FJ_HOST   = "wsgs.fjaic.gov.cn"
	FJ_ORIGIN = "http://wsgs.fjaic.gov.cn"
	FJ_REFER  = "http://wsgs.fjaic.gov.cn/creditpub/etpsInfo.do?method=queryGov"
)

type CorpInfo struct {
	CLRQ   string `json:"clrq"`
	DJJG   string `json:"djjg"`
	DJJGMC string `json:"djjdmc"`
	FDDBR  string `json:"fddbr"`
	MCLX   string `json:"mclx"`
	NBXH   string `json:"nbxh"`
	QYLX   string `json:"qylx"`
	QYMC   string `json:"qymc"`
	ZCH    string `json:"zch"`
	ZTLX   string `json:"ztlx"`
}

type FuJianJson struct {
	Count     int        `json:"count"`
	DataArray []CorpInfo `json:"data"`
	Refresh   bool       `json:"refresh"`
	Succ      bool       `json:"successed"`
}

//福建工商
type FJAIC struct {
	godownloader.AICBase
}

func NewFJAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *FJAIC {
	aic := FJAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "如果您看到该提示") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *FJAIC) extractSuburl(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\">")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *FJAIC) getAicDetail(suburl string, cookies []*http.Cookie) (string, string) {
	if strings.Contains(suburl, "&amp;") {
		suburl = strings.Replace(suburl, "&amp;", "&", -1)
	}

	url := FJ_ECPS_INDEX + suburl

	respinfo := "<real_url>" + url + "</real_url>"
	var strQueryWord string
	for _, v := range aic.DownUtil.QueryWords {
		strQueryWord += godownloader.GetUrlEncode(v)
	}
	respinfo += "<query>" + strQueryWord + "</query>"
	respinfo += "<content_type>text/html; charset=utf-8</content_type>"

	//先去rtd查
	rtd := aic.DownUtil.GetRtDownloaderAddr()

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(rtd+base64.URLEncoding.EncodeToString([]byte(url)), cookies, true)
	if status == 200 && len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))

		status, html, _, _ = aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
		if status == 200 || len(html) > 20 {
			return html, respinfo
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
		}
	}

	return "", ""
}

func (aic *FJAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract FuJian AIC|%s", pname)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(FJ_ECPS_CAP)
		if result == nil || cookies == nil {
			continue
		}

		//log.Println(result, cookies, imgStr, duration)

		for ir, r := range *result {
			url := FJ_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = FJ_REFER
			extheaders["Origin"] = FJ_ORIGIN
			extheaders["Host"] = FJ_HOST

			postdata := make(map[string]string)
			postdata["etpsName"] = pname
			postdata["code"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if isPageCorrect(&html) {

					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						return palldata, resparray
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						return palldata, resparray
					}

					if len(nodeArr) == 0 {
						break
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "creditpub") {
							html, respinfo := aic.getAicDetail(aic.extractSuburl(node.String()), cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = FJ_REFER
	headers["Origin"] = FJ_ORIGIN
	headers["Host"] = FJ_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewFJAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("图书")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
