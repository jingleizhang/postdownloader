package extract_zjc_org

import (
	"crawler/post/godownloader"
	"log"
	"net/http"
)

const (
	ZJC_INDEX = "http://www.zjecredit.org/zjecredit/index.do"
	ZJC_PUB   = "http://www.zjecredit.org/zjecredit/searchaction.do?GSJ=toList"

	ZJC_HOST         = "wsgs.fjaic.gov.cn"
	ZJC_ORIGIN       = "http://wsgs.fjaic.gov.cn"
	ZJC_REFER        = "http://wsgs.fjaic.gov.cn/creditpub/etpsInfo.do?method=queryGov"
	TOTAL_PAGE_COUNT = 57709
)

func get_zjc_list(url string, cookies []*http.Cookie, pagecount int, downUtil *DownloadUtil) []string {

		//do post
		url := url
		extheaders := make(map[string]string)
		extheaders["Referer"] = FJ_REFER
		extheaders["Origin"] = FJ_ORIGIN
		extheaders["Host"] = FJ_HOST

		postdata := make(map[string]string)
		postdata["etpsName"] = pname
		postdata["page"] = r.Label

		status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
		if status == 200 && len(html) > 20 {

		}
		
}

func extract_zjc(url string) {
	downUtil := godownloader.NewDownloadUtil(nil)

	status, html, cookies, _ := downUtil.GetHttpRequestByUrl(url, nil, false)
	if status == 200 && len(html) > 20 {
		for pageStart := 1;pageStart <= 57709 ;pageStart++{
			
		}

	}
}

func main() {
}
