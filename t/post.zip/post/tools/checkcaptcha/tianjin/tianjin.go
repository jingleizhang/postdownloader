package main

import (
	//"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	"github.com/moovweb/gokogiri"
	//"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	TianJin_ECPS_INDEX  = "http://www.tjaic.gov.cn/info/"
	TianJin_ECPS_CAP    = "http://202.99.67.176:80/info/inc/checkcode.asp"
	TianJin_ECPS_PUB    = "http://www.tjaic.gov.cn/info/Result.html"
	TianJin_ECPS_DETAIL = ""

	TianJin_HOST   = "www.tjaic.gov.cn"
	TianJin_ORIGIN = "http://www.tjaic.gov.cn"
	TianJin_REFER  = "http://www.tjaic.gov.cn/info/"
)

//天津工商
type TianJinAIC struct {
	godownloader.AICBase
}

func NewTianJinAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *TianJinAIC {
	aic := TianJinAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *TianJinAIC) extractHeBeiSuburl(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *TianJinAIC) extractTJDetail(suburl string, cookies []*http.Cookie) (string, string) {
	url := TianJin_ECPS_INDEX + suburl
	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	return "", ""
}

func (aic *TianJinAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 1; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract TianJin AIC|%s", pname)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(TianJin_ECPS_CAP)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			url := TianJin_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = TianJin_REFER
			extheaders["Origin"] = TianJin_ORIGIN
			extheaders["Host"] = TianJin_HOST

			postdata := make(map[string]string)
			postdata["qymc"] = pname
			postdata["yzmv"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if isPageCorrect(&html) {
					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						return palldata, resparray
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						return palldata, resparray
					}

					if len(nodeArr) == 0 {
						break
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "target") {
							suburl := aic.extractHeBeiSuburl(node.String())
							if !strings.Contains(suburl, "http") {
								html, respinfo := aic.extractTJDetail(suburl, cookies)
								crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

								palldata = append(palldata, html)
								resparray = append(resparray, respinfo)

							} else {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), suburl)
							}
						} else {
							if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
								crawlerlog.CrawlerLogInstance().StatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
							}
						}

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = TianJin_REFER
	headers["Origin"] = TianJin_ORIGIN
	headers["Host"] = TianJin_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewTianJinAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("汽车")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
