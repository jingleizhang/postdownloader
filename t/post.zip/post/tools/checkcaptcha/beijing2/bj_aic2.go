package main

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	//"github.com/moovweb/gokogiri"
	"log"
	"net/http"
	"strings"
	"time"
)

const (
	HN2_ECPS_INDEX  = "http://qyxy.baic.gov.cn"
	HN2_ECPS_CAP    = ""
	HN2_ECPS_PUB    = "http://qyxy.baic.gov.cn/lucene/luceneAction!NetCreditLucene.dhtml?currentTimeMillis=1402878180816&check_code=1"
	HN2_ECPS_DETAIL = ""

	HN2_HOST   = "qyxy.baic.gov.cn"
	HN2_ORIGIN = "http://qyxy.baic.gov.cn"
	HN2_REFER  = "http://qyxy.baic.gov.cn/simple/dealSimpleAction!transport_ww.dhtml?sysid=0150008788304366b7d3903b5067bb8c&module=wzsy&styleFlag=sy"
)

//北京工商（PC）
type BeijingAIC2 struct {
	godownloader.AICBase
}

func NewBeijingAIC2(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *BeijingAIC2 {
	aic := BeijingAIC2{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

//符合您输入关键字的检索结果数量过大，请您输入新的关键字
func (aic *BeijingAIC2) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "符合您输入关键字的检索结果数量过大") || strings.Contains(*str, "无查询结果") || strings.Contains(*str, "您停留的时间过长") {
		return false
	} else if strings.Contains(*str, "您可能频繁重复请求") {
		return false
	} else {
		return true
	}
}

func (aic *BeijingAIC2) extractBJDetail(data string, cookies []*http.Cookie) (string, string) {
	var newdata string
	start := strings.Index(data, "showDialog('")
	end := strings.Index(data, "', '企业详细'")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("showDialog('") : end]
	}

	if strings.Contains(newdata, "&amp;") {
		newdata = strings.Replace(newdata, "&amp;", "&", -1)
	}

	url := HN2_ECPS_INDEX + newdata
	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)

	log.Println(url, status, html, respinfo, cookies)

	if status == 200 || len(html) > 20 {
		if aic.isPageCorrect(&html) {
			return html, respinfo
		}
	}

	return "", ""
}

func (aic *BeijingAIC2) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//刷首页
	_, _, cookies, _ := aic.DownUtil.GetHttpRequestByUrl("http://qyxy.baic.gov.cn/", nil, false)

	url := HN2_ECPS_PUB
	extheaders := make(map[string]string)
	extheaders["Referer"] = HN2_REFER
	extheaders["Origin"] = HN2_ORIGIN
	extheaders["Host"] = HN2_HOST

	postdata := make(map[string]string)
	postdata["queryStr"] = pname
	postdata["module"] = ""
	postdata["idFlag"] = "qyxy"

	status, html, _, respinfo := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	//log.Println(status, html)

	if status == 200 && len(html) > 20 {
		if aic.isPageCorrect(&html) {
			//			doc, err := gokogiri.ParseHtml([]byte(html))
			//
			//			defer doc.Free()
			//			if err != nil {
			//				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
			//			}
			//
			//			//extract link
			//			nodeArr, err := doc.Search("//a")
			//			if err != nil {
			//				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("search '//a' fail, got fatal error|%s", err.Error())
			//			}
			//
			//			for i, node := range nodeArr {
			//				if strings.Contains(node.String(), "queryCreditAction") {
			//					html, respinfo := aic.extractBJDetail(node.String(), cookies)
			//					crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)
			//
			//					log.Println(html, respinfo)
			//
			//					palldata = append(palldata, html)
			//					resparray = append(resparray, respinfo)
			//
			//				} else {
			//					if !strings.Contains(node.String(), "href=\"javascript:void(0)\"") {
			//						crawlerlog.CrawlerLogInstance().PostStatLogger.DLogInfo("postcrawler|href_drop|%s|%s|%s", aic.DownUtil.GetAllQueryWords(), common.ExtractDomainOnly(aic.Ecps_index), node.String())
			//					}
			//				}
			//
			//				time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			//			}
			//
			//			return palldata, resparray
			palldata = append(palldata, html)
			resparray = append(resparray, respinfo)
			
			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
			
			return palldata, resparray
		} else {
			log.Println("page is not correct!")
		}
	}

	return palldata, resparray
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = HN2_REFER
	headers["Origin"] = HN2_ORIGIN
	headers["Host"] = HN2_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewBeijingAIC2(headers, pages, "", 5000, metricSender)

	palldata, resparray := aic.ExtractCredit("汽车电子")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
