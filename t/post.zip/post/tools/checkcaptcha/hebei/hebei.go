package main

import (
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	"github.com/moovweb/gokogiri"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	HN2_ECPS_INDEX  = "http://www.hebscztxyxx.gov.cn/notice/"
	HN2_ECPS_CAP    = "http://www.hebscztxyxx.gov.cn/notice/img.captcha?type=3&ra=0.14000600553117692"
	HN2_ECPS_PUB    = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntList"
	HN2_ECPS_DETAIL = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntInfoMainCountry.do"

	HN2_HOST   = "www.hebscztxyxx.gov.cn"
	HN2_ORIGIN = "http://www.hebscztxyxx.gov.cn"
	HN2_REFER  = "http://www.hebscztxyxx.gov.cn/notice/query/queryEntList"
)

//河北工商
type HeBeiAIC struct {
	godownloader.AICBase
}

func NewHeBeiAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *HeBeiAIC {
	aic := HeBeiAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *HeBeiAIC) extractHeBeiSuburl(data string) string {
	var newdata string
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" target")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("href=\"") : end]
	}

	return newdata
}

func (aic *HeBeiAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "您查询的信息") {
		return true
	} else {
		return false
	}
}

func (aic *HeBeiAIC) extractHeBeiDetail(suburl string, cookies []*http.Cookie) (string, string) {
	url := HN2_ECPS_INDEX + suburl
	status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 || len(html) > 20 {
		log.Println(html, respinfo)

		return html, respinfo
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
	}

	return "", ""
}

func (aic *HeBeiAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract HeBeiAIC|%s", pname)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(HN2_ECPS_CAP)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			queryURL := HN2_ECPS_PUB + "?condition.pageNo=1&condition.entName=" + godownloader.GetUrlEncode(pname) + "&condition.code=" + r.Label
			status, html, _, respinfo := aic.DownUtil.GetHttpRequestByUrl(queryURL, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), queryURL)
			}

			if status == 200 && len(html) > 20 {
				//log.Println(status, html, respinfo)

				if aic.isPageCorrect(&html) {
					doc, err := gokogiri.ParseHtml([]byte(html))
					defer doc.Free()
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got fatal error|%s", err.Error())
						continue
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						continue
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "queryEntInfoMainCountry") {
							html, respinfo := aic.extractHeBeiDetail(aic.extractHeBeiSuburl(node.String()), cookies)

							crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("finish extract|%d|%d|%s", i, len(nodeArr)-1, aic.Ecps_index)

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)

							time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
						}
					}

					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				} else {
					//log.Println("page is not correct")
					continue
				}

			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = HN2_REFER
	headers["Origin"] = HN2_ORIGIN
	headers["Host"] = HN2_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewHeBeiAIC(headers, pages, "", 300, metricSender)

	palldata, resparray := aic.ExtractCredit("汽车")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
