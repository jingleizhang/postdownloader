package main

import (
	"bytes"
	"crawler/post/common"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	"github.com/moovweb/gokogiri"
	"log"
	"net/http"
	"runtime"
	"strings"
)

const (
	GS_ECPS        = "http://xygs.gsaic.gov.cn/gsxygs/pub!list.do"
	GS_ECPS_CAP    = "http://xygs.gsaic.gov.cn/gsxygs/authcode.jsp"
	GS_ECPS_DETAIL = "http://xygs.gsaic.gov.cn/gsxygs/pub!view.do"

	GS_HOST   = "xygs.gsaic.gov.cn"
	GS_ORIGIN = "xygs.gsaic.gov.cn"
	GS_REFER  = "http://xygs.gsaic.gov.cn/gsxygs/"
)

type GanSuAIC struct {
	godownloader.AICBase
}

func NewGanSuAIC(headers map[string]string, pages map[string]string, tag string, gclient *graphite.Client, ms int) *GanSuAIC {
	aic := GanSuAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *GanSuAIC) isPageCorrect(str *string) bool {
	if strings.Contains(*str, "您搜索的条件无查询结果") || strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		return true
	}
}

func (aic *GanSuAIC) extractCreditId(data string) string {
	start := strings.Index(data, "id=\"")
	end := strings.Index(data, "\" href")

	if start >= 0 && end >= 0 {
		return data[start+len("id=\"") : end]
	}

	return ""
}

func (aic *GanSuAIC) getCreditInfoById(cookies []*http.Cookie, detailID string) (string, string) {
	url := GS_ECPS_DETAIL
	extheaders := make(map[string]string)
	extheaders["Referer"] = GS_REFER
	extheaders["Origin"] = GS_ORIGIN
	extheaders["Host"] = GS_HOST

	postdata := make(map[string]string)
	postdata["regno"] = detailID

	status, html, _, resp := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
	if status != 200 || len(html) < 20 {
		log.Println("fatal error:", status, len(html))
		return "", ""
	}
	return html, resp
}

func (aic *GanSuAIC) printMemStats() {
	var mem runtime.MemStats
	runtime.ReadMemStats(&mem)
	buf := bytes.NewBuffer(nil)
	buf.WriteString(strings.Repeat("=", 72) + "\n")
	buf.WriteString("Memory Profile:\n")
	buf.WriteString(fmt.Sprintf("\tAlloc: %d Kb\n", mem.Alloc/1024))
	buf.WriteString(fmt.Sprintf("\tTotalAlloc: %d Kb\n", mem.TotalAlloc/1024))
	buf.WriteString(fmt.Sprintf("\tNumGC: %d\n", mem.NumGC))
	buf.WriteString(fmt.Sprintf("\tGoroutines: %d\n", runtime.NumGoroutine()))
	buf.WriteString(strings.Repeat("=", 72))
	log.Println(buf.String())
}

func (aic *GanSuAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	//刷首页
	//aic.DownUtil.GetHttpRequestByUrl(GS_ECPS, nil, false)

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		log.Println("do Extract FuJian aic:", pname)

		result, cookies := aic.DownUtil.Post2Captha(GS_ECPS_CAP)

		if result == nil || cookies == nil || len(*result) == 0 {
			log.Println("fatal error, result or cookie is nil.")
			return palldata, resparray
		}

		for _, r := range *result {
			log.Println("label:", r.Label, r.Weight)

			url := GS_ECPS
			extheaders := make(map[string]string)
			extheaders["Referer"] = GS_REFER
			extheaders["Origin"] = GS_ORIGIN
			extheaders["Host"] = GS_HOST

			postdata := make(map[string]string)
			postdata["queryVal"] = pname
			postdata["authCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				log.Println("fatal error:", status, len(html))
			}

			if status == 200 {
				if aic.isPageCorrect(&html) {
					doc, err := gokogiri.ParseHtml([]byte(html))

					defer doc.Free()
					if err != nil {
						log.Println("fatal error: ", err.Error())
						return palldata, resparray
					}

					//extract link
					nodeArr, err := doc.Search("//a")
					if err != nil {
						log.Println("fatal error: ", err.Error(), len(nodeArr))
						return palldata, resparray
					}

					if len(nodeArr) == 0 {
						log.Println("got len(nodeArr) is 0. ", html)
						break
					}

					for i, node := range nodeArr {
						if strings.Contains(node.String(), "id=") {
							html, respinfo := aic.getCreditInfoById(cookies, aic.extractCreditId(node.String()))

							log.Println("finish extract ", i, len(nodeArr))

							palldata = append(palldata, html)
							resparray = append(resparray, respinfo)
						}
					}

					return palldata, resparray

				} else {
					log.Println("page is not correct.", html)
				}
			} else {
				log.Println("got error, status is ", status)
			}
		}
	}

	return palldata, resparray
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = GS_REFER
	headers["Origin"] = GS_ORIGIN
	headers["Host"] = GS_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewGanSuAIC(headers, pages, "", metricSender, 100)

	palldata, resparray := aic.ExtractCredit("汽车")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
