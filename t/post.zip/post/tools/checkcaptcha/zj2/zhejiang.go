package main

import (
	"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	//"github.com/moovweb/gokogiri"
	//"io/ioutil"
	"log"
	//"net/http"
	//"os"
	"strings"
	//"time"
)

const (
	ZJ2_ECPS_INDEX  = "http://www.zjecredit.org/zjecredit/index.do"
	ZJ2_ECPS_CAP    = ""
	ZJ2_ECPS_PUB    = "http://www.zjecredit.org/zjecredit/searchaction.do"
	ZJ2_ECPS_DETAIL = ""

	ZJ2_HOST   = "www.zjecredit.org"
	ZJ2_ORIGIN = "http://www.zjecredit.org"
	ZJ2_REFER  = "http://www.zjecredit.org/zjecredit/index.do"
)

//浙江信用
type ZJCreditAIC struct {
	godownloader.AICBase
}

func NewZJCreditAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ZJCreditAIC {
	aic := ZJCreditAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func (aic *ZJCreditAIC) parseCookies(data string) string {
	var newdata string
	start := strings.Index(data, "JSESSIONID=")
	end := strings.Index(data, "; Path")

	if start >= 0 && end >= 0 {
		newdata = data[start+len("JSESSIONID=") : end]
	}

	return newdata
}

func (aic *ZJCreditAIC) Utf8ToGb2312(str string) string {
	encoder := mahonia.NewEncoder("gb2312")
	newstr, ok := encoder.ConvertStringOK(str)
	if !ok {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got encoder error:%s", str)
		return ""
	}
	return newstr
}

func (aic *ZJCreditAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 3; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ZJ CreditAIC|%s", pname)

		//刷首页
		status, html, cookies, _ := aic.DownUtil.GetHttpRequestByUrl(ZJ2_ECPS_INDEX, nil, false)

		jsid := aic.parseCookies(fmt.Sprintf("%s", cookies))

		url := ZJ2_ECPS_PUB + ";jsessionid=" + jsid + "?GSJ=toLookUP2"
		extheaders := make(map[string]string)
		extheaders["Referer"] = ZJ2_REFER
		extheaders["Origin"] = ZJ2_ORIGIN
		extheaders["Host"] = ZJ2_HOST

		postdata := make(map[string]string)
		//postdata["comName"] = godownloader.GetUrlEncode(aic.Utf8ToGb2312(pname))
		postdata["comName"] = aic.Utf8ToGb2312(pname)
		postdata["people"] = ""

		log.Println(url, extheaders, postdata, cookies)

		status, html, cookies2, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
		if status != 200 || len(html) < 20 {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
		}

		if status == 200 {
			log.Println(status, html, ", cookies2:", cookies2)

			_, _, cookies3, _ := aic.DownUtil.GetHttpRequestByUrl("http://www.zjecredit.org/zjecredit/pages/search/waiting.jsp", cookies2, false)

			log.Println("cookies2:", cookies2, ", cookies3:", cookies3)

			//继续post
			postURL := ZJ2_ECPS_PUB + "?GSJ=toList2"
			extheaders := make(map[string]string)
			extheaders["Referer"] = "http://www.zjecredit.org/zjecredit/pages/search/waiting.jsp"
			extheaders["Origin"] = ZJ2_ORIGIN
			extheaders["Host"] = ZJ2_HOST

			status, html, _, _ = aic.DownUtil.PostHTTPRequestByUrl(postURL, extheaders, nil, cookies3, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d|%s", status, len(html), url)
			}

			log.Println(status, html)

			return palldata, resparray
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = ZJ2_REFER
	headers["Origin"] = ZJ2_ORIGIN
	headers["Host"] = ZJ2_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewZJCreditAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("电子信息")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
