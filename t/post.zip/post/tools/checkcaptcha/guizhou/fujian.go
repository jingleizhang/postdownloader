package main

import (
	//"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	//"github.com/moovweb/gokogiri"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	FJ_ECPS_INDEX  = "http://gsxt.gzgs.gov.cn/"
	FJ_ECPS_CAP    = "http://gsxt.gzgs.gov.cn/validCode?validTag=searchImageCode&1402562963414"
	FJ_ECPS_PUB    = "http://gsxt.gzgs.gov.cn/search!searchSczt.shtml"
	FJ_ECPS_DETAIL = ""

	FJ_HOST   = "gsxt.gzgs.gov.cn"
	FJ_ORIGIN = "http://gsxt.gzgs.gov.cn"
	FJ_REFER  = "http://gsxt.gzgs.gov.cn/list.jsp"
)

type CorpInfo struct {
	CLRQ   string `json:"clrq"`
	DJJG   string `json:"djjg"`
	DJJGMC string `json:"djjdmc"`
	FDDBR  string `json:"fddbr"`
	MCLX   string `json:"mclx"`
	NBXH   string `json:"nbxh"`
	QYLX   string `json:"qylx"`
	QYMC   string `json:"qymc"`
	ZCH    string `json:"zch"`
	ZTLX   string `json:"ztlx"`
}

type FuJianJson struct {
	Count     int        `json:"count"`
	DataArray []CorpInfo `json:"data"`
	Refresh   bool       `json:"refresh"`
	Succ      bool       `json:"successed"`
}

//福建工商
type FJAIC struct {
	godownloader.AICBase
}

func NewFJAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *FJAIC {
	aic := FJAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *FJAIC) getAicDetail(aicJson *CorpInfo, cookies []*http.Cookie) (string, string) {
	crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("got aicJson|%s", aicJson)

	var url string

	if aicJson.ZTLX == "1" {
		if strings.Index(aicJson.QYLX, "1") == 0 {
			url = "nzgs/"
		} else if strings.Index(aicJson.QYLX, "2") == 0 {
			url = "nzgsfgs/"
		} else if strings.Index(aicJson.QYLX, "3") == 0 {
			url = "nzqyfr/"
		} else if aicJson.QYLX == "4000" || (strings.Index(aicJson.QYLX, "41") == 0) || (strings.Index(aicJson.QYLX, "42") == 0) || (strings.Index(aicJson.QYLX, "44") == 0) {
			url = "nzyy/"
		} else if (strings.Index(aicJson.QYLX, "43") == 0) || (strings.Index(aicJson.QYLX, "46") == 0) || (strings.Index(aicJson.QYLX, "47") == 0) {
			url = "nzyyfz/"
		} else if strings.Index(aicJson.QYLX, "453") == 0 {
			url = "nzhh/"
		} else if aicJson.QYLX == "4540" {
			url = "grdzgs/"
		} else if aicJson.QYLX == "455" {
			url = "nzhhfz/"
		} else if aicJson.QYLX == "4560" {
			url = "grdzfzjg/"
		} else if (strings.Index(aicJson.QYLX, "50") == 0) || (strings.Index(aicJson.QYLX, "51") == 0) || (strings.Index(aicJson.QYLX, "52") == 0) {
			url = "wstz/"
		} else if (strings.Index(aicJson.QYLX, "53") == 0) || (strings.Index(aicJson.QYLX, "60") == 0) || (strings.Index(aicJson.QYLX, "61") == 0) {
			url = "wstz/"
		} else if (strings.Index(aicJson.QYLX, "62") == 0) || (strings.Index(aicJson.QYLX, "63") == 0) {
			url = "wstz/"
		} else if ((strings.Index(aicJson.QYLX, "58") == 0) || (strings.Index(aicJson.QYLX, "68") == 0) || (strings.Index(aicJson.QYLX, "70") == 0) || (strings.Index(aicJson.QYLX, "71") == 0) || aicJson.QYLX == "7310" || aicJson.QYLX == "7390") && aicJson.QYLX != "5840" && aicJson.QYLX != "6840" {
			url = "wstzfz/"
		} else if (strings.Index(aicJson.QYLX, "54") == 0) || (strings.Index(aicJson.QYLX, "64") == 0) {
			url = "wzhh/"
		} else if (strings.Index(aicJson.QYLX, "5840") == 0) || (strings.Index(aicJson.QYLX, "6840") == 0) {
			url = "wzhhfz/"
		} else if aicJson.QYLX == "7200" {
			url = "czdbjg/"
		} else if aicJson.QYLX == "7300" {
			url = "wgqycsjyhd/"
		} else if aicJson.QYLX == "9100" {
			url = "nmzyhzs/"
		} else if aicJson.QYLX == "9200" {
			url = "nmzyhzsfz/"
		} else {
			crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, 未知企业类型|%s", aicJson.QYLX)
		}
	} else if aicJson.ZTLX == "2" {
		url = "gtgsh/"
	} else {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, 未知主体类型|%s", aicJson.ZTLX)
	}

	indexURL := FJ_ECPS_INDEX + url + "index.jsp"

	extheaders := make(map[string]string)
	extheaders["Referer"] = FJ_REFER
	extheaders["Origin"] = FJ_ORIGIN
	extheaders["Host"] = FJ_HOST

	postdata := make(map[string]string)
	postdata["nbxh"] = aicJson.NBXH
	postdata["qymc"] = aicJson.QYMC
	postdata["zch"] = aicJson.ZCH

	status, html, _, respinfo := aic.DownUtil.PostHTTPRequestByUrl(indexURL, extheaders, postdata, cookies, true)
	if status != 200 || len(html) < 20 {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
	}

	if status == 200 {
		//log.Println(status, html, respinfo)

		//searchOne
		var newdata string
		start := strings.Index(html, "searchOne(")
		end := strings.Index(html, "searchList(")

		if start >= 0 && end >= 0 {
			newdata = html[start+len("searchOne(") : end]
		}

		tmpArray := strings.Split(newdata, ",")
		if len(tmpArray) == 4 {
			//post next
			searchURL := FJ_ECPS_INDEX + url + "search!searchData.shtml"
			postdata2 := make(map[string]string)
			postdata2["nbxh"] = aicJson.NBXH
			postdata2["c"] = strings.TrimSpace(tmpArray[0])
			postdata2["t"] = strings.TrimSpace(tmpArray[1])

			status, html, _, respinfo = aic.DownUtil.PostHTTPRequestByUrl(searchURL, extheaders, postdata2, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 {
				//log.Println(status, html, respinfo)

				return html, respinfo
			}
		}
	}

	return "", ""
}

func (aic *FJAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 1; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract FuJian AIC|%s", pname)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(FJ_ECPS_CAP)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			//log.Println("label:", r.Label, r.Weight)

			url := FJ_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = FJ_REFER
			extheaders["Origin"] = FJ_ORIGIN
			extheaders["Host"] = FJ_HOST

			postdata := make(map[string]string)
			postdata["q"] = pname
			postdata["validCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			if status == 200 && len(html) > 20 {
				if isPageCorrect(&html) {
					var fjJson FuJianJson

					err := json.Unmarshal([]byte(html), &fjJson)
					if err != nil {
						crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got json err|%d|%s", status, err.Error())
						continue
					}

					for _, v := range fjJson.DataArray {
						html, respinfo := aic.getAicDetail(&v, cookies)

						palldata = append(palldata, html)
						resparray = append(resparray, respinfo)

						time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
					}

					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}

			time.Sleep(time.Duration(aic.SleepMS) * time.Millisecond)
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = FJ_REFER
	headers["Origin"] = FJ_ORIGIN
	headers["Host"] = FJ_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewFJAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("图书")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
