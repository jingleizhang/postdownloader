package main

import (
	//"code.google.com/p/mahonia"
	"crawler/post/common"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	"crawler/post/graphite"
	"fmt"
	//"github.com/moovweb/gokogiri"
	"io/ioutil"
	"log"
	//"net/http"
	"os"
	"strings"
	//"time"
)

const (
	ZJ_ECPS_INDEX  = "http://gsxt.zjaic.gov.cn/search/"
	ZJ_ECPS_CAP    = "http://gsxt.zjaic.gov.cn/common/captcha/doReadKaptcha.do"
	ZJ_ECPS_PUB    = "http://gsxt.zjaic.gov.cn/search/doGetAppSearchResultIn.do"
	ZJ_ECPS_DETAIL = ""

	ZJ_HOST   = "gsxt.zjaic.gov.cn"
	ZJ_ORIGIN = "http://gsxt.zjaic.gov.cn"
	ZJ_REFER  = "http://gsxt.zjaic.gov.cn/search/doGetAppSearchResultIn.do"
)

//浙江工商
type ZJAIC struct {
	godownloader.AICBase
}

func NewZJAIC(headers map[string]string, pages map[string]string, tag string, ms int, gclient *graphite.Client) *ZJAIC {
	aic := ZJAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil(gclient)

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)
	aic.SetSleep(ms)

	return &aic
}

func isPageCorrect(str *string) bool {
	if strings.Contains(*str, "验证码不正确！") || strings.Contains(*str, "验证码输入错误") || strings.Contains(*str, "当前操作出现错误,请与管理员联系") {
		return false
	} else {
		//"您搜索的条件无查询结果"
		return true
	}
}

func saveCaptchaSample(imgStr string, url string, nth int, total int, duration int64, label string) {
	domain := strings.Replace(common.ExtractDomainOnly(url), ":", "-", -1)

	fileName := fmt.Sprintf("%s_(%s)_%d_%d_%d.png", label, domain, nth, total, duration)
	err := ioutil.WriteFile(common.PostdlConfigInstance().CaptchaSampleDir+"/"+fileName, []byte(imgStr), os.FileMode(0666))
	if err != nil {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("got WriteFile error:%s", err)
	}
}

func (aic *ZJAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {
	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	//重试三次
	for i := 0; i < 1; i++ {
		crawlerlog.CrawlerLogInstance().RollLogger.DLogInfo("do Extract ZJ AIC|%s", pname)

		result, cookies, imgStr, duration := aic.DownUtil.Post2Captha(ZJ_ECPS_CAP)
		if result == nil || cookies == nil {
			continue
		}

		for ir, r := range *result {
			log.Println("label:", r.Label, r.Weight)

			url := ZJ_ECPS_PUB
			extheaders := make(map[string]string)
			extheaders["Referer"] = ZJ_REFER
			extheaders["Origin"] = ZJ_ORIGIN
			extheaders["Host"] = ZJ_HOST

			postdata := make(map[string]string)
			postdata["name"] = pname
			postdata["verifyCode"] = r.Label

			status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, cookies, true)
			if status != 200 || len(html) < 20 {
				crawlerlog.CrawlerLogInstance().RollLogger.DLogError("error, got status|%d|%d", status, len(html))
			}

			log.Println(status, html)

			if status == 200 {
				if isPageCorrect(&html) {
					//save img to disk
					saveCaptchaSample(imgStr, aic.Ecps_cap, ir, len(*result), duration, r.Label)

					return palldata, resparray
				}
			}
		}
	}

	return nil, nil
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = ZJ_REFER
	headers["Origin"] = ZJ_ORIGIN
	headers["Host"] = ZJ_HOST

	metricSender, err := graphite.New(common.PostdlConfigInstance().GraphiteHost, "")
	if err != nil {
		log.Println("got err:", err)
	}

	pages := make(map[string]string)
	aic := NewZJAIC(headers, pages, "", 2000, metricSender)

	palldata, resparray := aic.ExtractCredit("电子信息")

	//aic.printMemStats()

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
