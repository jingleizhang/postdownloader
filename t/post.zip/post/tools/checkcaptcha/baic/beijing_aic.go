package main

import (
	"crawler/post/godownloader"
	"github.com/moovweb/gokogiri"
	"log"
	"net/http"
	"strconv"
	"strings"
)

const (
	BAIC_REFER  = "http://qyxy.baic.gov.cn/wap/creditWapAction!QueryEnt20130412.dhtml"
	BAIC_ORIGIN = "http://qyxy.baic.gov.cn"
	BAIC_HOST   = "qyxy.baic.gov.cn"

	BAIC_INDEX  = "http://qyxy.baic.gov.cn"
	BAIC_PUB    = "http://qyxy.baic.gov.cn/wap/creditWapAction!QueryEnt20130412.dhtml"
	BAIC_DETAIL = "http://qyxy.baic.gov.cn/xycx/queryCreditAction!qyxq_view.dhtml?reg_bus_ent_id="
)

type BeiJingAIC struct {
	godownloader.AICBase
}

func NewBeiJingAIC(headers map[string]string, pages map[string]string, tag string) *BeiJingAIC {
	aic := BeiJingAIC{}

	aic.DownUtil = godownloader.NewDownloadUtil()

	aic.SetHeaders(headers)
	aic.SetECPSInfo(pages)
	aic.SetTag(tag)

	return &aic
}

func (aic *BeiJingAIC) extractCreditId(data string) string {
	start := strings.Index(data, "href=\"")
	end := strings.Index(data, "\" style=")

	if start >= 0 && end >= 0 {
		return data[start+len("href=\"") : end]
	}

	return ""
}

func (aic *BeiJingAIC) extractJumpPage(data string) int {
	start := strings.Index(data, "jumppage(")
	end := strings.Index(data, ");return")

	if start >= 0 && end >= 0 {
		tmpArray := strings.Split(data[start+len("jumppage("):end], ",")
		if len(tmpArray) > 0 {
			ret, _ := strconv.Atoi(tmpArray[0][1 : len(tmpArray[0])-1])
			return ret
		}
	}
	return 0
}

func (aic *BeiJingAIC) getDetailInfo(suburl string, cookies []*http.Cookie) (string, string) {
	url := BAIC_INDEX + suburl

	status, html, _, _ := aic.DownUtil.GetHttpRequestByUrl(url, cookies, true)
	if status == 200 {
		respinfo := "<real_url>" + url + "</real_url>"
		var strQueryWord string
		for _, v := range aic.DownUtil.QueryWords {
			strQueryWord += godownloader.GetUrlEncode(v)
		}
		respinfo += "<query>" + strQueryWord + "</query>"
		respinfo += "<content_type>text/html; charset=utf-8</content_type>"

		return html, respinfo
	}

	return "", ""
}

func (aic *BeiJingAIC) ExtractCreditByPage(pname string, pagestart int) (palldata []string, resparray []string, totalpages int) {
	totalpages = 0

	url := BAIC_PUB
	extheaders := make(map[string]string)
	extheaders["Referer"] = aic.Referer
	extheaders["Origin"] = aic.Origin
	extheaders["Host"] = aic.Host

	postdata := make(map[string]string)
	postdata["queryStr"] = pname
	postdata["module"] = ""
	postdata["idFlag"] = "qyxy"
	postdata["key_word"] = pname
	postdata["SelectPageSize"] = "30"
	postdata["EntryPageNo"] = "1"
	postdata["pageNo"] = strconv.Itoa(pagestart)
	postdata["pageSize"] = "30"
	postdata["clear"] = "true"

	status, html, _, _ := aic.DownUtil.PostHTTPRequestByUrl(url, extheaders, postdata, nil)
	if status != 200 || len(html) < 20 {
		log.Println("fatal error:", status, len(html))
	}

	if status == 200 {
		log.Println("html:", html)

		doc, err := gokogiri.ParseHtml([]byte(html))

		defer doc.Free()
		if err != nil {
			log.Println("fatal error: ", err.Error())
			return palldata, resparray, totalpages
		}

		//extract link
		nodeArr, err := doc.Search("//a")
		if err != nil {
			log.Println("fatal error: ", err.Error(), len(nodeArr))
			return palldata, resparray, totalpages
		}

		if len(nodeArr) == 0 {
			log.Println("got len(nodeArr) is 0. ", html)
			return palldata, resparray, totalpages
		}

		for i, node := range nodeArr {
			if strings.Contains(node.String(), "reg_bus_ent_id") {
				id := aic.extractCreditId(node.String())

				log.Println("i:", i, ", len:", len(nodeArr))

				html, respinfo := aic.getDetailInfo(id, nil)

				palldata = append(palldata, html)
				resparray = append(resparray, respinfo)
			}
		}

		//extract total page
		for _, node := range nodeArr {
			if strings.Contains(node.String(), "title=\"尾页\"") {
				totalpages = aic.extractJumpPage(node.String())
			}
		}
	}

	return palldata, resparray, totalpages
}

func (aic *BeiJingAIC) ExtractCredit(pname string) (palldata []string, resparray []string) {

	startpage := 1

	aic.DownUtil.QueryWords = append(aic.DownUtil.QueryWords, pname)

	parray, rarray, totalpage := aic.ExtractCreditByPage(pname, startpage)
	for _, str := range parray {
		palldata = append(palldata, str)
	}
	for _, resp := range rarray {
		resparray = append(resparray, resp)
	}

	for totalpage > startpage {
		startpage++

		log.Println("startpage and totalpage:", pname, startpage, totalpage)

		parray2, rarray2, _ := aic.ExtractCreditByPage(pname, startpage)
		for _, str := range parray2 {
			palldata = append(palldata, str)
		}
		for _, resp := range rarray2 {
			resparray = append(resparray, resp)
		}
	}

	return parray, resparray
}

func main() {
	headers := make(map[string]string)
	headers["Referer"] = BAIC_REFER
	headers["Origin"] = BAIC_ORIGIN
	headers["Host"] = BAIC_HOST

	pages := make(map[string]string)
	aic := NewBeiJingAIC(headers, pages, "")

	palldata, resparray := aic.ExtractCredit("宜信")

	log.Println("palldata:", palldata, ", len(palldata):", len(palldata))
	log.Println("resparray:", resparray, ", len(resparray):", len(resparray))
}
