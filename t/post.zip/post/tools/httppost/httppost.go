package main

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"os"
)

const (
	//header
	HEADER_ACCEPT        = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
	HEADER_ACCEPT_ENCODE = "deflate"
	HEADER_UA            = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36"
	HEADER_CONTENT_TYPE  = "application/x-www-form-urlencoded; param=value"
)

func PostHTTPRequest(hosturl string, extheaders map[string]string, postdata map[string]string, reqcookie []*http.Cookie) (string, []*http.Cookie) {
	client := &http.Client{
		CheckRedirect: nil,
	}
	var respcookie []*http.Cookie = nil
	params := url.Values{}
	for key, value := range postdata {
		params.Set(key, value)
	}

	postDataStr := params.Encode()
	postDataBytes := []byte(postDataStr)
	reqest, _ := http.NewRequest("POST", hosturl, bytes.NewReader(postDataBytes))

	reqest.Header.Set("Accept", HEADER_ACCEPT)
	reqest.Header.Set("Accept-Encoding", HEADER_ACCEPT_ENCODE)
	reqest.Header.Set("User-Agent", HEADER_UA)
	reqest.Header.Set("Content-Type", HEADER_CONTENT_TYPE)

	for header, value := range extheaders {
		reqest.Header.Set(header, value)
	}

	if reqcookie != nil {
		for _, ck := range reqcookie {
			reqest.AddCookie(ck)
		}
	}

	response, err := client.Do(reqest)

	if err != nil {
		fmt.Println(err.Error())
	} else {
		defer response.Body.Close()

		if response.StatusCode == 200 {

			//get cookie
			respcookie = response.Cookies()

			html, err := ioutil.ReadAll(response.Body)
			if err != nil {
				fmt.Println("ReadAll error, ", err.Error())
			} else {
				return string(html), respcookie
			}
		} else {
			fmt.Println("got not valid status code:", response.StatusCode)
		}
	}

	return "", respcookie
}

func Post2Crawler() {
	url := "http://127.0.0.1:8301/download"
	//url := "http://10.181.10.52:8301/download"
	headers := make(map[string]string)

	postdata := make(map[string]string)
	postdata["gopost"] = `
				[
				    {
				        "object":[
				            {
				                "entity":"上海化学",
				                "type":"公司名",
				                "tag":"上海市"
				           
				            }
				        ]
				    }
				]`

	//上海家全物流有限公司
	//	postdata["gopost"] = `
	//		[
	//		    {
	//		        "object":[
	//		            {
	//		                "tag":"江苏省",
	//		                "type":"公司名",
	//		                "entity":"无锡市永甫冷作铸件厂"
	//		            }
	//		        ]
	//		    },
	//		    {
	//		        "object":[
	//		            {
	//		                "type":"姓名",
	//		                "entity":"谢心萍"
	//		            },
	//		            {
	//		                "type":"身份证",
	//		                "entity":"210212196205102047"
	//		            }
	//		        ]
	//		    },
	//		    {
	//		        "object":[
	//		            {
	//		                "type":"姓名",
	//		                "entity":"谢心萍"
	//		            }
	//		        ]
	//		    }
	//		]`

	/*
		postdata["gopost"] = `
				[
				    {
				        "object":[
				            {
				                "tag":"山东省",
				                "type":"公司名",
				                "entity":"济南华庄电子科技有限公司"
				            }
				        ]
				    },
				    {
				        "object":[
				            {
				                "tag":"辽宁省",
				                "type":"公司名",
				                "entity":"中兴通讯股份有限公司"
				            }
				        ]
				    },
				    {
				        "object":[
				            {
				                "tag":"重庆市",
				                "type":"公司名",
				                "entity":"重庆市华驰交通科技有限公司"
				            }
				        ]
				    },
				    {
				        "object":[
				            {
				                "type":"姓名",
				                "entity":"谢心萍"
				            },
				            {
				                "type":"身份证",
				                "entity":"210212196205102047"
				            }
				        ]
				    },
				    {
					    "object":[
					            {
					                "entity":"电子信息",
					                "type":"公司名"
					            }
					        ]
					 }
				]`
	*/

	html, _ := PostHTTPRequest(url, headers, postdata, nil)
	fmt.Println(html)
}

func Post2Captha() {
	var img string

	url := "http://127.0.0.1:8900/captcha"

	headers := make(map[string]string)

	reader, err := os.Open("1.png")
	if err != nil {
		fmt.Println(err.Error)
		return
	}

	defer reader.Close()

	buf := make([]byte, 1024)
	for {
		n, _ := reader.Read(buf)
		if 0 == n {
			break
		}
		img += string(buf[:n])
	}
	reader.Close()

	fmt.Println("img:", img)

	postdata := make(map[string]string)
	postdata["img"] = img
	postdata["format"] = "json"

	html, _ := PostHTTPRequest(url, headers, postdata, nil)
	fmt.Println(html)
}

func main() {
	Post2Crawler()
	//Post2Captha()
}
