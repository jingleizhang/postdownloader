import urllib2, json, urllib, sys, random, time

def set_status(query):
    url = 'http://10.180.180.35/DEL/query.' + query
    urllib2.urlopen(url).read()
    url = 'http://10.180.180.35/LPUSH/query.' + query + '/' + str(int(time.time(
))) + '.submitter.submit'
    print url
    urllib2.urlopen(url).read()

def post(body, host):
    try:
        print json.dumps(body)
        data = urllib.urlencode({"gopost": json.dumps(body)})
        req = urllib2.Request(host, data)
        resp = urllib2.urlopen(req)
        time.sleep(0.1)
    except Exception, e:
        print e

objs = []
for line in sys.stdin:
    line = line.strip()
    if len(line) == 0:
        continue
    obj = {}
    obj["object"] = []
    print line
    key, value = line.split('\t')
    obj["object"].append({"entity": value, "type": key})
    #set_status(urllib.quote(value))
    objs.append(obj)
    if len(objs) > 100:
        #post(objs, 'http://post.crawler.bdp.cc/download')
        post(objs, 'http://127.0.0.1:8301/download')
        objs = []

#post(objs, 'http://post.crawler.bdp.cc/download')
post(objs, 'http://127.0.0.1:8301/download')