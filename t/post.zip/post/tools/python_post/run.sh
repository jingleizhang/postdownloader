#!/bin/bash


cat objects.txt | python object_post.py

