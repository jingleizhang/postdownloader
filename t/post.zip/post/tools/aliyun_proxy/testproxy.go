package main

import (
	"crawler/post/godownloader"
	"log"
	"net/http"
)

func main() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)
	var url, html, respinfo string
	var status int
	var cookies []*http.Cookie

	downUtil := godownloader.NewDownloadUtil(nil)

	url = "http://222.171.175.16:9080/ECPS/validateCode.jspx"
	status, html, cookies, respinfo = downUtil.GetHttp(url, nil, nil, nil, false)
	log.Println(status, html, respinfo, cookies)

	url = "http://www.sgs.gov.cn/lz/etpsInfo.do?method=doSearch"
	extheaders := make(map[string]string)
	extheaders["Referer"] = "http://www.sgs.gov.cn/lz/etpsInfo.do?method=doSearch"
	extheaders["Origin"] = "http://www.sgs.gov.cn"
	extheaders["Host"] = "www.sgs.gov.cn"

	postdata := make(map[string]string)
	postdata["searchType"] = "1"
	postdata["keyWords"] = "上海汽车"
	postdata["period"] = "上海汽车"
	postdata["pageNo"] = "1"

	status, html, cookies, respinfo = downUtil.PostHttp(url, extheaders, postdata, nil, true)
	log.Println(status, html, respinfo, cookies)
}
