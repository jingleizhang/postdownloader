package common

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"testing"
)

func TestNewMetaDataConf(t *testing.T) {
	path := "../config/metadata.json"
	text, err := ioutil.ReadFile(path)
	if err != nil {
		fmt.Println("fatal error: ", err.Error())
		panic(err)
	}

	metaConf := NewMetaDataConf(string(text))
	//fmt.Println("metaConf:", metaConf)

	metaJson, err := json.Marshal(metaConf)
	if err != nil {
		t.Error(err)
	}

	if len(metaConf.ExternalMeta) == 0 || len(metaConf.InternalMeta) == 0 || len(metaJson) < 10 {
		t.Error("empty meta config")
	}
}

func TestNewPostConf(t *testing.T) {
	path := "../config/website.json"
	text, err := ioutil.ReadFile(path)
	if err != nil {
		fmt.Println("fatal error: ", err.Error())
		panic(err)
	}

	conf := NewPostConf(string(text))
	//fmt.Println("len(*conf):", len(*conf))

	if len(*conf) == 0 {
		t.Error("empty post config")
	}
}

func TestNewPostdlConfJson(t *testing.T) {
	path := "../godownloader/bin/postdl.json"
	conf := NewPostdlConfJson(path)

	if len(conf.ConfigHost) == 0 {
		t.Error("empty postdl config")
	}
}

func TestNewMetaDataConfByPath(t *testing.T) {
	path := "../config/metadata.json"
	confMeta := NewMetaDataConfByPath(path)

	if len(confMeta.ExternalMeta) == 0 || len(confMeta.InternalMeta) == 0 {
		t.Error("not valid confMeta, ", confMeta)
	}
	//fmt.Println("confMeta:", confMeta)
}

func TestNewPostConfByPath(t *testing.T) {
	path := "../config/website.json"
	confPost := NewPostConfByPath(path)

	if len(*confPost) == 0 {
		t.Error("got empty len(*confPost)")
	}

	//fmt.Println("len(*confPost):", len(*confPost))
}

func TestNewPostObjectEntity(t *testing.T) {
	jsonStr := `
		[
		    {
		        "object":[
		            {
		                "entity":"项亮",
		                "type":"姓名"
		            },
		            {
		                "entity":"12345678900",
		                "type":"手机号"
		            }
		        ]
		    },
		    {
		        "object":[
		            {
		                "entity":"上海文广",
		                "type":"公司名"
		            }
		        ]
		    }
		]`
		
	confObj := NewPostObjectEntity(jsonStr)
	for _,v := range *confObj {
		fmt.Println("---------------v:", v)
	}
	
	if len(*confObj) != 2 {
		t.Error("error")
	}
}
