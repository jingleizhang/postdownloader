package common

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
)

type PostCrawlerState struct {
	ID     int               `json:"id"`
	URL    string            `json:"url"`
	Method string            `json:"method"`
	Params map[string]string `json:"params"`
}

type PostMetaData struct {
	ExternalMeta map[string]string `json:"external_meta"`
	InternalMeta map[string]string `json:"internal_meta"`
}

type PostCrawlerConf struct {
	Domain         string             `json:"domain"`
	Headers        map[string]string  `json:"header"`
	Pages          map[string]string  `json:"pages"`
	PostStateCount int                `json:"state_count"`
	PostState      []PostCrawlerState `json:"state"`
	Keywords       []string           `json:"keyword"`
	SleepMS        int                `json:"sleepms"`
}

type PostdlConfJson struct {
	DownloaderHost   string `json:"downloader_host"`
	RedirectorHost   string `json:"redirector_host"`
	FilterHost       string `json:"filter_host"`
	ConfigHost       string `json:"config_host"`
	PostConfHost     string `json:"postconfig_host"`
	MetaConfHost     string `json:"metaconfig_host"`
	CapConfHost      string `json:"captcha_host"`
	GraphiteHost     string `json:"graphite_host"`
	PagePerMinute    int    `json:"page_per_minute"`
	DownloadTimeout  int64  `json:"download_timeout"`
	RedirectChanNum  int    `json:"redirect_chan_num"`
	RedirectChanSize int    `json:"redirect_chan_size"`
	WritePageFreq    int    `json:"write_page_freq"`
	GoPostChanCount  int    `json:"go_post_chans"`
	DayLog           string `json:"day_log"`
	StatLog          string `json:"stat_log"`
	PostStatLog      string `json:"poststat_log"`
	CaptchaSampleDir string `json:"captcha_samples"`
}

/*
 {"object": [{"tag": "天津市", "type": "公司名", "entity": "天津市武清区杨村镇供电公司"}]}
*/
type Entity struct {
	Name string `json:"entity"`
	Type string `json:"type"`
	Tag  string `json:"tag"`
}

type EntityObject struct {
	EntitySet []Entity `json:"object"`
}

func NewPostdlConfJson(path string) *PostdlConfJson {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	//got pwd
	cmd := exec.Command("pwd")
	var out bytes.Buffer
	cmd.Stdout = &out
	err := cmd.Run()
	if err != nil {
		log.Fatal("fatal error: exec failed.")
	} else {
		log.Printf(out.String())
	}

	postdlConf := PostdlConfJson{}

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error(), ", path:", path)
		panic(err)
	}

	err = json.Unmarshal(text, &postdlConf)
	if err != nil {
		panic(err)
	}

	return &postdlConf
}

//var postdlConfInstance *PostdlConfJson = NewPostdlConfJson("postdl.json")
var postdlConfInstance *PostdlConfJson

func PostdlConfigInstance() *PostdlConfJson {
	if postdlConfInstance == nil {
		path := "/data/crawler/postdl.json"
		_, err := os.Stat(path)
		if err != nil {
			//not valid path
			postdlConfInstance = NewPostdlConfJson("postdl.json")
		} else {
			postdlConfInstance = NewPostdlConfJson(path)
		}
	}
	return postdlConfInstance
}

func NewDefaultMetaConf() *PostMetaData {
	metaConfig := PostMetaData{
		ExternalMeta: make(map[string]string),
		InternalMeta: make(map[string]string),
	}

	return &metaConfig
}

func NewMetaDataConf(jsonstr string) *PostMetaData {
	config := PostMetaData{
		ExternalMeta: make(map[string]string),
		InternalMeta: make(map[string]string),
	}

	err := json.Unmarshal([]byte(jsonstr), &config)
	if err != nil {
		panic(err)
	}
	return &config
}

func NewMetaDataConfByPath(path string) *PostMetaData {
	config := PostMetaData{
		ExternalMeta: make(map[string]string),
		InternalMeta: make(map[string]string),
	}

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
		return &config
	}

	err = json.Unmarshal(text, &config)
	if err != nil {
		panic(err)
	}
	return &config
}

func NewDefaultPostConf() *[]PostCrawlerConf {
	config := PostCrawlerConf{
		Domain:         "",
		Headers:        make(map[string]string),
		PostStateCount: 0,
	}

	var postconfig []PostCrawlerConf
	postconfig = append(postconfig, config)
	return &postconfig
}

func NewPostConf(jsonStr string) *[]PostCrawlerConf {
	var config []PostCrawlerConf

	err := json.Unmarshal([]byte(jsonStr), &config)
	if err != nil {
		panic(err)
	}
	return &config
}

func NewPostConfByPath(path string) *[]PostCrawlerConf {
	var config []PostCrawlerConf

	text, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
		return &config
	}

	err = json.Unmarshal(text, &config)
	if err != nil {
		panic(err)
	}
	return &config
}

func NewPostObjectEntity(jsonStr string) *[]EntityObject {
	var entityArray []EntityObject

	err := json.Unmarshal([]byte(jsonStr), &entityArray)

	if err != nil {
		panic(err)
	}
	return &entityArray
}
