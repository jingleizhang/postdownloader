#!/bin/bash

PATH="/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin"
SERVER_NAME=""

MailTool="/data/crawler/monitor/MailSender.py"

ProjectPath="/data/crawler"
MonitorLog=${ProjectPath}/monitor/log/monitor.log

MailList="jingleizhang@creditease.cn,liangxiang@creditease.cn"
#MailList="jingleizhang@creditease.cn,liangxiang@creditease.cn,huazheng@creditease.cn"

IP=$(/sbin/ifconfig|grep -A3 "eth0"|grep "inet addr"|awk '{print $2}'|awk -F':' '{print $2}')

function service_stop
{
    #echo $(date +"%Y%m%d %H:%M") "${IP}, $1 stop"  
    case $1 in
        download)
        echo "SERVICE STOP $1 ..."
        pkill -9 godl
        ;;
        picdl)
        echo "SERVICE STOP $1 ..."
        pkill -9 pic_downloader
        ;;
        postdl)
        echo "SERVICE STOP $1 ..."
        pkill -9 postdl
        ;;
        captcha_service)
        echo "SERVICE STOP $1 ..."
        pkill -9 captcha_service
        ;;
        flume)
        echo "SERVICE STOP $1 ..."
        pkill -9 java
        ;;
        redirect)
        echo "SERVICE STOP $1 ..."
        pkill -9 godl
        ;;
        filter)
        echo "SERVICE STOP $1 ..."
        pkill -9 godl
        ;; 
        *)
        echo "service_stop: { download | postdl | captcha_service | flume | redirect | filter }"
    esac
    echo $(date +"%Y%m%d %H:%M") "${IP}, $1 stop... done."  
}

function service_start
{
    #echo $(date +"%Y%m%d %H:%M") "${IP}, $1 start"  
    case $1 in
        download)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        #chmod a+x ${ProjectPath}/godl
        #/data/crawler/godl --port 8100 --mode download > /data/crawler/log/$port.log 2>&1 &
        cd ${ProjectPath} && sh start.sh
        ;;
        picdl)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        cd ${ProjectPath} && sh start_picdl.sh
        ;;
        postdl)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        chmod a+x ${ProjectPath}/postdl
        /data/crawler/postdl > /data/crawler/postdl.log 2>&1 &
        ;;
        captcha_service)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        chmod a+x ${ProjectPath}/captcha/captcha_service
        #/data/crawler/captcha/captcha_service > /data/crawler/captcha/captcha_service.log 2>&1 & 
        cd ${ProjectPath}/captcha && sh captcha_service.sh
        ;;
        flume)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        #cd /data/crawler/flume && flume-ng agent -n crawler -f flume.conf > flume.log 2> flume.err < /dev/null &
        #cd /data/crawler/flume && flume-ng agent -n postcrawler -f flume.conf > postflume.log 2> postflume.err < /dev/null &
        cd /data/crawler/flume && sh flume.sh
        ;;
        redirect)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        service_start_redirector
        ;;
        filter)
        echo "SERVICE START $1 ..."
        ulimit -c unlimited
        service_start_filter
        ;;       
        *)
        echo "service_start: { download | postdl | captcha_service | flume | redirect | filter }"
    esac    
    echo $(date +"%Y%m%d %H:%M") "${IP}, $1 start... done."  
}

function service_start_redirector
{
    #echo $(date +"%Y%m%d %H:%M") "${proc_name} redirector START"  
    /data/crawler/godl --port 8100 --mode redirect > /data/crawler/redirect.log 2>&1 &
    echo $(date +"%Y%m%d %H:%M") "${proc_name} redirector START... done."  
}

function service_start_filter
{
    #echo $(date +"%Y%m%d %H:%M") "${IP}, filter START"  
    /data/crawler/godl --port 8100 --mode filter > /data/crawler/filter.log 2>&1 &
    echo $(date +"%Y%m%d %H:%M") "${IP}, filter START... done"  
}

function check_disk_usage
{
    echo $(date +"%Y%m%d %H:%M") "${IP}, check disk usage start"  
    
    tempfile="/tmp/available.$$"

    echo 'EOF' >> ${tempfile}
    echo '{sum += $4}' >> ${tempfile}
    echo 'END {mb = sum / 1024' >> ${tempfile}
    echo 'gb = mb / 1024' >> ${tempfile}
    echo 'printf "%.0f MB (%.2fGB) of available disk space\n", mb, gb' >> ${tempfile}
    echo '}' >> ${tempfile}
    echo 'EOF' >> ${tempfile}
    
    df -k | grep '/data' | awk -f ${tempfile}  
    
    disk_free=`df -k | grep '/data' | awk -f ${tempfile} | awk '{print $1}'`
    if [ "$disk_free" -lt 100 ]
    then
        #write log
        echo $(date +"%Y%m%d %H:%M") "disk space is not enough, now: ${disk_free}MB"  
        #alert
        echo $(date +"%Y%m%d %H:%M") "${IP}, disk space IS NOT ENOUGH, now: ${disk_free}MB."  >  ${tempfile}
        echo "" >> ${tempfile}
        echo "" >> ${tempfile}
        echo "" >> ${tempfile}
        echo $(date +"%Y%m%d %H:%M") "df -h :"  >>  ${tempfile}
        df -h >> ${tempfile}
        cat ${tempfile} | ${MailTool} -s CrawlerMonitor_CheckDisk -o jingleizhang@creditease.cn -d "${MailList}"
    fi 
            
    rm -f ${tempfile}
    echo $(date +"%Y%m%d %H:%M") "check disk usage... done. ${disk_free}MB is available."  
}

function check_alive
{
    proc_name=$1
    proc_num=`ps -ef|grep ${proc_name}|grep -v grep|grep -v tail|grep -v CrawlerMonitor.sh|wc|awk '{printf $1}'`
    echo $(date +"%Y%m%d %H:%M") "Process Name: ${proc_name} , Process Count: ${proc_num}"  
    
    if [ "$proc_num" -lt 1 ]
    then
        #write log
        echo "---------------ps result before restart----------------"  
        ps -ef|grep -v grep|grep ${proc_name}  
        echo ""  
        echo $(date +"%Y%m%d %H:%M") "${proc_name} restart"  
        echo ""  

        #alert
        tempfile="/tmp/available.$$"
        echo $(date +"%Y%m%d %H:%M") "${IP}, Process Name: ${proc_name} , Process Number: ${proc_num}" >> ${tempfile}
        echo "" >> ${tempfile}
        echo $(date +"%Y%m%d %H:%M") "${IP}, ${proc_name} process IS NOT ALIVE." >> ${tempfile}
        echo "" >> ${tempfile}
        echo "---------------ps result before restart----------------" >> ${tempfile}
        echo "ps -ef|grep -v grep|grep ${proc_name}" >> ${tempfile}
        ps -ef|grep -v grep|grep ${proc_name} >> ${tempfile}
        echo "" >> ${tempfile}
        echo "---------------tail -n 200 /data/crawler/postdl.log----------------" >> ${tempfile}
        tail -n 200 /data/crawler/postdl.log >> ${tempfile}
        echo "" >> ${tempfile}
        
        #restart
        ulimit -c unlimited
        echo $(date +"%Y%m%d %H:%M") "${IP}, 'ulimit -c unlimited'... Done." >> ${tempfile}
        echo "" >> ${tempfile}
        
        service_stop ${proc_name}
        echo $(date +"%Y%m%d %H:%M") "${IP}, $1 SERVICE STOP... Done." >> ${tempfile}
        echo "" >> ${tempfile}
        
        service_start ${proc_name}
        echo $(date +"%Y%m%d %H:%M") "${IP}, $1 SERVICE START... Done." >> ${tempfile}
        echo "" >> ${tempfile}
        
        #send mail
        cat ${tempfile} | ${MailTool} -s CrawlerMonitor_CheckAlive -o jingleizhang@creditease.cn -d "${MailList}"
        rm -f ${tempfile}
        
    fi
    echo $(date +"%Y%m%d %H:%M") "Check Process Number : ${proc_name} ${proc_num}... done."  
}

if [ $# -eq 0 ]
then
    echo -e "Usage: $0 { stop | start | restart | check_alive | check_disk }"
    exit 1
fi

cd `dirname $0`

case $1 in
    stop)
    echo "SERVICE STOP ..."
    service_stop $2
    ;;
    start)
    echo "SERVICE START ..."
    service_start $2
    ;;
    restart)
    echo "SERVICE RESTART ..."
    service_stop $2
    service_start $2
    ;;
    check_alive)
    echo "SERVICE CHECK ALIVE $2 ..."
    check_alive $2
    ;;
    check_disk)
    echo "SERVICE CHECK DISK ..."
    check_disk_usage
    ;;
    *)
    echo -e "Usage: $0 { stop | start | restart | check_alive | check_disk }"
esac

exit 0
