package main

import (
	"crawler/post/godownloader"
	"fmt"
)

func main() {
	postdownstat := godownloader.NewPostDownloadStat()

	postdl := godownloader.NewPostDownloader(postdownstat)

	postConfArray := postdl.GetPostConf()

	fmt.Println(len(*postConfArray))

	for _, v := range *postConfArray {
		fmt.Println(fmt.Sprintf("%s|%s", v.Domain, v.Keywords))
	}
}
