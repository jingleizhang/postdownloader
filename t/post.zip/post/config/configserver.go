package main

import (
	"crawler/post/common"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"runtime"
)

func confHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		path := "website.json"

		text, err := ioutil.ReadFile(path)
		if err != nil {
			log.Fatal("fatal error: ", err.Error(), r.RemoteAddr, r.URL)
			http.NotFound(w, r)
		} else {
			io.WriteString(w, string(text))
			log.Println("response GET request from ", r.RemoteAddr, r.URL)
		}

	} else {
		io.WriteString(w, "go web server")
		log.Fatal("fatal error: not valid request", r.RemoteAddr, r.Method, r.URL)
	}
}

func metaHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		path := "metadata.json"

		text, err := ioutil.ReadFile(path)
		if err != nil {
			log.Fatal("fatal error: ", err.Error(), r.RemoteAddr, r.URL)
			http.NotFound(w, r)
		} else {
			io.WriteString(w, string(text))
			log.Println("response GET request from ", r.RemoteAddr, r.URL)
		}

	} else {
		io.WriteString(w, "go web server")
		log.Fatal("fatal error: not valid request from ", r.RemoteAddr, r.Method, r.URL)
	}
}

func webHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		io.WriteString(w, "this is web page")
	} else {
		io.WriteString(w, "go web server")
		log.Println("fatal error: not valid request", r.RemoteAddr, r.Method, r.URL)
	}
}

func main() {
	runtime.GOMAXPROCS(runtime.NumCPU())
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	http.HandleFunc("/crawler/config/json/postconf", confHandler)
	http.HandleFunc("/crawler/config/json/meta", metaHandler)
	http.HandleFunc("/crawler/config/web", webHandler)

	err := http.ListenAndServe(common.PostdlConfigInstance().ConfigHost, nil)
	if err != nil {
		log.Fatal("fatal error: ", err.Error())
	}
}
