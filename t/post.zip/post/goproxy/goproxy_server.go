package main

import (
	"bytes"
	"crawler/post/crawlerlog"
	"crawler/post/godownloader"
	//"crawler/post/goproxy"
	"io"
	"log"
	"net/http"
	"strings"
)

func proxyHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		io.WriteString(w, "<html><head>head</head><body>do not support GET</body></html>")
	} else if r.Method == "POST" {
		r.ParseForm()

		paramMap := make(map[string]string)
		for k, v := range r.Form {
			paramMap[k] = strings.Join(v, "")
		}

		if paramMap["type"] == "goproxy" {
			var buff bytes.Buffer
			buff.WriteString(paramMap["context"])
			context := godownloader.DecodeContext(buff)

			var reqCookieArray []*http.Cookie
			for _, v := range context.CookiesReq {
				reqCookieArray = append(reqCookieArray, &v)
			}

			downUtil := godownloader.NewDownloadUtil(nil)
			var cookies []*http.Cookie

			if context.Method == "GET" {
				context.Status, context.Html, cookies, context.Respinfo = downUtil.GetHttpRequestByUrl(context.URL, reqCookieArray, context.Convert2Utf8)

				context.CookiesResp = context.CookiesResp[:0] //clear
				for _, v := range cookies {
					context.CookiesResp = append(context.CookiesResp, *v)
				}

				//log.Println(cookies, context.CookiesResp)
				log.Println(context.URL, context.Status, context.Respinfo, len(buff.String()), context.CookiesResp, len(context.CookiesResp))

				buff = godownloader.EncodeContext(*context)
				io.WriteString(w, buff.String())
			} else if context.Method == "POST" {
				context.Status, context.Html, cookies, context.Respinfo = downUtil.PostHTTPRequestByUrl(context.URL, context.Headers, context.PostData, reqCookieArray, context.Convert2Utf8)

				context.CookiesResp = context.CookiesResp[:0] //clear
				for _, v := range cookies {
					context.CookiesResp = append(context.CookiesResp, *v)
				}

				buff = godownloader.EncodeContext(*context)

				log.Println(cookies, context.CookiesResp)
				log.Println(context.URL, context.Status, context.Respinfo, len(buff.String()), context.CookiesResp, len(context.CookiesResp))

				io.WriteString(w, buff.String())
			}
		}
	} else {
		io.WriteString(w, "go web server")
	}
}

func main() {
	http.HandleFunc("/proxy", proxyHandler)
	err := http.ListenAndServe("127.0.0.1:9110", nil)
	if err != nil {
		log.Fatal(log.Ldate, "|", log.Ltime, "|", log.Lshortfile, "|fatal error: ", err.Error())
		crawlerlog.CrawlerLogInstance().RollLogger.DLogError("fatal error|%s", err.Error())
	}
}
